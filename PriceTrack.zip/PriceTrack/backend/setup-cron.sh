#!/bin/bash

# Get the absolute path to the script directory
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
UPDATE_SCRIPT="$SCRIPT_DIR/update-prices.sh"

# Check if the update script exists
if [ ! -f "$UPDATE_SCRIPT" ]; then
    echo "Error: update-prices.sh not found at $UPDATE_SCRIPT"
    exit 1
fi

# Make sure the update script is executable
chmod +x "$UPDATE_SCRIPT"

# Create a temporary file for the crontab
TEMP_CRON=$(mktemp)

# Get the current crontab
crontab -l > "$TEMP_CRON" 2>/dev/null || echo "# Creating new crontab" > "$TEMP_CRON"

# Check if the cron job already exists
if grep -q "$UPDATE_SCRIPT" "$TEMP_CRON"; then
    echo "Cron job already exists."
else
    # Add the cron job to run every hour
    echo "# PriceTrack - Update prices every hour" >> "$TEMP_CRON"
    echo "0 * * * * $UPDATE_SCRIPT >> $SCRIPT_DIR/cron.log 2>&1" >> "$TEMP_CRON"
    
    # Install the updated crontab
    crontab "$TEMP_CRON"
    echo "Cron job added to update prices every hour."
fi

# Clean up
rm "$TEMP_CRON"

echo "Setup complete. The price update will run every hour."
echo "You can check the logs in: $SCRIPT_DIR/cron.log and $SCRIPT_DIR/update-prices.log" 