#!/usr/bin/env node

/**
 * Скрипт для тестирования парсеров маркетплейсов
 * 
 * Пример использования:
 * node test-parsers.js
 */

const { exec } = require('child_process');
const util = require('util');
const execAsync = util.promisify(exec);

// Примеры URL товаров для тестирования
const TEST_URLS = {
  ozon: 'https://www.ozon.ru/product/smartfon-xiaomi-redmi-12-8-256gb-graphite-gray-global-version-1171511903/',
  wildberries: 'https://www.wildberries.ru/catalog/elektronika/noutbuki-periferiya/noutbuki-ultrabuki',
  aliexpress: 'https://aliexpress.ru/item/1005004702108257.html'
};

// Асинхронная функция для тестирования парсеров
async function testParsers() {
  console.log('=== Тестирование парсеров маркетплейсов ===\n');
  
  // Проверка зависимостей
  try {
    console.log('Проверка Python...');
    await execAsync('python3 --version');
    console.log('Проверка Selenium...');
    await execAsync('python3 -c "from selenium import webdriver"').catch(async () => {
      console.log('Selenium не установлен, устанавливаем...');
      await execAsync('bash scripts/setup-selenium-parser.sh');
    });
    console.log('Зависимости проверены успешно!\n');
  } catch (error) {
    console.error('Ошибка при проверке зависимостей:', error.message);
    process.exit(1);
  }
  
  // Тестирование парсеров для каждого маркетплейса
  for (const [marketplace, url] of Object.entries(TEST_URLS)) {
    console.log(`\n=== Тестирование парсера для ${marketplace.toUpperCase()} ===`);
    console.log(`URL: ${url}\n`);
    
    try {
      // Тестирование Selenium парсера
      console.log('1. Тестирование Selenium парсера:');
      const seleniumStart = Date.now();
      const seleniumResult = await execAsync(`python3 scripts/selenium_parser.py --url "${url}"`);
      const seleniumTime = (Date.now() - seleniumStart) / 1000;
      
      const seleniumData = JSON.parse(seleniumResult.stdout);
      console.log('Результат:');
      console.log(JSON.stringify(seleniumData, null, 2));
      console.log(`Время выполнения: ${seleniumTime.toFixed(2)} секунд\n`);
      
      // Тестирование Playwright парсера
      console.log('2. Тестирование Playwright парсера:');
      const playwrightStart = Date.now();
      const playwrightResult = await execAsync(`python3 scripts/price_parser.py --url "${url}"`);
      const playwrightTime = (Date.now() - playwrightStart) / 1000;
      
      const playwrightData = JSON.parse(playwrightResult.stdout);
      console.log('Результат:');
      console.log(JSON.stringify(playwrightData, null, 2));
      console.log(`Время выполнения: ${playwrightTime.toFixed(2)} секунд\n`);
      
      // Сравнение результатов
      console.log('Сравнение результатов:');
      console.log('Selenium парсер:');
      console.log(`- Название: ${seleniumData.name}`);
      console.log(`- Цена: ${seleniumData.price}`);
      console.log(`- Оригинальная цена: ${seleniumData.originalPrice}`);
      console.log(`- Успешно: ${seleniumData.success}`);
      
      console.log('\nPlaywright парсер:');
      console.log(`- Название: ${playwrightData.name}`);
      console.log(`- Цена: ${playwrightData.price}`);
      console.log(`- Оригинальная цена: ${playwrightData.originalPrice || 'N/A'}`);
      console.log(`- Успешно: ${playwrightData.success}`);
      
      console.log('\nРазница во времени:');
      const timeDiff = seleniumTime - playwrightTime;
      console.log(`${timeDiff > 0 ? 'Playwright быстрее на' : 'Selenium быстрее на'} ${Math.abs(timeDiff).toFixed(2)} секунд`);
      
    } catch (error) {
      console.error(`Ошибка при тестировании парсера для ${marketplace}:`, error.message);
    }
  }
  
  console.log('\n=== Тестирование завершено ===');
}

// Запуск тестирования
testParsers().catch(error => {
  console.error('Необработанная ошибка:', error);
  process.exit(1);
}); 