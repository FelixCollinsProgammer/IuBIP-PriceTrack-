import puppeteer from 'puppeteer';
import { Browser, Page, HTTPRequest, ConsoleMessage, Dialog } from 'puppeteer';
import axios from 'axios';
import { PythonParserService } from './PythonParserService';

// Define the interface here
interface ProductDetails {
  name: string;
  price: number;
  imageUrl: string;
  originalPrice?: number;
  discount?: number;
}

export class ParserService {
  // Кэш для хранения последних цен продуктов
  private static productPriceCache: Map<string, number> = new Map();
  // Время последнего обновления цены для каждого URL
  private static lastUpdateTime: Map<string, Date> = new Map();
  // Кулдаун для обновления цен (30 минут)
  private readonly PRICE_UPDATE_COOLDOWN = 30 * 60 * 1000; // 30 минут в миллисекундах

  /**
   * Проверяет, можно ли обновить цену для данного URL
   */
  canUpdatePrice(url: string): boolean {
    const lastUpdate = ParserService.lastUpdateTime.get(url);
    if (!lastUpdate) return true;
    
    const now = new Date();
    const elapsed = now.getTime() - lastUpdate.getTime();
    return elapsed > this.PRICE_UPDATE_COOLDOWN;
  }

  getTimeUntilNextUpdate(url: string): number {
    const lastUpdate = ParserService.lastUpdateTime.get(url);
    if (!lastUpdate) return 0;
    
    const now = new Date();
    const elapsed = now.getTime() - lastUpdate.getTime();
    
    if (elapsed > this.PRICE_UPDATE_COOLDOWN) {
      return 0;
    }
    
    return this.PRICE_UPDATE_COOLDOWN - elapsed;
  }

  /**
   * Обновляет время последнего обновления цены
   */
  updateLastPriceTime(url: string): void {
    ParserService.lastUpdateTime.set(url, new Date());
  }

  static async parseUrl(url: string): Promise<ProductDetails> {
    console.log(`[ParserService] Starting to parse URL: ${url}`);
    
    if (!url || typeof url !== 'string') {
      console.error(`[ParserService] Invalid URL provided: ${url}`);
      return {
        name: `Неизвестный товар`,
        price: 0,
        imageUrl: ParserService.getMarketplacePlaceholder('Other')
      };
    }

    // Нормализуем URL
    let validUrl = url.trim();
    
    // Добавляем протокол, если он отсутствует
    if (!validUrl.startsWith('http://') && !validUrl.startsWith('https://')) {
      validUrl = 'https://' + validUrl;
      console.log(`[ParserService] Added https:// protocol: ${validUrl}`);
    }

    try {
      // Валидация URL
      new URL(validUrl);
    } catch (err) {
      console.error(`[ParserService] Invalid URL format: ${validUrl}`, err);
      return {
        name: `Неизвестный товар`,
        price: 0,
        imageUrl: ParserService.getMarketplacePlaceholder('Other')
      };
    }
    
    // Создаем экземпляр сервиса для вызова нестатических методов
    const service = new ParserService();
    
    try {
      // Определяем маркетплейс из URL
      const marketplace = ParserService.getMarketplaceFromUrl(validUrl);

      // Проверка кулдауна - если цена была обновлена недавно, возвращаем кэшированное значение
      if (!service.canUpdatePrice(validUrl) && ParserService.productPriceCache.has(validUrl)) {
        const cachedPrice = ParserService.productPriceCache.get(validUrl)!;
        
        console.log(`[ParserService] Using cached price for ${validUrl}: ${cachedPrice}`);
        return {
          name: `Товар с ${marketplace}`,
          price: cachedPrice,
          imageUrl: ParserService.getMarketplacePlaceholder(marketplace)
        };
      }

      // Пробуем сначала использовать Selenium парсер для всех маркетплейсов
      if (validUrl.includes('ozon.ru') || validUrl.includes('wildberries.ru') || 
          validUrl.includes('wb.ru') || validUrl.includes('aliexpress')) {
        try {
          console.log(`[ParserService] Trying to parse ${marketplace} using Selenium parser`);
          const pythonResult = await PythonParserService.parseUrlWithSelenium(validUrl);
          
          // Проверяем успешность парсинга
          if (pythonResult.success && pythonResult.price > 0) {
            console.log(`[ParserService] Successfully parsed ${marketplace} with Selenium: ${pythonResult.name}, ${pythonResult.price} руб.`);
            
            // Обновляем кэш и время последнего обновления
            ParserService.productPriceCache.set(validUrl, pythonResult.price);
            service.updateLastPriceTime(validUrl);
            
            // Возвращаем результат
            return {
              name: pythonResult.name || `Товар с ${marketplace}`,
              price: pythonResult.price,
              imageUrl: pythonResult.imageUrl || ParserService.getMarketplacePlaceholder(marketplace),
              originalPrice: pythonResult.originalPrice,
              discount: pythonResult.discount
            };
          } else {
            console.log(`[ParserService] Selenium parsing failed for ${marketplace}, falling back to legacy parsers`);
          }
        } catch (error: any) {
          console.error(`[ParserService] Error using Selenium parser:`, error);
          console.log(`[ParserService] Falling back to legacy parsers`);
        }
      }
      
      // Если Selenium парсер не сработал, используем старые методы
      // Для Ozon
      if (validUrl.includes('ozon.ru')) {
        try {
          console.log('[ParserService] Trying to parse Ozon via API approach');
          const result = await service.parseOzonApi(validUrl);
          service.updateLastPriceTime(validUrl);
          return result;
        } catch (error) {
          console.log('[ParserService] Ozon API parsing failed, returning placeholder', error);
          return {
            name: `Товар с Ozon`,
            price: 0,
            imageUrl: ParserService.getMarketplacePlaceholder('Ozon')
          };
        }
      }
      
      // Для Wildberries используем API
      if (validUrl.includes('wildberries.ru') || validUrl.includes('wb.ru')) {
        try {
          console.log('[ParserService] Trying to parse Wildberries via API approach');
          const result = await service.parseWildberriesApi(validUrl);
          service.updateLastPriceTime(validUrl);
          return result;
        } catch (error) {
          console.log('[ParserService] API parsing failed, returning placeholder', error);
          return {
            name: `Товар с Wildberries`,
            price: 0,
            imageUrl: ParserService.getMarketplacePlaceholder('Wildberries')
          };
        }
      }
      
      // Для AliExpress
      if (validUrl.includes('aliexpress') || validUrl.includes('aliexpress.com')) {
        try {
          console.log('[ParserService] Trying to parse AliExpress via Puppeteer');
          const result = await service.parseWithPuppeteer(validUrl);
          service.updateLastPriceTime(validUrl);
          return result;
        } catch (error) {
          console.error('[ParserService] AliExpress parsing failed', error);
          return {
            name: `Товар с AliExpress`,
            price: 0,
            imageUrl: ParserService.getMarketplacePlaceholder('AliExpress')
          };
        }
      }

      // Для других магазинов используем заглушку
      return {
        name: `Товар с ${marketplace}`,
        price: 0,
        imageUrl: ParserService.getMarketplacePlaceholder(marketplace)
      };
    } catch (error) {
      console.error('[ParserService] Error in parseUrl:', error);
      const marketplace = ParserService.getMarketplaceFromUrl(validUrl);
      return {
        name: `Товар с ${marketplace}`,
        price: 0,
        imageUrl: ParserService.getMarketplacePlaceholder(marketplace)
      };
    }
  }

  /**
   * Парсинг URL через Puppeteer
   */
  private async parseWithPuppeteer(url: string): Promise<ProductDetails> {
    let browser: Browser | null = null;
    let page: Page | null = null;
    let maxRetries = 2;
    let retryCount = 0;
    
    while (retryCount <= maxRetries) {
      try {
        console.log(`[ParserService] Attempting to parse ${url} with Puppeteer (attempt ${retryCount + 1}/${maxRetries + 1})`);
        
        // Create Puppeteer page with proper browser initialization
        browser = await puppeteer.launch({
          headless: 'new',
          timeout: 120000,
          executablePath: process.env.PUPPETEER_EXECUTABLE_PATH || undefined,
          ignoreDefaultArgs: ['--disable-extensions'],
          args: [
            '--no-sandbox',
            '--disable-setuid-sandbox',
            '--disable-dev-shm-usage',
            '--disable-accelerated-2d-canvas',
            '--disable-gpu',
            '--window-size=1920x1080',
            '--disable-web-security',
            '--disable-features=IsolateOrigins,site-per-process',
            '--disable-extensions',
            '--disable-infobars',
            '--ignore-certificate-errors',
            '--no-first-run',
            '--disable-notifications'
          ]
        });
        
        page = await browser.newPage();
        
        // Determine marketplace and use appropriate parser
        const marketplace = ParserService.getMarketplaceFromUrl(url);
        
        // Navigation timeout handling
        const navigationPromise = page.goto(url, {
          waitUntil: 'domcontentloaded',
          timeout: 30000
        }).catch((err: Error) => {
          console.error(`[ParserService] Navigation error: ${err.message}`);
          // Even if navigation errors out, we try to continue if the page loaded partially
          return null;
        });
        
        // Add a timeout to the navigation
        const timeoutPromise = new Promise((_, reject) => 
          setTimeout(() => reject(new Error('Navigation timeout')), 40000)
        );
        
        // Wait for navigation or timeout
        await Promise.race([navigationPromise, timeoutPromise]).catch(err => {
          console.warn(`[ParserService] Navigation race condition: ${err.message}`);
        });
        
        // Take screenshot for debugging (optional)
        if (process.env.DEBUG === 'true') {
          await page.screenshot({ path: `debug_${new Date().getTime()}.png` });
        }
        
        let result: ProductDetails;
        
        // Choose the right parser based on marketplace
        switch (marketplace) {
          case 'Ozon':
            result = await this.parseOzon(page);
            break;
          case 'Wildberries':
            result = await this.parseWildberries(page);
            break;
          case 'AliExpress':
            result = await this.parseAliexpress(page);
            break;
          default:
            result = await this.parseGeneric(page);
        }
        
        // Check if we got a meaningful result
        if (result && result.name && result.price > 0) {
          // Clean up and return success
          if (browser) await browser.close();
          console.log(`[ParserService] Successfully parsed ${url} with Puppeteer: ${result.name}, ${result.price} руб.`);
          return result;
        }
        
        // If result is invalid (zero price or no name), try again
        retryCount++;
        console.warn(`[ParserService] Invalid result from parsing, retrying... (${retryCount}/${maxRetries})`);
        
        // Clean up before retry
        if (page) await page.close().catch(() => {});
        
      } catch (error) {
        console.error(`[ParserService] Error parsing ${url} with Puppeteer (attempt ${retryCount + 1}):`, error);
        retryCount++;
        
        // Clean up before retry
        if (page) await page.close().catch(() => {});
        
        // Sleep between retries
        if (retryCount <= maxRetries) {
          const sleepTime = 2000 * retryCount; // Increase sleep time with each retry
          console.log(`[ParserService] Waiting ${sleepTime}ms before next retry...`);
          await new Promise(resolve => setTimeout(resolve, sleepTime));
        }
      }
    }
    
    // If we've exhausted all retries, return a fallback
    console.error(`[ParserService] Failed to parse ${url} after ${maxRetries + 1} attempts`);
    return {
      name: `Товар с ${ParserService.getMarketplaceFromUrl(url)}`,
      price: 0,
      imageUrl: ParserService.getMarketplacePlaceholder(ParserService.getMarketplaceFromUrl(url))
    };
  }

  /**
   * Создает URL для изображения маркетплейса
   */
  static getMarketplacePlaceholder(marketplace: string): string {
    // Use actual hosted images instead of local files
    switch (marketplace.toLowerCase()) {
      case 'ozon':
        return 'https://upload.wikimedia.org/wikipedia/commons/thumb/8/82/Logo_of_Ozon.ru_%28old%29.svg/320px-Logo_of_Ozon.ru_%28old%29.svg.png';
      case 'wildberries':
        return 'https://upload.wikimedia.org/wikipedia/commons/thumb/8/88/Wildberries_logo.svg/320px-Wildberries_logo.svg.png';
      case 'aliexpress':
        return 'https://upload.wikimedia.org/wikipedia/commons/thumb/e/e1/AliExpress_logo.svg/320px-AliExpress_logo.svg.png';
      case 'amazon':
        return 'https://upload.wikimedia.org/wikipedia/commons/thumb/a/a9/Amazon_logo.svg/320px-Amazon_logo.svg.png';
      case 'yandex market':
        return 'https://upload.wikimedia.org/wikipedia/commons/thumb/5/55/Yandex_Market_logo.svg/320px-Yandex_Market_logo.svg.png';
      default:
        // For unknown marketplaces use a generic placeholder
        return 'https://cdn-icons-png.flaticon.com/512/3176/3176363.png';
    }
  }

  /**
   * Определяет маркетплейс из URL
   */
  static getMarketplaceFromUrl(url: string): string {
    try {
      // Преобразуем URL в нижний регистр для унификации
      const lowercaseUrl = url.toLowerCase();
      
      // Проверка на основные маркетплейсы по вхождению в URL
      if (lowercaseUrl.includes('ozon.ru')) {
        return 'Ozon';
      }
      
      if (lowercaseUrl.includes('wildberries.ru') || lowercaseUrl.includes('wb.ru')) {
        return 'Wildberries';
      }
      
      if (lowercaseUrl.includes('aliexpress.ru') || lowercaseUrl.includes('aliexpress.com')) {
        return 'AliExpress';
      }
      
      if (lowercaseUrl.includes('amazon.') || lowercaseUrl.includes('amzn.')) {
        return 'Amazon';
      }
      
      if (lowercaseUrl.includes('yandex.market') || lowercaseUrl.includes('market.yandex')) {
        return 'Yandex Market';
      }
      
      // Если не нашли соответствие, пробуем получить домен
      try {
        const domain = new URL(url).hostname.replace('www.', '');
        // Возвращаем домен с большой буквы для первого слова
        return domain.split('.')[0].charAt(0).toUpperCase() + domain.split('.')[0].slice(1);
      } catch (e) {
        console.error('Error parsing URL domain:', e);
        return 'Other';
      }
    } catch (e) {
      console.error('Error determining marketplace from URL:', e);
      return 'Other';
    }
  }

  /**
   * Парсинг Wildberries через API
   */
  private async parseWildberriesApi(url: string): Promise<ProductDetails> {
    console.log('[ParserService] Parsing Wildberries via API');
    
    try {
      // Извлекаем ID товара из URL
      const matches = url.match(/wildberries\.ru\/catalog\/(\d+)\/detail/);
      let productId = matches ? matches[1] : null;
      
      if (!productId) {
        // Альтернативный способ извлечения ID товара
        const altMatches = url.match(/wildberries\.ru\/[a-z]+\/product\?card=(\d+)/);
        productId = altMatches ? altMatches[1] : null;
        
        // Попробуем третий формат URL
        if (!productId) {
          const thirdMatches = url.match(/wb\.ru\/([^/]+)\/detail\/([^/]+)/);
          if (thirdMatches) {
            // Попытка извлечь ID из URL формата wb.ru
            // Для этого формата часто ID находится в пути
            try {
              const fullUrl = url;
              console.log(`[ParserService] Using full URL for Wildberries: ${fullUrl}`);
              
              // Выполняем HTTP запрос для получения ID товара из содержимого страницы
              const response = await axios.get(fullUrl, {
                headers: {
                  'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                  'Accept-Language': 'ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7',
                  'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
                  'Referer': 'https://www.wildberries.ru/',
                  'sec-ch-ua': '"Not_A Brand";v="8", "Chromium";v="120", "Google Chrome";v="120"',
                  'sec-ch-ua-mobile': '?0',
                  'sec-ch-ua-platform': '"macOS"',
                  'Cache-Control': 'no-cache',
                  'Pragma': 'no-cache'
                },
                timeout: 10000
              });
              
              // Поиск ID товара в HTML
              const idMatch = response.data.match(/productCard\s*:\s*{\s*id\s*:\s*(\d+)/);
              if (idMatch && idMatch[1]) {
                productId = idMatch[1];
                console.log(`[ParserService] Extracted product ID from response: ${productId}`);
                // Убедимся, что productId не null перед вызовом
                if (productId) {
                  return this.fetchWildberriesProductById(productId);
                }
              }
              
              // Попробуем еще один формат поиска ID
              const jsMatch = response.data.match(/data-nm-id="(\d+)"/);
              if (jsMatch && jsMatch[1]) {
                productId = jsMatch[1];
                console.log(`[ParserService] Extracted product ID from nm-id attribute: ${productId}`);
                if (productId) {
                  return this.fetchWildberriesProductById(productId);
                }
              }
            } catch (error) {
              console.error('[ParserService] Error parsing Wildberries short URL:', error);
            }
          }
        }
        
        // Последняя попытка для любого URL Wildberries - попробуем puppeteer
        if (url.includes('wildberries.ru') || url.includes('wb.ru')) {
          console.log(`[ParserService] Using Puppeteer for generic Wildberries URL: ${url}`);
          try {
            return await this.parseWithPuppeteer(url);
          } catch (puppeteerError) {
            console.error('[ParserService] Puppeteer parsing failed:', puppeteerError);
            throw new Error('Failed to parse Wildberries URL with Puppeteer');
          }
        }
        
        throw new Error('Could not extract product ID from Wildberries URL');
      }
      
      // Используем извлеченный ID для запроса к API
      if (typeof productId === 'string') {
        return this.fetchWildberriesProductById(productId);
      } else {
        throw new Error('Invalid product ID: productId is null');
      }
    } catch (error) {
      console.error('[ParserService] Error parsing Wildberries API:', error);
      throw error;
    }
  }
  
  private async fetchWildberriesProductById(productId: string): Promise<ProductDetails> {
    try {
      // Используем Wildberries API для получения данных о товаре
      console.log(`[ParserService] Fetch product ${productId} from Wildberries API`);
      
      // Используем новый API эндпоинт, более устойчивый к блокировкам
      const apiUrls = [
        `https://card.wb.ru/cards/detail?nm=${productId}`,
        `https://wbxcatalog-ru.wildberries.ru/nm-2-card/catalog/${productId}/detail.json`,
        `https://wbx-content-v2.wbstatic.net/ru/${productId}.json`
      ];
      
      let response = null;
      let successUrl = '';
      
      // Пробуем разные эндпоинты для получения данных
      for (const apiUrl of apiUrls) {
        try {
          response = await axios.get(apiUrl, {
            headers: {
              'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
              'Accept-Language': 'ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7',
              'Accept': 'application/json',
              'Referer': `https://www.wildberries.ru/catalog/${productId}/detail.aspx`,
              'Origin': 'https://www.wildberries.ru',
              'sec-ch-ua': '"Not_A Brand";v="8", "Chromium";v="120", "Google Chrome";v="120"',
              'sec-ch-ua-mobile': '?0',
              'sec-ch-ua-platform': '"macOS"'
            },
            timeout: 5000
          });
          
          if (response.data && 
              ((response.data.data && response.data.data.products) || 
               (response.data.data && response.data.data.nm) || 
               response.data.name)) {
            successUrl = apiUrl;
            break;
          }
        } catch (e) {
          console.log(`[ParserService] Failed to fetch from ${apiUrl}, trying next`);
        }
      }
      
      if (!response || !successUrl) {
        console.log('[ParserService] All API endpoints failed, trying Puppeteer');
        return this.parseWildberries(await this.createPuppeteerPage(`https://www.wildberries.ru/catalog/${productId}/detail.aspx`));
      }
      
      console.log(`[ParserService] Successfully fetched data from ${successUrl}`);
      
      // Проверяем ответ API в зависимости от формата
      if (successUrl.includes('card.wb.ru')) {
        if (response.data && response.data.data && response.data.data.products && response.data.data.products.length > 0) {
          const product = response.data.data.products[0];
          
          // Извлекаем цену из ответа
          const price = product.salePriceU ? (product.salePriceU / 100) : (product.priceU / 100);
          const name = product.name || `Товар ${productId} с Wildberries`;
          const imageUrl = product.pics && product.pics.length > 0 
            ? `https://images.wbstatic.net/big/new/${Math.floor(Number(productId) / 10000)}0000/${productId}-1.jpg`
            : ParserService.getMarketplacePlaceholder('Wildberries');
          
          console.log(`[ParserService] Successfully parsed Wildberries product: ID=${productId}, Name=${name}, Price=${price}`);
          
          return {
            name,
            price,
            imageUrl
          };
        }
      } else if (successUrl.includes('wbxcatalog-ru')) {
        if (response.data && response.data.data && response.data.data.nm) {
          const product = response.data.data.nm;
          
          const price = product.sale > 0 ? product.price * (1 - product.sale/100) : product.price;
          const name = product.name || `Товар ${productId} с Wildberries`;
          const imageUrl = `https://images.wbstatic.net/big/new/${Math.floor(Number(productId) / 10000)}0000/${productId}-1.jpg`;
          
          return { name, price, imageUrl };
        }
      } else if (successUrl.includes('wbx-content-v2')) {
        if (response.data && response.data.name) {
          // Этот эндпоинт не содержит цену, будем парсить через Puppeteer
          const name = response.data.name;
          return this.parseWildberries(await this.createPuppeteerPage(`https://www.wildberries.ru/catalog/${productId}/detail.aspx`));
        }
      }
      
      console.error('[ParserService] Invalid response from Wildberries API, using fallback');
      // Если не удалось получить данные через API, возвращаем заглушку с нулевой ценой
      return {
        name: `Товар ${productId} с Wildberries`,
        price: 0,
        imageUrl: ParserService.getMarketplacePlaceholder('Wildberries')
      };
    } catch (error) {
      console.error('[ParserService] Error fetching Wildberries product data:', error);
      throw error;
    }
  }

  /**
   * Создает и настраивает страницу в Puppeteer с необходимыми параметрами
   */
  private async createPuppeteerPage(url: string): Promise<Page> {
    let browser: Browser | null = null;
    
    try {
      // Массив User-Agent для ротации
      const userAgents = [
        'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Safari/605.1.15',
        'Mozilla/5.0 (iPhone; CPU iPhone OS 17_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/120.0.6099.101 Mobile/15E148 Safari/604.1',
        'Mozilla/5.0 (iPad; CPU OS 17_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Mobile/15E148 Safari/604.1'
      ];
      
      browser = await puppeteer.launch({
        headless: 'new',
        timeout: 120000,
        executablePath: process.env.PUPPETEER_EXECUTABLE_PATH || undefined,
        ignoreDefaultArgs: ['--disable-extensions'],
        args: [
          '--no-sandbox',
          '--disable-setuid-sandbox',
          '--disable-dev-shm-usage',
          '--disable-accelerated-2d-canvas',
          '--disable-gpu',
          '--window-size=1920x1080',
          '--disable-web-security',
          '--disable-features=IsolateOrigins,site-per-process',
          '--disable-extensions',
          '--disable-infobars',
          '--ignore-certificate-errors',
          '--no-first-run',
          '--disable-notifications'
        ]
      });
      
      const page = await browser.newPage();
      
      // Установка более длительных таймаутов
      page.setDefaultTimeout(60000); // Увеличиваем с 30000 до 60000
      page.setDefaultNavigationTimeout(60000); // Увеличиваем с 30000 до 60000
      
      // Установка HTTP-заголовков для эмуляции реального браузера
      await page.setExtraHTTPHeaders({
        'Accept-Language': 'ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7',
        'User-Agent': userAgents[Math.floor(Math.random() * userAgents.length)],
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
        'Referer': 'https://www.google.com/',
        'Sec-Fetch-Site': 'same-origin',
        'Sec-Fetch-Mode': 'navigate',
        'Sec-Fetch-User': '?1',
        'Sec-Fetch-Dest': 'document',
        'Sec-Ch-Ua': '"Not_A Brand";v="8", "Chromium";v="120", "Google Chrome";v="120"',
        'Sec-Ch-Ua-Mobile': '?0',
        'Sec-Ch-Ua-Platform': '"macOS"',
        'Cache-Control': 'no-cache',
        'Pragma': 'no-cache'
      });
      
      // Эмулируем мобильное устройство для некоторых сайтов, если это поможет
      if (url.includes('aliexpress') || url.includes('wildberries') || Math.random() > 0.5) {
        await page.setUserAgent('Mozilla/5.0 (iPhone; CPU iPhone OS 14_7_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.1.2 Mobile/15E148 Safari/604.1');
        
        // Устанавливаем viewport как у телефона
        await page.setViewport({
          width: 390,
          height: 844,
          deviceScaleFactor: 2,
          isMobile: true,
          hasTouch: true
        });
      } else {
        // Устанавливаем desktop viewport
        await page.setViewport({
          width: 1280,
          height: 800,
          deviceScaleFactor: 1,
          isMobile: false,
          hasTouch: false
        });
      }
      
      // Настраиваем перехват запросов для блокировки ненужных ресурсов
      await page.setRequestInterception(true);
      page.on('request', (request: HTTPRequest) => {
        const resourceType = request.resourceType();
        const url = request.url();
        
        // Блокируем ненужные ресурсы и некоторые трекеры
        if (['image', 'media', 'font'].includes(resourceType) || 
            url.includes('google-analytics') || 
            url.includes('metrika') || 
            url.includes('facebook') || 
            url.includes('tracking')) {
          request.abort('blockedbyclient');
        } else {
          request.continue();
        }
      });
      
      // Подавляем ошибки для заблокированных ресурсов
      page.on('requestfailed', (request: HTTPRequest) => {
        const failure = request.failure();
        if (failure && failure.errorText === 'net::ERR_FAILED') {
          const url = request.url();
          // Игнорируем ошибки для заблокированных ресурсов
          if (url.includes('.jpg') || url.includes('.png') || url.includes('.gif') || 
              url.includes('.woff') || url.includes('.ttf') || url.includes('.mp4') || 
              url.includes('.css') || url.includes('google-analytics') || 
              url.includes('metrika') || url.includes('facebook')) {
            return;
          }
        }
        
        const errorText = request.failure()?.errorText || 'Unknown error';
        console.error(`[ParserService] Request failed: ${request.url()}, Error: ${errorText}`);
      });
      
      // Обработчики событий страницы
      page.on('error', (error: Error) => {
        console.error('[ParserService] Page error:', error);
      });
      
      page.on('console', (msg: ConsoleMessage) => {
        if (msg.type() === 'error') {
          const text = msg.text();
          // Фильтруем ошибки загрузки заблокированных ресурсов
          if (text.includes('net::ERR_FAILED') && 
              (text.includes('.jpg') || text.includes('.png') || text.includes('.gif') || 
               text.includes('.woff') || text.includes('.ttf') || text.includes('.mp4') || 
               text.includes('.css') || text.includes('google-analytics') || 
               text.includes('metrika') || text.includes('facebook'))) {
            return; // Игнорируем эти ошибки
          }
          console.log('[ParserService] Console error:', msg.text());
        }
      });
      
      // Обработка диалоговых окон
      page.on('dialog', async (dialog: Dialog) => {
        console.log('[ParserService] Dialog appeared:', dialog.type(), dialog.message());
        await dialog.dismiss().catch((e: Error) => console.error('[ParserService] Error dismissing dialog:', e));
      });
      
      try {
        await page.goto(url, { 
          waitUntil: 'domcontentloaded',
          timeout: 30000 
        });
        
        // Дополнительная задержка для загрузки динамического контента
        await page.waitForTimeout(3000);
        
        return page;
      } catch (navigationError) {
        console.error('[ParserService] Navigation error:', navigationError);
        
        // Если навигация не удалась, попробуем еще раз с другими параметрами
        try {
          console.log('[ParserService] Retrying navigation with different parameters');
          await page.goto(url, { 
            waitUntil: 'networkidle2',
            timeout: 45000 
          });
          await page.waitForTimeout(2000);
          return page;
        } catch (retryError) {
          console.error('[ParserService] Retry navigation failed:', retryError);
          // Закрываем браузер при неудаче
          if (browser) await browser.close().catch((e: Error) => {});
          throw new Error(`Navigation to ${url} failed after retry`);
        }
      }
    } catch (error: any) {
      console.error(`[ParserService] Error creating Puppeteer page: ${error.message}`);
      if (browser) await browser.close().catch((e: Error) => {});
      throw error;
    }
  }

  /**
   * Парсинг Ozon через API
   */
  private async parseOzonApi(url: string): Promise<ProductDetails> {
    // Проверяем, является ли URL коротким
    if (url.includes('clck.ru') || url.includes('oz.ru') || url.includes('ozon.ru/t/')) {
      const response = await axios.get(url, {
        maxRedirects: 5,
        headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36' }
      });
      url = response.request.res.responseUrl || url;
    }
    
    // Извлекаем ID товара из URL
    const idMatch1 = url.match(/product\/(\d+)/);
    const idMatch2 = url.match(/-(\d+)\/?$/);
    const productId = idMatch1 ? idMatch1[1] : idMatch2 ? idMatch2[1] : null;
    
    if (!productId) {
      throw new Error('Could not extract product ID from URL');
    }
    
    try {
      const productDetails = await this.fetchOzonProductData(productId);
      return productDetails;
    } catch (error) {
      console.error('[ParserService] Error fetching Ozon product data:', error);
      return this.parseWithPuppeteer(url);
    }
  }

  /**
   * Получает данные о товаре Ozon по API
   */
  private async fetchOzonProductData(productId: string): Promise<ProductDetails> {
    // Rotate User-Agents for better success rate
    const userAgents = [
      'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
      'Mozilla/5.0 (iPhone; CPU iPhone OS 14_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.0.3 Mobile/15E148 Safari/604.1',
      'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.1.1 Safari/605.1.15',
      'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.107 Safari/537.36'
    ];
    
    const randomUserAgent = userAgents[Math.floor(Math.random() * userAgents.length)];
    
    // Try multiple API endpoints
    const apiEndpoints = [
      `https://api.ozon.ru/composer-api.bx/page/json/v1?url=/product/${productId}`,
      `https://www.ozon.ru/api/composer-api.bx/page/json/v1?url=/product/${productId}`,
      `https://m.ozon.ru/api/composer-api.bx/page/json/v1?url=/product/${productId}`
    ];
    
    let lastError = null;
    
    for (const apiUrl of apiEndpoints) {
      try {
        console.log(`Trying Ozon API endpoint: ${apiUrl}`);
        
        const response = await axios.get(apiUrl, {
          headers: {
            'User-Agent': randomUserAgent,
            'Accept': 'application/json',
            'Accept-Language': 'ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7',
            'Referer': `https://ozon.ru/product/${productId}`,
            'sec-ch-ua': '"Not_A Brand";v="8", "Chromium";v="120", "Google Chrome";v="120"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"macOS"'
          },
          timeout: 10000,
          maxRedirects: 5
        });
        
        const data = response.data;
        const widgets = data?.widgetStates || {};
        
        // Search for product data in widgets
        let productName = '';
        let productPrice = 0;
        let imageUrl = '';
        let originalPrice = 0;
        
        // Process all widgets to find product info
        for (const key in widgets) {
          try {
            let parsedData;
            // Only try to parse if it's a string
            if (typeof widgets[key] === 'string') {
              parsedData = JSON.parse(widgets[key]);
            } else {
              parsedData = widgets[key];
            }
            
            // Extract product title
            if ((key.includes('webProductHeading') || key.includes('webOzonTitle') || 
                 key.includes('nameDetail') || key.includes('title')) && 
                parsedData.title) {
              productName = parsedData.title;
            }
            
            // Extract product price
            if ((key.includes('webPrice') || key.includes('webOzonPrice') || 
                 key.includes('priceDetail') || key.includes('price')) && 
                (parsedData.price || parsedData.priceText)) {
              const priceText = parsedData.price || parsedData.priceText || '';
              productPrice = parseInt(priceText.toString().replace(/[^\d]/g, ''));
              
              // Extract original price if available
              if (parsedData.originalPrice || parsedData.oldPrice) {
                const oldPriceText = parsedData.originalPrice || parsedData.oldPrice || '';
                originalPrice = parseInt(oldPriceText.toString().replace(/[^\d]/g, ''));
              }
            }
            
            // Extract image URL
            if ((key.includes('webGallery') || key.includes('webOzonGallery') || 
                 key.includes('gallery') || key.includes('images')) && 
                parsedData.images && parsedData.images.length > 0) {
              imageUrl = parsedData.images[0].src || parsedData.images[0].url || '';
            }
          } catch (e) {
            // Ignore parsing errors for individual widgets
          }
        }
        
        // Validate extracted data
        if (productName && productPrice > 0) {
          // Save to cache
          ParserService.productPriceCache.set(`https://ozon.ru/product/${productId}`, productPrice);
          
          return {
            name: productName,
            price: productPrice,
            imageUrl: imageUrl || ParserService.getMarketplacePlaceholder('Ozon'),
            originalPrice: originalPrice > 0 ? originalPrice : undefined,
            discount: originalPrice > 0 ? Math.round(((originalPrice - productPrice) / originalPrice) * 100) : undefined
          };
        }
      } catch (error) {
        console.error(`Error with Ozon API endpoint ${apiUrl}:`, error);
        lastError = error;
      }
    }
    
    // If we reach here, all API attempts failed
    console.log('All Ozon API attempts failed, falling back to Puppeteer');
    throw lastError || new Error('Could not extract product data from any API response');
  }

  /**
   * Парсинг Ozon через Puppeteer
   */
  private async parseOzon(page: Page): Promise<ProductDetails> {
    try {
      // Ждем загрузки страницы
      await page.waitForSelector('h1', { timeout: 10000 }).catch(() => {});
      
      // Проверяем, есть ли капча или блокировка
      const isCaptcha = await page.evaluate(() => {
        return document.body.textContent?.includes('captcha') || 
               document.body.textContent?.includes('blocked') ||
               document.body.textContent?.includes('робот');
      });
      
      if (isCaptcha) {
        throw new Error('Captcha or blocking detected');
      }
      
      // Получаем название товара
      const name = await page.evaluate(() => {
        const h1 = document.querySelector('h1');
        return h1 ? h1.textContent?.trim() : '';
      });
      
      // Получаем цену
      const price = await page.evaluate(() => {
        // Пробуем различные селекторы для цены
        const selectors = [
          'span[data-widget="webPrice"] span.price-final-price',
          'div[data-widget="webPrice"] span.price-final-price',
          'div[data-widget="webPrice"] .price-block span',
          'div[data-widget="webPrice"] span',
          '.price-block span'
        ];
        
        for (const selector of selectors) {
          const priceElement = document.querySelector(selector);
          if (priceElement && priceElement.textContent) {
            const text = priceElement.textContent.trim();
            const match = text.replace(/\s+/g, '').match(/\d+/);
            if (match) {
              return parseInt(match[0]);
            }
          }
        }
        
        return 0;
      });
      
      // Получаем изображение
      const imageUrl = await page.evaluate(() => {
        const imgSelector = 'div[data-widget="webGallery"] img';
        const img = document.querySelector(imgSelector);
        return img ? img.getAttribute('src') : '';
      });
      
      return {
        name: name || 'Товар с Ozon',
        price: price || 0,
        imageUrl: imageUrl || ParserService.getMarketplacePlaceholder('Ozon')
      };
    } catch (error) {
      console.error('[ParserService] Error parsing Ozon with Puppeteer:', error);
      return {
        name: 'Товар с Ozon',
        price: 0,
        imageUrl: ParserService.getMarketplacePlaceholder('Ozon')
      };
    }
  }

  /**
   * Парсинг Wildberries через Puppeteer
   */
  private async parseWildberries(page: Page): Promise<ProductDetails> {
    try {
      // Ждем загрузки страницы
      await page.waitForSelector('h1', { timeout: 10000 }).catch(() => {});
      
      // Получаем название товара
      const name = await page.evaluate(() => {
        const h1 = document.querySelector('h1');
        return h1 ? h1.textContent?.trim() : '';
      });
      
      // Получаем цену
      const price = await page.evaluate(() => {
        // Пробуем различные селекторы для цены
        const selectors = [
          'ins.price-block__final-price',
          'span.price-block__final-price',
          '.price-block__price-wrap ins',
          '.price-block__price'
        ];
        
        for (const selector of selectors) {
          const priceElement = document.querySelector(selector);
          if (priceElement && priceElement.textContent) {
            const text = priceElement.textContent.trim();
            const match = text.replace(/\s+/g, '').match(/\d+/);
            if (match) {
              return parseInt(match[0]);
            }
          }
        }
        
        return 0;
      });
      
      // Получаем изображение
      const imageUrl = await page.evaluate(() => {
        const imgSelector = 'img.photo-zoom__preview';
        const img = document.querySelector(imgSelector);
        return img ? img.getAttribute('src') : '';
      });
      
      return {
        name: name || 'Товар с Wildberries',
        price: price || 0,
        imageUrl: imageUrl || ParserService.getMarketplacePlaceholder('Wildberries')
      };
    } catch (error) {
      console.error('[ParserService] Error parsing Wildberries with Puppeteer:', error);
      return {
        name: 'Товар с Wildberries',
        price: 0,
        imageUrl: ParserService.getMarketplacePlaceholder('Wildberries')
      };
    }
  }

  /**
   * Парсинг AliExpress через Puppeteer
   */
  private async parseAliexpress(page: Page): Promise<ProductDetails> {
    try {
      // Ждем загрузки страницы
      await page.waitForSelector('h1', { timeout: 15000 }).catch(() => {});
      
      // Получаем название товара
      const name = await page.evaluate(() => {
        // Разные селекторы для заголовка
        const selectors = ['h1', '.product-title', '.title'];
        
        for (const selector of selectors) {
          const element = document.querySelector(selector);
          if (element && element.textContent) {
            return element.textContent.trim();
          }
        }
        
        return '';
      });
      
      // Получаем цену
      const price = await page.evaluate(() => {
        // Разные селекторы для цены
        const selectors = [
          '.product-price-value',
          '.product-price',
          '.price-current'
        ];
        
        for (const selector of selectors) {
          const element = document.querySelector(selector);
          if (element && element.textContent) {
            const text = element.textContent.trim();
            const match = text.replace(/\s+/g, '').match(/[\d,.]+/);
            if (match) {
              const priceStr = match[0].replace(',', '.');
              return Math.round(parseFloat(priceStr) * 100);
            }
          }
        }
        
        return 0;
      });
      
      // Получаем изображение
      const imageUrl = await page.evaluate(() => {
        // Разные селекторы для изображений
        const selectors = [
          '.gallery-preview img',
          '.product-gallery img',
          '.magnifier-image'
        ];
        
        for (const selector of selectors) {
          const img = document.querySelector(selector);
          if (img && img.getAttribute('src')) {
            return img.getAttribute('src');
          }
        }
        
        return '';
      });
      
      return {
        name: name || 'Товар с AliExpress',
        price: price || 0,
        imageUrl: imageUrl || ParserService.getMarketplacePlaceholder('AliExpress')
      };
    } catch (error) {
      console.error('[ParserService] Error parsing AliExpress with Puppeteer:', error);
      return {
        name: 'Товар с AliExpress',
        price: 0,
        imageUrl: ParserService.getMarketplacePlaceholder('AliExpress')
      };
    }
  }

  /**
   * Парсинг других магазинов через Puppeteer
   */
  private async parseGeneric(page: Page): Promise<ProductDetails> {
    try {
      // Ждем загрузки страницы
      await page.waitForSelector('h1', { timeout: 10000 }).catch(() => {});
      
      // Получаем название товара
      const name = await page.evaluate(() => {
        const h1 = document.querySelector('h1');
        return h1 ? h1.textContent?.trim() : '';
      });
      
      // Пытаемся найти цену
      const price = await page.evaluate(() => {
        // Общие селекторы для цен
        const selectors = [
          '.price',
          '.product-price',
          '.price-current',
          '.current-price',
          '[itemprop="price"]'
        ];
        
        // Регулярное выражение для поиска чисел в строке с ценой
        const priceRegex = /[\d\s,.]+/;
        
        for (const selector of selectors) {
          const elements = document.querySelectorAll(selector);
          // Convert NodeList to Array to make it iterable
          const elementsArray = Array.from(elements);
          for (const element of elementsArray) {
            const text = element.textContent?.trim();
            if (text) {
              const match = text.match(priceRegex);
              if (match) {
                const priceText = match[0].replace(/\s+/g, '').replace(',', '.');
                return Math.round(parseFloat(priceText));
              }
            }
          }
        }
        
        return 0;
      });
      
      // Пытаемся найти изображение
      const imageUrl = await page.evaluate(() => {
        // Общие селекторы для изображений
        const selectors = [
          '.product-image img',
          '.product-photo img',
          '.gallery img',
          '[itemprop="image"]'
        ];
        
        for (const selector of selectors) {
          const img = document.querySelector(selector);
          if (img && img.getAttribute('src')) {
            return img.getAttribute('src');
          }
        }
        
        return '';
      });
      
      // Определяем домен для отображения в названии
      const domain = await page.evaluate(() => {
        return window.location.hostname;
      });
      
      return {
        name: name || `Товар с ${domain}`,
        price: price || 0,
        imageUrl: imageUrl || ParserService.getMarketplacePlaceholder('Other')
      };
    } catch (error) {
      console.error('[ParserService] Error parsing generic site with Puppeteer:', error);
      return {
        name: 'Товар',
        price: 0,
        imageUrl: ParserService.getMarketplacePlaceholder('Other')
      };
    }
  }
}