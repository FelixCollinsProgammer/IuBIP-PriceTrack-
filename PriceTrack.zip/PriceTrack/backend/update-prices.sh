#!/bin/bash

# Navigate to the project directory
cd "$(dirname "$0")"

# Run the price update script with Node.js
node dist/updatePrices.js

# Log completion
echo "$(date) - Price update completed" >> update-prices.log 