#!/bin/bash

# Script to set up Selenium parser for PriceTrack
# This script will install Python, pip, Selenium, and WebDriver

echo "Setting up Selenium parser for PriceTrack..."

# Check if Python is installed
if ! command -v python3 &> /dev/null; then
    echo "Python 3 not found. Please install Python 3 before running this script."
    exit 1
fi

# Check Python version
PYTHON_VERSION=$(python3 --version 2>&1 | awk '{print $2}')
echo "Found Python $PYTHON_VERSION"

# Check if pip is installed
if ! command -v pip3 &> /dev/null; then
    echo "pip not found. Installing pip..."
    if [[ "$OSTYPE" == "linux-gnu"* ]]; then
        sudo apt-get update
        sudo apt-get install -y python3-pip
    elif [[ "$OSTYPE" == "darwin"* ]]; then
        # macOS
        curl https://bootstrap.pypa.io/get-pip.py -o get-pip.py
        python3 get-pip.py
        rm get-pip.py
    else
        echo "Unsupported OS. Please install pip manually."
        exit 1
    fi
fi

# Install required Python packages
echo "Installing required Python packages..."
pip3 install selenium webdriver-manager

# Install ChromeDriver using webdriver-manager
python3 -c "
from selenium import webdriver
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.chrome.service import Service
import os

# Create a temp script to verify ChromeDriver installation
with open('test_selenium.py', 'w') as f:
    f.write('''
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.chrome.service import Service

# Set up Chrome options
options = Options()
options.add_argument('--headless=new')
options.add_argument('--no-sandbox')
options.add_argument('--disable-dev-shm-usage')

# Install and configure ChromeDriver
service = Service(ChromeDriverManager().install())

# Create driver
try:
    driver = webdriver.Chrome(service=service, options=options)
    print('ChromeDriver initialized successfully!')
    driver.quit()
except Exception as e:
    print(f'Error initializing ChromeDriver: {e}')
''')

print('Installing ChromeDriver...')
ChromeDriverManager().install()
print('ChromeDriver installed successfully!')
"

# Test Selenium installation
echo "Testing Selenium installation..."
python3 test_selenium.py
rm test_selenium.py

# Make the Selenium parser executable
chmod +x "$(dirname "$0")/selenium_parser.py"

echo "Selenium parser setup complete!"
echo "You can now use the parser with command: python3 selenium_parser.py --url \"https://example.com/product\"" 