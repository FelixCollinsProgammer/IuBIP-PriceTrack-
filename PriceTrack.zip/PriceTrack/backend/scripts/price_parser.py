#!/usr/bin/env python3
import sys
import json
import asyncio
import re
import argparse
from playwright.async_api import async_playwright
from urllib.parse import urlparse
import random
import time

"""
Скрипт для парсинга цен товаров с различных маркетплейсов.
Использует Playwright для рендеринга страниц с JavaScript и извлечения данных.

Пример использования:
python price_parser.py --url "https://www.ozon.ru/product/smartfon-xiaomi-redmi-12-8-256gb-graphite-gray-global-version-1171511903/"
"""

async def extract_ozon_price(page):
    """Извлекает цену и прочую информацию о товаре с Ozon"""
    try:
        # Ожидаем загрузки страницы
        await page.wait_for_load_state("networkidle", timeout=15000)
        
        # Делаем снимок экрана для отладки
        await page.screenshot(path="ozon_debug.png")
        
        # Проверка на блокировку или капчу
        if await page.locator("text=/капч|captcha|robot|робот/i").count() > 0:
            print("Обнаружена капча на странице Ozon", file=sys.stderr)
            return {
                "success": False,
                "error": "Captcha обнаружена на странице"
            }
        
        # Название товара - пробуем разные селекторы
        name = ""
        for selector in [
            'h1[data-widget="webProductHeading"]', 
            'h1',
            'div[data-widget="webProductHeading"]',
            '.jn0 h1',
        ]:
            try:
                if await page.locator(selector).count() > 0:
                    name = await page.locator(selector).first.text_content()
                    name = name.strip()
                    break
            except:
                continue
        
        if not name:
            print("Не удалось найти название товара на Ozon", file=sys.stderr)
        
        # Тестируем наличие базовых элементов страницы
        price_found = False
        current_price = None
        
        # Пробуем разные селекторы для актуальной цены
        price_selectors = [
            "div[data-widget='webPrice'] span.ln-c",
            "div[data-widget='webPrice'] span.c2h5",
            ".o3n span",
            ".jn3 span",
            ".ln3 span",
            "span[data-widget='webOzonPrice']",
            "span[data-widget='webPrice']",
            "div[data-widget='webPrice'] span",
            ".ln-c span",
            ".c2h5 span",
            ".lj5 span",
            "span.c2h5"
        ]
        
        # Проверяем наличие каждого селектора
        for selector in price_selectors:
            try:
                if await page.locator(selector).count() > 0:
                    await page.evaluate(f"console.log('Найден селектор: {selector}')")
                    
                    # Скроллим к элементу, чтобы убедиться, что он виден
                    await page.locator(selector).first.scroll_into_view_if_needed()
                    await asyncio.sleep(1)
                    
                    # Получаем текст и обрабатываем его
                    price_text = await page.locator(selector).first.text_content()
                    if price_text:
                        # Извлекаем только цифры из строки и преобразуем в число
                        price_text = price_text.strip()
                        price_numbers = re.sub(r'[^\d]', '', price_text)
                        if price_numbers:
                            current_price = int(price_numbers)
                            price_found = True
                            print(f"Найдена цена по селектору {selector}: {current_price}", file=sys.stderr)
                            break
            except Exception as e:
                print(f"Ошибка при извлечении цены с селектором {selector}: {str(e)}", file=sys.stderr)
                continue
                
        # Если не нашли цену через селекторы, пробуем искать в HTML страницы через JS
        if not price_found:
            try:
                # Извлекаем весь текст страницы
                body_text = await page.evaluate("document.body.innerText")
                
                # Ищем цену с помощью регулярного выражения
                price_matches = re.findall(r'(\d{1,3}(?:\s?\d{3})*)\s?₽', body_text)
                if price_matches:
                    price_text = price_matches[0]
                    price_numbers = re.sub(r'[^\d]', '', price_text)
                    if price_numbers:
                        current_price = int(price_numbers)
                        price_found = True
                        print(f"Найдена цена через регулярное выражение: {current_price}", file=sys.stderr)
            except Exception as e:
                print(f"Ошибка при поиске цены через регулярное выражение: {str(e)}", file=sys.stderr)
                
        # Если цена все еще не найдена, пробуем найти её в JS-данных страницы
        if not price_found:
            try:
                # Ищем цену в JS-данных на странице
                price_data = await page.evaluate("""() => {
                    try {
                        // Поиск в window.__NUXT__
                        if (window.__NUXT__ && window.__NUXT__.state && window.__NUXT__.state.product) {
                            return window.__NUXT__.state.product.price || window.__NUXT__.state.product.currentPrice;
                        }
                        
                        // Поиск в window.__INITIAL_STATE__
                        if (window.__INITIAL_STATE__ && window.__INITIAL_STATE__.pdp) {
                            return window.__INITIAL_STATE__.pdp.currentPrice || window.__INITIAL_STATE__.pdp.price;
                        }
                        
                        // Поиск в data-атрибутах элементов
                        const priceElements = document.querySelectorAll('[data-price]');
                        if (priceElements.length > 0) {
                            return priceElements[0].getAttribute('data-price');
                        }
                        
                        return null;
                    } catch (e) {
                        console.error('Ошибка при поиске цены в JS-данных:', e);
                        return null;
                    }
                }""")
                
                if price_data and isinstance(price_data, (int, float, str)):
                    if isinstance(price_data, str):
                        price_data = re.sub(r'[^\d]', '', price_data)
                    
                    if price_data:
                        current_price = int(price_data)
                        price_found = True
                        print(f"Найдена цена через JS-данные: {current_price}", file=sys.stderr)
            except Exception as e:
                print(f"Ошибка при поиске цены в JS-данных: {str(e)}", file=sys.stderr)
                
        # Если цена не найдена, возвращаем ошибку
        if not price_found or not current_price:
            print("Не удалось извлечь цену", file=sys.stderr)
            return {
                "success": False,
                "error": "Не удалось извлечь цену"
            }
                
        # Ищем старую цену (до скидки)
        original_price = None
        try:
            old_price_selectors = [
                "div[data-widget='webPrice'] span.jn1",
                "div[data-widget='webPrice'] span.c2m7",
                "div[data-widget='webPrice'] span[class*='old']",
                "div[data-widget='webPrice'] span.lk3",
                "div[data-widget='webPrice'] span.ly2",
                "span.lk3",
                "span.ly2"
            ]
            
            for selector in old_price_selectors:
                if await page.locator(selector).count() > 0:
                    old_price_text = await page.locator(selector).first.text_content()
                    if old_price_text:
                        old_price_numbers = re.sub(r'[^\d]', '', old_price_text)
                        if old_price_numbers:
                            original_price = int(old_price_numbers)
                            break
        except Exception as e:
            print(f"Ошибка при извлечении оригинальной цены: {str(e)}", file=sys.stderr)
            # Это не критическая ошибка, продолжаем
        
        # URL изображения товара
        image_url = ""
        try:
            # Пробуем разные способы получения изображения
            image_selectors = [
                "div[data-widget='webGallery'] img",
                ".jn2 img",
                ".jn9 img",
                ".lo7 img",
                "img.lj2",
                "img[src*='product']",
                "img[src*='goods']"
            ]
            
            for selector in image_selectors:
                if await page.locator(selector).count() > 0:
                    image_url = await page.locator(selector).first.get_attribute("src")
                    if image_url:
                        if not image_url.startswith("http"):
                            image_url = "https:" + image_url
                        break
                    
            # Если изображение не найдено, используем заглушку
            if not image_url:
                image_url = "https://static.tildacdn.com/tild3737-3832-4261-b562-303730636233/Ozon_logo_main.png"
        except Exception as e:
            print(f"Ошибка при извлечении URL изображения: {str(e)}", file=sys.stderr)
            image_url = "https://static.tildacdn.com/tild3737-3832-4261-b562-303730636233/Ozon_logo_main.png"
        
        # Рассчитываем скидку, если есть оригинальная цена
        discount = None
        if original_price and original_price > current_price:
            discount = round(100 - (current_price / original_price * 100))
        
        return {
            "success": True,
            "name": name,
            "price": current_price,
            "image_url": image_url,
            "original_price": original_price,
            "discount": discount
        }
    except Exception as e:
        print(f"Ошибка при парсинге Ozon: {str(e)}", file=sys.stderr)
        return {
            "success": False,
            "error": str(e)
        }

async def extract_wildberries_price(page):
    """Извлекает цену и всю доступную информацию о товаре с Wildberries"""
    try:
        # Ждем загрузки страницы и сетевой активности
        await page.wait_for_load_state("networkidle", timeout=15000)
        
        # Делаем снимок экрана для отладки
        await page.screenshot(path="wildberries_debug.png")
        
        # Проверка на блокировку или капчу
        if await page.locator("text=/капч|captcha|robot|робот/i").count() > 0:
            print("Обнаружена капча на странице Wildberries", file=sys.stderr)
            return {
                "success": False,
                "error": "Captcha обнаружена на странице"
            }
        
        # Название товара - пробуем разные селекторы и сохраняем первый успешный результат
        name = ""
        name_selectors = [
            "h1.product-page__title",
            "h1[data-link='text{:productCard.naming}']",
            "div.same-part-kt__header h1",
            "h1.same-part-kt__header",
            "div.product-page__header h1",
            "div.same-part-kt__header span",
            "h1"
        ]
        
        for selector in name_selectors:
            try:
                if await page.locator(selector).count() > 0:
                    name = await page.locator(selector).first.text_content()
                    name = name.strip()
                    print(f"Найдено название товара: {name}", file=sys.stderr)
                    break
            except Exception as e:
                print(f"Ошибка при извлечении названия с селектором {selector}: {str(e)}", file=sys.stderr)
                continue
        
        if not name:
            print("Не удалось найти название товара на Wildberries", file=sys.stderr)
            
        # Пробуем найти JS-данные о товаре
        product_data = None
        try:
            product_data = await page.evaluate("""() => {
                try {
                    // Попытка найти данные в window.app
                    if (window.app && window.app.product) {
                        return window.app.product;
                    }
                    
                    // Попытка найти данные в window.wbAppData
                    if (window.wbAppData && window.wbAppData.productData) {
                        return window.wbAppData.productData;
                    }
                    
                    // Попытка найти в data-nms
                    const nmsElement = document.querySelector('[data-nms]');
                    if (nmsElement) {
                        try {
                            return JSON.parse(nmsElement.getAttribute('data-nms'));
                        } catch (e) {
                            console.error('Ошибка парсинга data-nms', e);
                        }
                    }
                    
                    // Попытка найти в данных на странице через data-атрибуты
                    const productElements = document.querySelectorAll('[data-product-id]');
                    if (productElements.length > 0) {
                        const productId = productElements[0].getAttribute('data-product-id');
                        const priceElement = document.querySelector('[data-price]');
                        if (priceElement) {
                            return {
                                id: productId,
                                priceData: {
                                    price: priceElement.getAttribute('data-price')
                                }
                            };
                        }
                    }
                    
                    return null;
                } catch (e) {
                    console.error('Ошибка при поиске данных о товаре:', e);
                    return null;
                }
            }""")
            
            if product_data:
                print(f"Получены JS-данные о товаре: {product_data.keys() if isinstance(product_data, dict) else 'не словарь'}", file=sys.stderr)
        except Exception as e:
            print(f"Ошибка при извлечении JS-данных о товаре: {str(e)}", file=sys.stderr)
            
        # Получаем цену из JS-данных
        price_found = False
        current_price = None
        
        if product_data and isinstance(product_data, dict):
            try:
                # Пробуем различные варианты структуры данных
                if 'priceData' in product_data and 'price' in product_data['priceData']:
                    current_price = int(product_data['priceData']['price'])
                    price_found = True
                    print(f"Найдена цена через JS-данные priceData.price: {current_price}", file=sys.stderr)
                elif 'priceData' in product_data and 'currentPrice' in product_data['priceData']:
                    current_price = int(product_data['priceData']['currentPrice'])
                    price_found = True
                    print(f"Найдена цена через JS-данные priceData.currentPrice: {current_price}", file=sys.stderr)
                elif 'price' in product_data:
                    current_price = int(product_data['price'])
                    price_found = True
                    print(f"Найдена цена через JS-данные price: {current_price}", file=sys.stderr)
            except Exception as e:
                print(f"Ошибка при извлечении цены из JS-данных: {str(e)}", file=sys.stderr)
                
        # Если не нашли цену через JS, ищем через селекторы
        if not price_found:
            price_selectors = [
                "ins.price-block__final-price",
                "span.price-block__final-price",
                "span.price-block__whole-price",
                "p.price-block__price-wrap ins",
                "p[data-link='visible: productCard.priceForProduct']",
                "span.price-commission__current-price",
                "[data-tag='finalPrice']",
                ".price-block__content--active .price-block__price",
                ".same-part-kt__price-block .price-block__price",
                ".same-part-kt__price-block .price-block__final-price"
            ]
            
            for selector in price_selectors:
                try:
                    if await page.locator(selector).count() > 0:
                        price_element = page.locator(selector).first
                        await price_element.scroll_into_view_if_needed()
                        await asyncio.sleep(0.5)
                        
                        price_text = await price_element.text_content()
                        price_text = price_text.strip()
                        # Удаляем все, кроме цифр
                        price_numbers = re.sub(r'[^\d]', '', price_text)
                        if price_numbers:
                            current_price = int(price_numbers)
                            price_found = True
                            print(f"Найдена цена по селектору {selector}: {current_price}", file=sys.stderr)
                            break
                except Exception as e:
                    print(f"Ошибка при извлечении цены с селектором {selector}: {str(e)}", file=sys.stderr)
                    continue
                    
        # Если не нашли цену, пробуем искать в тексте страницы
        if not price_found:
            try:
                body_text = await page.evaluate("document.body.innerText")
                price_matches = re.findall(r'(\d{1,3}(?:\s?\d{3})*)\s?(?:₽|руб)', body_text)
                if price_matches:
                    price_text = price_matches[0]
                    price_numbers = re.sub(r'[^\d]', '', price_text)
                    if price_numbers:
                        current_price = int(price_numbers)
                        price_found = True
                        print(f"Найдена цена через регулярное выражение: {current_price}", file=sys.stderr)
            except Exception as e:
                print(f"Ошибка при поиске цены через регулярное выражение: {str(e)}", file=sys.stderr)
                
        # Если цена не найдена, возвращаем ошибку
        if not price_found or not current_price:
            print("Не удалось извлечь цену с Wildberries", file=sys.stderr)
            return {
                "success": False,
                "error": "Не удалось извлечь цену"
            }
                
        # Поиск оригинальной цены (до скидки)
        original_price = None
        try:
            old_price_selectors = [
                "del.price-block__old-price",
                "span.price-block__old-price",
                "span.price-block__base-price",
                "p.price-block__price-wrap del",
                "[data-tag='basicPrice']",
                ".price-block__content--active del.price-block__old-price"
            ]
            
            for selector in old_price_selectors:
                if await page.locator(selector).count() > 0:
                    old_price_text = await page.locator(selector).first.text_content()
                    if old_price_text:
                        old_price_numbers = re.sub(r'[^\d]', '', old_price_text)
                        if old_price_numbers:
                            original_price = int(old_price_numbers)
                            print(f"Найдена оригинальная цена: {original_price}", file=sys.stderr)
                            break
                            
            # Если не нашли через селекторы, но есть JS-данные
            if not original_price and product_data and isinstance(product_data, dict) and 'priceData' in product_data:
                if 'originalPrice' in product_data['priceData']:
                    original_price = int(product_data['priceData']['originalPrice'])
                    print(f"Найдена оригинальная цена из JS-данных originalPrice: {original_price}", file=sys.stderr)
                elif 'basicPrice' in product_data['priceData']:
                    original_price = int(product_data['priceData']['basicPrice'])
                    print(f"Найдена оригинальная цена из JS-данных basicPrice: {original_price}", file=sys.stderr)
        except Exception as e:
            print(f"Ошибка при извлечении оригинальной цены: {str(e)}", file=sys.stderr)
            # Не критическая ошибка, продолжаем
        
        # Расчет скидки, если есть оригинальная цена
        discount = None
        if original_price and original_price > current_price:
            discount = round(100 - (current_price / original_price * 100))
            print(f"Рассчитана скидка: {discount}%", file=sys.stderr)
        
        # URL изображения товара
        image_url = ""
        try:
            image_selectors = [
                "img.photo-zoom__preview",
                "img.j-zoom-image",
                "img.slide__content img",
                "img.slider__img",
                "img[alt='product image']",
                "img.img-plug",
                ".sw-slider-kt img",
                ".same-part-kt__slider img",
                ".swiper-container img"
            ]
            
            for selector in image_selectors:
                if await page.locator(selector).count() > 0:
                    image_url = await page.locator(selector).first.get_attribute("src")
                    if image_url:
                        if not image_url.startswith("http"):
                            image_url = "https:" + image_url
                        print(f"Найден URL изображения: {image_url}", file=sys.stderr)
                        break
                        
            # Если не нашли через селекторы, но есть JS-данные
            if not image_url and product_data and isinstance(product_data, dict):
                if 'media' in product_data and product_data['media'] and product_data['media']['photos']:
                    media_photo = product_data['media']['photos'][0]
                    image_url = media_photo.get('big') or media_photo.get('url')
                    if image_url and not image_url.startswith("http"):
                        image_url = "https:" + image_url
                    print(f"Найден URL изображения из JS-данных: {image_url}", file=sys.stderr)
                elif 'data' in product_data and 'images' in product_data['data'] and product_data['data']['images']:
                    image_url = product_data['data']['images'][0]
                    if image_url and not image_url.startswith("http"):
                        image_url = "https:" + image_url
                    print(f"Найден URL изображения из JS-данных data.images: {image_url}", file=sys.stderr)
        except Exception as e:
            print(f"Ошибка при извлечении URL изображения: {str(e)}", file=sys.stderr)
            # Не критическая ошибка, продолжаем
            
        # Если не нашли изображение, используем заглушку
        if not image_url:
            image_url = "https://static.wbstatic.net/i/blank.gif"
            print("Используется заглушка вместо изображения товара", file=sys.stderr)
        
        # Возвращаем результат
        return {
            "success": True,
            "name": name,
            "price": current_price,
            "image_url": image_url,
            "original_price": original_price,
            "discount": discount,
            "marketplace": "wildberries"
        }
    except Exception as e:
        print(f"Ошибка при извлечении данных с Wildberries: {str(e)}", file=sys.stderr)
        return {
            "success": False,
            "error": f"Ошибка при извлечении данных: {str(e)}"
        }

async def extract_aliexpress_price(page):
    """Извлекает цену и прочую информацию о товаре с AliExpress"""
    try:
        # Ждем загрузки страницы
        await page.wait_for_load_state("networkidle", timeout=15000)
        
        # Делаем снимок экрана для отладки
        await page.screenshot(path="aliexpress_debug.png")
        
        # Проверка на блокировку или капчу
        if await page.locator("text=/капч|captcha|robot|робот|verify/i").count() > 0:
            print("Обнаружена капча на странице AliExpress", file=sys.stderr)
            return {
                "success": False,
                "error": "Captcha обнаружена на странице"
            }
        
        # Пытаемся закрыть модальные окна, которые могут мешать
        try:
            close_buttons = [
                "button.btn-close", 
                "button.close-btn", 
                "img.close-btn", 
                "div.close-layer",
                "button._24EHh",
                "div.next-dialog-close"
            ]
            
            for selector in close_buttons:
                if await page.locator(selector).count() > 0:
                    close_button = page.locator(selector).first
                    print(f"Найдена кнопка закрытия: {selector}", file=sys.stderr)
                    await close_button.click()
                    await asyncio.sleep(0.5)
        except Exception as e:
            print(f"Ошибка при попытке закрыть модальное окно: {str(e)}", file=sys.stderr)
        
        # Пробуем найти данные через JS
        product_data = None
        try:
            product_data = await page.evaluate("""() => {
                try {
                    // Попытка найти данные в runParams
                    if (window.runParams && window.runParams.data) {
                        return window.runParams.data;
                    }
                    
                    // Попытка найти в другом месте
                    const scripts = document.querySelectorAll('script');
                    for (const script of scripts) {
                        const content = script.textContent || '';
                        if (content.includes('window\\.runParams')) {
                            const match = content.match(/window\\.runParams\\s*=\\s*({.+?});/);
                            if (match && match[1]) {
                                try {
                                    const params = JSON.parse(match[1]);
                                    if (params.data) return params.data;
                                } catch (e) {}
                            }
                        }
                        
                        // Ищем данные в формате JSON
                        if (content.includes('"formatedActivityPrice"') || content.includes('"formatedPrice"')) {
                            const match = content.match(/({[^{]*?"formatedActivityPrice"[^}]*})/);
                            if (match && match[1]) {
                                try {
                                    return JSON.parse(match[1]);
                                } catch (e) {}
                            }
                        }
                    }
                    
                    // Ищем цену в элементах DOM
                    const priceElements = {
                        current: document.querySelector('.product-price-value') || 
                                document.querySelector('.uniform-banner-box-price') ||
                                document.querySelector('.price-current'),
                        original: document.querySelector('.product-price-original') || 
                                document.querySelector('.uniform-banner-box-discounts') ||
                                document.querySelector('.price-original')
                    };
                    
                    if (priceElements.current) {
                        return {
                            priceInfo: {
                                formatedPrice: priceElements.current.textContent.trim(),
                                formatedActivityPrice: priceElements.original ? 
                                    priceElements.original.textContent.trim() : null
                            },
                            titleModule: {
                                subject: document.querySelector('h1')?.textContent.trim() ||
                                        document.title
                            },
                            imageModule: {
                                imagePathList: Array.from(document.querySelectorAll('.images-view-item img')).map(img => img.src)
                            }
                        };
                    }
                    
                    return null;
                } catch (e) {
                    console.error('Ошибка при поиске данных о товаре:', e);
                    return null;
                }
            }""")
        except Exception as e:
            print(f"Ошибка при извлечении JS-данных о товаре: {str(e)}", file=sys.stderr)
            
        # Название товара
        name = ""
        try:
            # Сначала пробуем через JS-данные
            if product_data and 'titleModule' in product_data and 'subject' in product_data['titleModule']:
                name = product_data['titleModule']['subject']
                print(f"Найдено название товара через JS-данные: {name}", file=sys.stderr)
            
            # Если не нашли через JS, ищем через селекторы
            if not name:
                name_selectors = [
                    "h1.product-title-text",
                    "h1.pdp-mod-product-title",
                    "h1",
                    "div.product-title",
                    "div.title"
                ]
                
                for selector in name_selectors:
                    if await page.locator(selector).count() > 0:
                        name_element = page.locator(selector).first
                        name = await name_element.text_content()
                        name = name.strip()
                        print(f"Найдено название товара по селектору {selector}: {name}", file=sys.stderr)
                        break
                
                # Если всё еще нет названия, берем заголовок страницы
                if not name:
                    name = await page.title()
                    print(f"Использую заголовок страницы как название: {name}", file=sys.stderr)
        except Exception as e:
            print(f"Ошибка при извлечении названия товара: {str(e)}", file=sys.stderr)
            # Пытаемся использовать заголовок страницы как запасной вариант
            try:
                name = await page.title()
            except:
                name = "Товар с AliExpress"
                
        # Ищем текущую цену
        current_price = None
        price_found = False
        
        # Сначала пробуем через JS-данные
        if product_data:
            try:
                # Вариант 1: данные в прямом формате
                if 'priceInfo' in product_data:
                    price_info = product_data['priceInfo']
                    
                    # Проверяем разные варианты хранения цены
                    if 'formatedActivityPrice' in price_info and price_info['formatedActivityPrice']:
                        price_text = price_info['formatedActivityPrice']
                    elif 'formatedPrice' in price_info and price_info['formatedPrice']:
                        price_text = price_info['formatedPrice']
                    elif 'minActivityAmount' in price_info:
                        price_text = price_info['minActivityAmount']['formatedAmount']
                    elif 'minAmount' in price_info:
                        price_text = price_info['minAmount']['formatedAmount']
                    else:
                        price_text = None
                        
                    if price_text:
                        # Извлекаем числа из строки цены
                        price_numbers = re.sub(r'[^\d\.,]', '', price_text.replace(',', '.'))
                        if price_numbers:
                            try:
                                current_price = float(price_numbers)
                                current_price = int(current_price * 100)  # Переводим в копейки и затем в целое число
                                price_found = True
                                print(f"Найдена цена через JS-данные: {current_price}", file=sys.stderr)
                            except ValueError:
                                print(f"Не удалось преобразовать строку '{price_numbers}' в число", file=sys.stderr)
            except Exception as e:
                print(f"Ошибка при извлечении цены из JS-данных: {str(e)}", file=sys.stderr)
        
        # Если не нашли через JS, ищем через селекторы
        if not price_found:
            try:
                price_selectors = [
                    "span.product-price-value",
                    "div.product-price",
                    "span.uniform-banner-box-price",
                    "span.price-current",
                    ".pdp-mod-product-price span"
                ]
                
                for selector in price_selectors:
                    if await page.locator(selector).count() > 0:
                        price_element = page.locator(selector).first
                        price_text = await price_element.text_content()
                        if price_text:
                            # Извлекаем числа из строки цены
                            price_numbers = re.sub(r'[^\d\.,]', '', price_text.replace(',', '.'))
                            if price_numbers:
                                try:
                                    current_price = float(price_numbers)
                                    current_price = int(current_price * 100)  # Переводим в копейки и затем в целое число
                                    price_found = True
                                    print(f"Найдена цена по селектору {selector}: {current_price}", file=sys.stderr)
                                    break
                                except ValueError:
                                    print(f"Не удалось преобразовать строку '{price_numbers}' в число", file=sys.stderr)
            except Exception as e:
                print(f"Ошибка при извлечении цены через селекторы: {str(e)}", file=sys.stderr)
                
        # Если не нашли цену, ищем в тексте страницы
        if not price_found:
            try:
                body_text = await page.evaluate("document.body.innerText")
                price_matches = re.findall(r'(\d{1,3}(?:[ \.,]\d{3})*(?:\.\d{2})?)\s?(?:RUB|₽|руб|USD|\$)', body_text)
                if price_matches:
                    price_text = price_matches[0]
                    price_numbers = re.sub(r'[^\d\.,]', '', price_text.replace(',', '.'))
                    if price_numbers:
                        try:
                            current_price = float(price_numbers)
                            current_price = int(current_price * 100)  # Переводим в копейки и затем в целое число
                            price_found = True
                            print(f"Найдена цена через регулярное выражение: {current_price}", file=sys.stderr)
                        except ValueError:
                            print(f"Не удалось преобразовать строку '{price_numbers}' в число", file=sys.stderr)
            except Exception as e:
                print(f"Ошибка при поиске цены через регулярное выражение: {str(e)}", file=sys.stderr)
                
        # Если цена не найдена, возвращаем ошибку
        if not price_found or not current_price:
            print("Не удалось извлечь цену с AliExpress", file=sys.stderr)
            return {
                "success": False,
                "error": "Не удалось извлечь цену"
            }
            
        # Ищем оригинальную цену (до скидки)
        original_price = None
        try:
            # Сначала ищем через JS-данные
            if product_data:
                price_info = product_data['priceInfo']
                
                if 'regularPriceShow' in price_info and price_info['regularPriceShow']:
                    price_text = price_info['regularPriceShow']
                elif 'originalPrice' in price_info and price_info['originalPrice']:
                    price_text = price_info['originalPrice']
                elif 'formatedPrice' in price_info and price_info['formatedActivityPrice']:
                    # Если есть цена со скидкой и обычная цена, то обычная - это оригинальная
                    price_text = price_info['formatedPrice']
                else:
                    price_text = None
                    
                if price_text:
                    price_numbers = re.sub(r'[^\d\.,]', '', price_text.replace(',', '.'))
                    if price_numbers:
                        try:
                            original_price = float(price_numbers)
                            original_price = int(original_price * 100)  # Переводим в копейки и затем в целое число
                            print(f"Найдена оригинальная цена через JS-данные: {original_price}", file=sys.stderr)
                        except ValueError:
                            print(f"Не удалось преобразовать строку '{price_numbers}' в число для оригинальной цены", file=sys.stderr)
            
            # Если не нашли через JS, ищем через селекторы
            if not original_price:
                original_price_selectors = [
                    "span.product-price-original",
                    "span.product-price-del",
                    "span.uniform-banner-box-discounts",
                    "span.price-original",
                    ".pdp-mod-product-price del"
                ]
                
                for selector in original_price_selectors:
                    if await page.locator(selector).count() > 0:
                        price_element = page.locator(selector).first
                        price_text = await price_element.text_content()
                        if price_text:
                            price_numbers = re.sub(r'[^\d\.,]', '', price_text.replace(',', '.'))
                            if price_numbers:
                                try:
                                    original_price = float(price_numbers)
                                    original_price = int(original_price * 100)  # Переводим в копейки и затем в целое число
                                    print(f"Найдена оригинальная цена по селектору {selector}: {original_price}", file=sys.stderr)
                                    break
                                except ValueError:
                                    print(f"Не удалось преобразовать строку '{price_numbers}' в число для оригинальной цены", file=sys.stderr)
        except Exception as e:
            print(f"Ошибка при извлечении оригинальной цены: {str(e)}", file=sys.stderr)
            # Не критическая ошибка, продолжаем
            
        # URL изображения товара
        image_url = ""
        try:
            # Сначала пробуем через JS-данные
            if product_data:
                if 'imageModule' in product_data and 'imagePathList' in product_data['imageModule'] and product_data['imageModule']['imagePathList']:
                    image_url = product_data['imageModule']['imagePathList'][0]
                    print(f"Найден URL изображения через JS-данные: {image_url}", file=sys.stderr)
                    
            # Если не нашли через JS, ищем через селекторы
            if not image_url:
                image_selectors = [
                    "img.magnifier-image",
                    "div.pdp-custom-image-container img",
                    ".images-view-list img",
                    ".product-img img",
                    "img.main-image"
                ]
                
                for selector in image_selectors:
                    if await page.locator(selector).count() > 0:
                        image_element = page.locator(selector).first
                        # Проверяем разные атрибуты
                        for attr in ['src', 'data-src', 'data-lazyload-src']:
                            attr_value = await image_element.get_attribute(attr)
                            if attr_value and not attr_value.startswith('data:'):
                                image_url = attr_value
                                print(f"Найден URL изображения по селектору {selector} и атрибуту {attr}: {image_url}", file=sys.stderr)
                                break
                        if image_url:
                            break
                            
            # Если изображение до сих пор не найдено, ищем первое достаточно большое изображение на странице
            if not image_url:
                all_images = await page.evaluate("""() => {
                    return Array.from(document.querySelectorAll('img'))
                        .filter(img => img.width > 100 && img.height > 100 && !img.src.includes('logo') && !img.src.startsWith('data:'))
                        .map(img => img.src);
                }""")
                
                if all_images and len(all_images) > 0:
                    image_url = all_images[0]
                    print(f"Найден URL изображения через поиск по всем изображениям: {image_url}", file=sys.stderr)
            
            # Если изображение не найдено, используем заглушку
            if not image_url:
                image_url = "https://ae01.alicdn.com/images/eng/wholesale/icon/aliexpress.ico"
        except Exception as e:
            print(f"Ошибка при извлечении URL изображения: {str(e)}", file=sys.stderr)
            image_url = "https://ae01.alicdn.com/images/eng/wholesale/icon/aliexpress.ico"
            
        # Рассчитываем скидку, если есть оригинальная цена
        discount = None
        if original_price and current_price and original_price > current_price:
            discount = round(100 - (current_price / original_price * 100))
            
        return {
            "success": True,
            "name": name,
            "price": current_price,
            "image_url": image_url,
            "original_price": original_price,
            "discount": discount
        }
    except Exception as e:
        print(f"Ошибка при парсинге AliExpress: {str(e)}", file=sys.stderr)
        return {
            "success": False,
            "error": str(e)
        }

async def extract_avito_price(page):
    """Извлекает цену и прочую информацию о товаре с Авито"""
    try:
        # Ждем загрузки страницы
        await page.wait_for_load_state("networkidle", timeout=15000)
        
        # Делаем снимок экрана для отладки
        await page.screenshot(path="avito_debug.png")
        
        # Проверка на блокировку или капчу
        if await page.locator("text=/капч|captcha|robot|робот|verify/i").count() > 0:
            print("Обнаружена капча на странице Авито", file=sys.stderr)
            return {
                "success": False,
                "error": "Captcha обнаружена на странице"
            }
            
        # Пытаемся закрыть различные модальные окна
        try:
            close_selectors = [
                "div.sticky-bottom-popup button",
                "div[data-marker='popup-header'] button",
                "div.popup-overlay button",
                "div.popup-header button",
                "button.desktop-w4rho1"
            ]
            
            for selector in close_selectors:
                if await page.locator(selector).count() > 0:
                    print(f"Найдена и закрывается кнопка закрытия: {selector}", file=sys.stderr)
                    await page.locator(selector).first.click()
                    await asyncio.sleep(0.5)
        except Exception as e:
            print(f"Ошибка при закрытии модальных окон: {str(e)}", file=sys.stderr)
                    
        # Пробуем получить данные через JS для лучшей надежности
        product_data = None
        try:
            product_data = await page.evaluate("""() => {
                try {
                    const data = {};
                    
                    // Пытаемся найти данные в window.__initialData
                    if (window.__initialData) {
                        return JSON.parse(window.__initialData);
                    }
                    
                    // Ищем данные в JSON-LD
                    const jsonLdEl = document.querySelector('script[type="application/ld+json"]');
                    if (jsonLdEl && jsonLdEl.textContent) {
                        try {
                            return JSON.parse(jsonLdEl.textContent);
                        } catch(e) {}
                    }
                    
                    // Собираем базовые данные из DOM
                    data.name = document.querySelector('h1')?.textContent?.trim();
                    
                    // Цена может быть в разных местах
                    const priceElement = document.querySelector('[data-marker="item-price"]') || 
                                        document.querySelector('.js-item-price') ||
                                        document.querySelector('span[itemprop="price"]');
                    
                    if (priceElement) {
                        data.price = priceElement.textContent?.trim() || 
                                    priceElement.getAttribute('content');
                    }
                    
                    // Ищем изображения
                    const images = Array.from(document.querySelectorAll('[data-marker="item-photo"] img')).map(img => img.src);
                    if (images.length > 0) {
                        data.image = images[0];
                    }
                    
                    return data;
                } catch (e) {
                    console.error('Ошибка при извлечении данных через JS:', e);
                    return null;
                }
            }""")
        except Exception as e:
            print(f"Ошибка при извлечении JS-данных: {str(e)}", file=sys.stderr)
        
        # Название товара
        name = ""
        try:
            # Сначала проверяем JS-данные
            if product_data:
                if 'name' in product_data:
                    name = product_data['name']
                elif 'itemListElement' in product_data:
                    name = product_data['itemListElement'].pop()['name']
                elif '@type' in product_data and product_data['@type'] == 'Product':
                    name = product_data['name']
                    
            # Если не нашли через JS, ищем через селекторы
            if not name:
                name_selectors = [
                    "h1.title-info-title",
                    "h1[data-marker='item-title']",
                    "h1",
                    "div.title-info"
                ]
                
                for selector in name_selectors:
                    if await page.locator(selector).count() > 0:
                        name_element = page.locator(selector).first
                        name = await name_element.text_content()
                        name = name.strip()
                        print(f"Найдено название товара по селектору {selector}: {name}", file=sys.stderr)
                        break
                        
            # Если всё еще нет названия, берем заголовок страницы
            if not name:
                name = await page.title()
                name = name.replace(" - Авито", "").strip()
                print(f"Использую заголовок страницы как название: {name}", file=sys.stderr)
        except Exception as e:
            print(f"Ошибка при извлечении названия товара: {str(e)}", file=sys.stderr)
            # Используем заголовок страницы как запасной вариант
            try:
                name = await page.title()
                name = name.replace(" - Авито", "").strip()
            except:
                name = "Товар с Авито"
                
        # Извлекаем цену
        current_price = None
        price_found = False
        
        # Сначала ищем в JS-данных
        if product_data:
            try:
                if 'price' in product_data:
                    price_text = product_data['price']
                elif 'offers' in product_data and 'price' in product_data['offers']:
                    price_text = product_data['offers']['price']
                elif '@type' in product_data and product_data['@type'] == 'Product' and 'offers' in product_data:
                    price_text = product_data['offers']['price']
                else:
                    price_text = None
                    
                if price_text:
                    # Если это строка, извлекаем числа
                    if isinstance(price_text, str):
                        price_numbers = re.sub(r'[^\d\.,]', '', price_text.replace(',', '.'))
                        try:
                            current_price = float(price_numbers)
                            current_price = int(current_price * 100)  # В копейки
                            price_found = True
                            print(f"Найдена цена через JS-данные: {current_price}", file=sys.stderr)
                        except ValueError:
                            print(f"Не удалось преобразовать строку '{price_numbers}' в число", file=sys.stderr)
                    # Если это уже число
                    elif isinstance(price_text, (int, float)):
                        current_price = int(float(price_text) * 100)  # В копейки
                        price_found = True
                        print(f"Найдена числовая цена через JS-данные: {current_price}", file=sys.stderr)
            except Exception as e:
                print(f"Ошибка при извлечении цены из JS-данных: {str(e)}", file=sys.stderr)
        
        # Если не нашли через JS, ищем через селекторы
        if not price_found:
            try:
                price_selectors = [
                    "span[data-marker='item-price']",
                    "span[itemprop='price']",
                    "span.js-item-price",
                    "div.item-price span.price-value",
                    "div.item-price"
                ]
                
                for selector in price_selectors:
                    if await page.locator(selector).count() > 0:
                        price_element = page.locator(selector).first
                        # Проверяем атрибут content, который может содержать точную цену
                        price_content = await price_element.get_attribute("content")
                        
                        if price_content:
                            try:
                                current_price = float(price_content)
                                current_price = int(current_price * 100)  # В копейки
                                price_found = True
                                print(f"Найдена цена из атрибута content по селектору {selector}: {current_price}", file=sys.stderr)
                                break
                            except ValueError:
                                print(f"Не удалось преобразовать content '{price_content}' в число", file=sys.stderr)
                        
                        # Если не нашли в content, смотрим на текст
                        price_text = await price_element.text_content()
                        if price_text:
                            price_numbers = re.sub(r'[^\d\.,]', '', price_text.replace(',', '.').replace(' ', ''))
                            if price_numbers:
                                try:
                                    current_price = float(price_numbers)
                                    current_price = int(current_price * 100)  # В копейки
                                    price_found = True
                                    print(f"Найдена цена из текста по селектору {selector}: {current_price}", file=sys.stderr)
                                    break
                                except ValueError:
                                    print(f"Не удалось преобразовать строку '{price_numbers}' в число", file=sys.stderr)
            except Exception as e:
                print(f"Ошибка при извлечении цены через селекторы: {str(e)}", file=sys.stderr)
                
        # Если по-прежнему нет цены, ищем регулярным выражением в тексте страницы
        if not price_found:
            try:
                body_text = await page.evaluate("document.body.innerText")
                # Ищем вхождения цены в формате "XXX XXX ₽" или "XXX XXX руб."
                price_matches = re.findall(r'(\d{1,3}(?: \d{3})*)(?: |&nbsp;)(?:₽|руб\.)', body_text)
                if price_matches:
                    price_text = price_matches[0][0]
                    price_numbers = re.sub(r'[^\d]', '', price_text)
                    if price_numbers:
                        try:
                            current_price = int(price_numbers) * 100  # В копейки
                            price_found = True
                            print(f"Найдена цена через регулярное выражение: {current_price}", file=sys.stderr)
                        except ValueError:
                            print(f"Не удалось преобразовать строку '{price_numbers}' в число", file=sys.stderr)
            except Exception as e:
                print(f"Ошибка при поиске цены через регулярное выражение: {str(e)}", file=sys.stderr)
                
        # Если цена не найдена, возвращаем ошибку
        if not price_found or not current_price:
            print("Не удалось извлечь цену с Авито", file=sys.stderr)
            return {
                "success": False,
                "error": "Не удалось извлечь цену"
            }
            
        # URL изображения товара
        image_url = ""
        try:
            # Сначала пробуем через JS-данные
            if product_data:
                if 'image' in product_data:
                    image_url = product_data['image']
                elif '@type' in product_data and product_data['@type'] == 'Product' and 'image' in product_data:
                    image_url = product_data['image']
                    
            # Если не нашли через JS, ищем через селекторы
            if not image_url:
                image_selectors = [
                    "div.gallery-img-frame img",
                    "div.gallery-img-wrapper img",
                    "li.js-gallery-img-item img",
                    "div[data-marker='item-photo'] img"
                ]
                
                for selector in image_selectors:
                    if await page.locator(selector).count() > 0:
                        image_element = page.locator(selector).first
                        # Проверяем разные атрибуты
                        for attr in ['src', 'data-src']:
                            attr_value = await image_element.get_attribute(attr)
                            if attr_value and not attr_value.startswith('data:'):
                                image_url = attr_value
                                print(f"Найден URL изображения по селектору {selector} и атрибуту {attr}: {image_url}", file=sys.stderr)
                                break
                        if image_url:
                            break
                            
            # Если изображение до сих пор не найдено, ищем первое достаточно большое изображение на странице
            if not image_url:
                all_images = await page.evaluate("""() => {
                    return Array.from(document.querySelectorAll('img'))
                        .filter(img => img.width > 100 && img.height > 100 && !img.src.includes('logo') && !img.src.startsWith('data:'))
                        .map(img => img.src);
                }""")
                
                if all_images and len(all_images) > 0:
                    image_url = all_images[0]
                    print(f"Найден URL изображения через поиск по всем изображениям: {image_url}", file=sys.stderr)
                    
            # Если изображение не найдено, используем заглушку
            if not image_url:
                image_url = "https://www.avito.ru/favicon.ico"
        except Exception as e:
            print(f"Ошибка при извлечении URL изображения: {str(e)}", file=sys.stderr)
            image_url = "https://www.avito.ru/favicon.ico"
            
        return {
            "success": True,
            "name": name,
            "price": current_price,
            "image_url": image_url,
            "original_price": current_price,  # На Авито обычно нет оригинальной цены
            "discount": 0  # На Авито обычно нет скидок
        }
    except Exception as e:
        print(f"Ошибка при парсинге Авито: {str(e)}", file=sys.stderr)
        return {
            "success": False,
            "error": str(e)
        }

async def extract_generic_price(page):
    """Пытается извлечь цену с любого сайта"""
    try:
        # Ждем полной загрузки страницы
        await page.wait_for_load_state("networkidle", timeout=10000)
        
        # Получаем HTML страницы
        html = await page.content()
        
        # Получаем title страницы как название товара
        name = await page.title()
        
        # Ищем цены с помощью регулярных выражений и микро-данных
        price = None
        
        # Поиск по микроданным (schema.org)
        price_selectors = [
            'meta[property="product:price:amount"]',
            'meta[property="og:price:amount"]',
            'meta[itemprop="price"]',
            '[itemprop="price"]',
            '.price',
            '.product-price',
            '.offer-price',
            '.current-price',
            '[data-price]',
            '[data-product-price]'
        ]
        
        for selector in price_selectors:
            try:
                # Пробуем найти цену по селектору
                await page.wait_for_selector(selector, timeout=500)
                element = await page.query_selector(selector)
                
                if element:
                    # Проверяем тип элемента
                    tag_name = await element.get_property('tagName')
                    tag_name = await tag_name.json_value()
                    
                    if tag_name.lower() == 'meta':
                        price_text = await element.get_attribute('content')
                    else:
                        # У некоторых элементов цена в data-атрибуте
                        price_text = await element.get_attribute('data-price')
                        if not price_text:
                            price_text = await element.text_content()
                    
                    # Извлекаем числа из текста
                    price_match = re.search(r'[\d\s,.]+', price_text)
                    if price_match:
                        price_str = price_match.group().strip().replace(' ', '').replace(',', '.')
                        # Оставляем только первую точку, остальные удаляем
                        if price_str.count('.') > 1:
                            price_str = price_str.replace('.', '', price_str.count('.') - 1)
                        price = float(price_str)
                        break
            except:
                continue
        
        # Если по селекторам не нашли, ищем в тексте страницы
        if price is None:
            # Распространенные паттерны цен на русском и английском
            price_patterns = [
                r'(\d[\d\s,.]*)\s*₽',  # Рубли
                r'(\d[\d\s,.]*)\s*руб',  # Рубли (сокращение)
                r'(\d[\d\s,.]*)\s*р',  # Рубли (короткое сокращение)
                r'(\d[\d\s,.]*)\s*RUB',  # Рубли (код валюты)
                r'₽\s*(\d[\d\s,.]*)',  # Рубли (символ перед числом)
                r'(\d[\d\s,.]*)\s*\$',  # Доллары
                r'\$\s*(\d[\d\s,.]*)',  # Доллары (символ перед числом)
                r'(\d[\d\s,.]*)\s*USD',  # Доллары (код валюты)
                r'(\d[\d\s,.]*)\s*€',  # Евро
                r'€\s*(\d[\d\s,.]*)',  # Евро (символ перед числом)
                r'(\d[\d\s,.]*)\s*EUR',  # Евро (код валюты)
                r'цена:?\s*(\d[\d\s,.]*)',  # "цена: 1234"
                r'стоимость:?\s*(\d[\d\s,.]*)',  # "стоимость: 1234"
                r'price:?\s*(\d[\d\s,.]*)',  # "price: 1234"
                r'cost:?\s*(\d[\d\s,.]*)',  # "cost: 1234"
            ]
            
            for pattern in price_patterns:
                price_matches = re.findall(pattern, html, re.IGNORECASE)
                if price_matches:
                    # Берем первое найденное совпадение
                    price_str = price_matches[0].strip().replace(' ', '').replace(',', '.')
                    # Оставляем только первую точку, остальные удаляем
                    if price_str.count('.') > 1:
                        price_str = price_str.replace('.', '', price_str.count('.') - 1)
                    price = float(price_str)
                    break
        
        # Если не удалось найти цену, используем запасной вариант
        if price is None:
            price = 0
        
        # Находим изображение товара
        image_url = None
        image_selectors = [
            'meta[property="og:image"]',
            'meta[name="og:image"]',
            'meta[itemprop="image"]',
            'link[rel="image_src"]',
            '[itemprop="image"]',
            '.product-image img',
            '.product-photo img',
            '.gallery img',
            '.carousel img',
            '.product img',
            'img[alt*="product"]',
            '.main-image',
            '.primary-image'
        ]
        
        for selector in image_selectors:
            try:
                await page.wait_for_selector(selector, timeout=500)
                element = await page.query_selector(selector)
                
                if element:
                    # Проверяем тип элемента
                    tag_name = await element.get_property('tagName')
                    tag_name = await tag_name.json_value()
                    
                    if tag_name.lower() == 'meta' or tag_name.lower() == 'link':
                        image_url = await element.get_attribute('content')
                        if not image_url:
                            image_url = await element.get_attribute('href')
                    else:
                        image_url = await element.get_attribute('src')
                        
                    if image_url:
                        # Проверяем, является ли URL относительным
                        if not image_url.startswith(('http:', 'https:')):
                            # Преобразуем в абсолютный URL
                            domain = urlparse(page.url).netloc
                            scheme = urlparse(page.url).scheme
                            if image_url.startswith('//'):
                                image_url = f"{scheme}:{image_url}"
                            elif image_url.startswith('/'):
                                image_url = f"{scheme}://{domain}{image_url}"
                            else:
                                image_url = f"{scheme}://{domain}/{image_url}"
                        break
            except:
                continue
                
        # Если не нашли изображение, используем запасной вариант
        if not image_url:
            image_url = "https://via.placeholder.com/400x400?text=Image+Not+Found"
            
        # Предполагаем, что оригинальная цена такая же
        original_price = price
        discount = 0
            
        return {
            "name": name.strip(),
            "price": price,
            "originalPrice": original_price,
            "discount": discount,
            "imageUrl": image_url,
            "success": True
        }
    except Exception as e:
        print(f"Ошибка при общем парсинге: {str(e)}", file=sys.stderr)
        return {"success": False, "error": str(e)}

async def parse_website(url):
    """Парсит веб-сайт и извлекает данные о товаре"""
    marketplace = detect_marketplace(url)
    
    async with async_playwright() as p:
        # Используем Chrome/Chromium
        browser_args = []
        
        # Добавляем аргументы для скрытия автоматизации
        browser_args.extend([
            '--disable-blink-features=AutomationControlled',
            '--disable-features=IsolateOrigins,site-per-process',
            '--disable-site-isolation-trials',
            '--disable-web-security',
            '--disable-features=BlockInsecurePrivateNetworkRequests'
        ])
        
        browser = await p.chromium.launch(
            headless=True,  # Безголовый режим
            args=browser_args
        )
        
        # Случайный User-Agent для каждого запуска
        user_agents = [
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36",
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.5.1 Safari/605.1.15",
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/115.0",
            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36",
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:109.0) Gecko/20100101 Firefox/115.0",
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36 Edg/115.0.1901.188"
        ]
        user_agent = random.choice(user_agents)
        
        # Создаем новый контекст с эмуляцией десктопного браузера и скрытием автоматизации
        context = await browser.new_context(
            user_agent=user_agent,
            viewport={"width": 1920, "height": 1080},
            locale="ru-RU",
            timezone_id="Europe/Moscow",
            geolocation={"latitude": 55.7558, "longitude": 37.6173},  # Москва
            permissions=['geolocation'],
            extra_http_headers={
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
                "Accept-Language": "ru-RU,ru;q=0.8,en-US;q=0.5,en;q=0.3",
                "Sec-Fetch-Dest": "document",
                "Sec-Fetch-Mode": "navigate",
                "Sec-Fetch-Site": "none"
            }
        )
        
        # Скрываем WebDriver
        await context.add_init_script("""
            Object.defineProperty(navigator, 'webdriver', { get: () => false });
            Object.defineProperty(navigator, 'languages', { get: () => ['ru-RU', 'ru', 'en-US', 'en'] });
            Object.defineProperty(navigator, 'plugins', { get: () => Array(3).fill().map(() => ({})) });
        """)
        
        # Открываем новую страницу
        page = await context.new_page()
        
        # Устанавливаем случайный интервал между действиями
        await page.set_default_timeout(60000)
        
        try:
            # Переходим на сайт с таймаутом в 30 секунд
            await page.goto(url, timeout=30000, wait_until="domcontentloaded")
            
            # Выполняем случайные действия на странице для имитации поведения пользователя
            await random_human_behavior(page)
            
            # Ждем загрузки страницы
            await page.wait_for_load_state("networkidle", timeout=10000)
            
            # В зависимости от маркетплейса используем соответствующий экстрактор
            if marketplace == "ozon":
                result = await extract_ozon_price(page)
            elif marketplace == "wildberries":
                result = await extract_wildberries_price(page)
            elif marketplace == "aliexpress":
                result = await extract_aliexpress_price(page)
            elif marketplace == "avito":
                result = await extract_avito_price(page)
            else:
                result = await extract_generic_price(page)
                
            # Добавляем информацию о маркетплейсе
            result["marketplace"] = marketplace
            
            # Добавляем URL в результат
            result["url"] = url
                
        except Exception as e:
            print(f"Ошибка при парсинге {url}: {str(e)}", file=sys.stderr)
            result = {
                "success": False,
                "error": str(e),
                "marketplace": marketplace,
                "url": url
            }
        
        # Делаем скриншот для отладки при ошибке
        if not result.get("success", False):
            try:
                screenshot_path = f"debug_screenshot_{int(time.time())}.png"
                await page.screenshot(path=screenshot_path)
                print(f"Создан скриншот для отладки: {screenshot_path}", file=sys.stderr)
            except:
                pass
        
        # Закрываем браузер
        await browser.close()
        
        return result

async def random_human_behavior(page):
    """Имитирует случайное поведение человека на странице"""
    # Случайная задержка перед началом действий
    await asyncio.sleep(random.uniform(1, 3))
    
    # Случайное прокручивание страницы
    for _ in range(random.randint(2, 5)):
        await page.mouse.wheel(0, random.randint(300, 700))
        await asyncio.sleep(random.uniform(0.5, 2))
    
    # Случайное перемещение мыши
    for _ in range(random.randint(3, 7)):
        await page.mouse.move(
            random.randint(100, 1000), 
            random.randint(100, 700), 
            steps=random.randint(5, 10)
        )
        await asyncio.sleep(random.uniform(0.3, 1))

def detect_marketplace(url):
    """Определяет маркетплейс по URL"""
    domain = urlparse(url).netloc.lower()
    
    if "ozon" in domain:
        return "ozon"
    elif "wildberries" in domain or "wb.ru" in domain:
        return "wildberries"
    elif "aliexpress" in domain:
        return "aliexpress"
    elif "avito" in domain:
        return "avito"
    else:
        return "unknown"

async def main():
    # Настраиваем аргументы командной строки
    parser = argparse.ArgumentParser(description="Парсит цены товаров с различных маркетплейсов")
    parser.add_argument("--url", required=True, help="URL товара для парсинга")
    args = parser.parse_args()
    
    # Парсим указанный URL
    result = await parse_website(args.url)
    
    # Выводим результат в JSON формате
    print(json.dumps(result, ensure_ascii=False))

if __name__ == "__main__":
    asyncio.run(main()) 