#!/bin/bash

# Check if PostgreSQL is installed
if command -v psql >/dev/null 2>&1; then
  echo "PostgreSQL is installed."
else
  echo "PostgreSQL is not installed. Please install PostgreSQL."
  echo "For macOS: brew install postgresql"
  echo "For Ubuntu: sudo apt install postgresql"
  exit 1
fi

# Database configuration from .env
DB_HOST="localhost"
DB_PORT="5432"
DB_USER="postgres"
DB_PASSWORD="postgres"
DB_NAME="pricetrack"

# Load configuration from .env if it exists
if [ -f "../.env" ]; then
  echo "Loading database configuration from .env"
  source "../.env"
fi

# Check if PostgreSQL service is running
if pg_isready -h $DB_HOST -p $DB_PORT > /dev/null 2>&1; then
  echo "PostgreSQL is running."
else
  echo "PostgreSQL is not running. Please start PostgreSQL service."
  echo "For macOS: brew services start postgresql"
  echo "For Ubuntu: sudo service postgresql start"
  exit 1
fi

# Try to connect to the database
PGPASSWORD=$DB_PASSWORD psql -h $DB_HOST -p $DB_PORT -U $DB_USER -d postgres -c '\q' 2>/dev/null
if [ $? -ne 0 ]; then
  echo "Failed to connect to PostgreSQL with provided credentials."
  echo "Please check your database credentials in .env file."
  exit 1
fi

# Check if the database exists
DB_EXISTS=$(PGPASSWORD=$DB_PASSWORD psql -h $DB_HOST -p $DB_PORT -U $DB_USER -d postgres -tAc "SELECT 1 FROM pg_database WHERE datname='$DB_NAME'")
if [ "$DB_EXISTS" = "1" ]; then
  echo "Database '$DB_NAME' already exists."
else
  echo "Creating database '$DB_NAME'..."
  PGPASSWORD=$DB_PASSWORD psql -h $DB_HOST -p $DB_PORT -U $DB_USER -d postgres -c "CREATE DATABASE $DB_NAME" >/dev/null 2>&1
  if [ $? -eq 0 ]; then
    echo "Database '$DB_NAME' created successfully."
  else
    echo "Failed to create database '$DB_NAME'."
    exit 1
  fi
fi

echo "Database setup completed successfully."
echo "You can now run: npm run dev" 