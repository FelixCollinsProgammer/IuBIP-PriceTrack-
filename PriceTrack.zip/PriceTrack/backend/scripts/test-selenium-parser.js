#!/usr/bin/env node

/**
 * Скрипт для тестирования Selenium парсера
 * 
 * Пример использования:
 * node test-selenium-parser.js https://www.ozon.ru/product/...
 */

const { execSync } = require('child_process');
const path = require('path');
const fs = require('fs');

// Проверяем аргументы командной строки
if (process.argv.length < 3) {
  console.error('Необходимо указать URL товара для тестирования');
  console.error('Пример: node test-selenium-parser.js https://www.ozon.ru/product/...');
  process.exit(1);
}

const url = process.argv[2];
const scriptPath = path.join(__dirname, 'selenium_parser.py');

console.log(`Проверка наличия скрипта парсера: ${scriptPath}`);
if (!fs.existsSync(scriptPath)) {
  console.error(`Ошибка: файл ${scriptPath} не найден`);
  process.exit(1);
}

// Проверка установки Python
try {
  const pythonVersion = execSync('python3 --version').toString().trim();
  console.log(`Python версии: ${pythonVersion}`);
} catch (error) {
  console.error('Python не установлен. Пожалуйста, установите Python 3');
  process.exit(1);
}

// Проверка установки Selenium
try {
  execSync('python3 -c "from selenium import webdriver"');
  console.log('Selenium установлен');
} catch (error) {
  console.error('Selenium не установлен. Запускаем установку...');
  try {
    execSync('bash scripts/setup-selenium-parser.sh', { stdio: 'inherit' });
    console.log('Selenium успешно установлен');
  } catch (setupError) {
    console.error('Ошибка при установке Selenium:', setupError.message);
    process.exit(1);
  }
}

// Запуск парсера
console.log(`Тестирование парсинга URL: ${url}`);
try {
  const start = Date.now();
  const result = execSync(`python3 "${scriptPath}" --url "${url}"`, { timeout: 120000 }).toString();
  const end = Date.now();
  const executionTime = (end - start) / 1000;
  
  try {
    const data = JSON.parse(result);
    console.log('Результат парсинга:');
    console.log(JSON.stringify(data, null, 2));
    console.log(`Время выполнения: ${executionTime.toFixed(2)} секунд`);
    
    if (data.success) {
      console.log('\n✅ Тест успешно пройден');
    } else {
      console.log('\n❌ Тест не пройден: парсер вернул ошибку');
      console.error(data.error);
    }
  } catch (parseError) {
    console.error('Ошибка при парсинге результата JSON:', parseError.message);
    console.log('Полученный результат:');
    console.log(result);
  }
} catch (error) {
  console.error('Ошибка при запуске парсера:', error.message);
  process.exit(1);
} 