# PriceTrack Parsers

Данный каталог содержит парсеры для различных маркетплейсов: Ozon, Wildberries и AliExpress. Парсеры используются для извлечения цен и информации о товарах с этих платформ.

## Доступные парсеры

### 1. Selenium Parser (`selenium_parser.py`)

Новый парсер, основанный на Selenium WebDriver. Более стабильный и эффективный для обхода защиты от ботов.

#### Особенности:
- Использует Selenium для управления браузером
- Имитирует поведение реального пользователя
- Работает с динамическим контентом
- Эффективнее обходит защиту от ботов
- Поддерживает: Ozon, Wildberries, AliExpress

### 2. Playwright Parser (`price_parser.py`)

Старый парсер, основанный на Playwright.

#### Особенности:
- Использует Playwright для управления браузером
- Быстрее Selenium на некоторых сайтах
- Может быть нестабильным на некоторых маркетплейсах
- Поддерживает: Ozon, Wildberries, AliExpress, Avito

## Установка зависимостей

Для установки всех необходимых зависимостей используйте следующие скрипты:

```bash
# Для Selenium парсера
bash setup-selenium-parser.sh

# Для Playwright парсера
bash setup-python-parser.sh
```

## Использование парсеров

### Напрямую через Python

```bash
# Selenium Parser
python3 selenium_parser.py --url "https://www.ozon.ru/product/smartfon-xiaomi-redmi-12-8-256gb-graphite-gray-global-version-1171511903/"

# Playwright Parser
python3 price_parser.py --url "https://www.ozon.ru/product/smartfon-xiaomi-redmi-12-8-256gb-graphite-gray-global-version-1171511903/"
```

### Тестирование парсеров

Для тестирования работы парсеров используйте следующие скрипты:

```bash
# Тестирование Selenium парсера
node test-selenium-parser.js "https://www.ozon.ru/product/smartfon-xiaomi-redmi-12-8-256gb-graphite-gray-global-version-1171511903/"

# Сравнение обоих парсеров
node ../test-parsers.js
```

### Использование в TypeScript коде

```typescript
import { PythonParserService } from './services/PythonParserService';

// Использование Selenium парсера
const resultWithSelenium = await PythonParserService.parseUrlWithSelenium(url);

// Использование Playwright парсера
const resultWithPlaywright = await PythonParserService.parseUrlWithPlaywright(url);

// Использование текущего активного парсера (по умолчанию Playwright)
const result = await PythonParserService.parseUrl(url);
```

## Формат ответа

Парсеры возвращают результат в формате JSON:

```json
{
  "name": "Название товара",
  "price": 12345,
  "originalPrice": 15000,
  "discount": 18,
  "imageUrl": "https://example.com/image.jpg",
  "marketplace": "ozon",
  "url": "https://www.ozon.ru/product/...",
  "success": true
}
```

При ошибке:

```json
{
  "success": false,
  "error": "Описание ошибки",
  "name": "Не удалось загрузить товар",
  "price": 0,
  "originalPrice": 0,
  "discount": 0,
  "imageUrl": "https://via.placeholder.com/400x400?text=Error+Loading+Image",
  "marketplace": "ozon",
  "url": "https://www.ozon.ru/product/..."
}
```

## Поддерживаемые маркетплейсы

| Маркетплейс | Selenium Parser | Playwright Parser |
|-------------|-----------------|-------------------|
| Ozon         | ✅              | ✅                |
| Wildberries  | ✅              | ✅                |
| AliExpress   | ✅              | ✅                |
| Avito        | ❌              | ✅                |
| Другие       | ⚠️ (базовый)    | ⚠️ (базовый)      |

## Устранение проблем

### Ошибка: ChromeDriver не найден

Убедитесь, что вы установили все зависимости с помощью скрипта:

```bash
bash setup-selenium-parser.sh
```

### Ошибка: Капча или блокировка

Если вы часто получаете ошибки о капче или блокировке:

1. Уменьшите частоту запросов
2. Используйте прокси-серверы (требуется дополнительная настройка)
3. Переключитесь между Selenium и Playwright парсерами

### Ошибка: Неверный результат парсинга

Селекторы на сайтах маркетплейсов могут меняться. Если вы получаете неверные результаты или нулевые цены, возможно, нужно обновить селекторы в коде парсеров. 