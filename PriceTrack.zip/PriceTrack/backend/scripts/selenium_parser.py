#!/usr/bin/env python3
import sys
import json
import re
import argparse
import random
import time
import traceback
from urllib.parse import urlparse
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import (
    TimeoutException, 
    NoSuchElementException, 
    StaleElementReferenceException,
    WebDriverException
)

"""
Скрипт для парсинга цен товаров с различных маркетплейсов с использованием Selenium.
Поддерживаемые маркетплейсы: Ozon, Wildberries, AliExpress.

Пример использования:
python selenium_parser.py --url "https://www.ozon.ru/product/smartfon-xiaomi-redmi-12-8-256gb-graphite-gray-global-version-1171511903/"
"""

class ProductParser:
    def __init__(self, headless=True, timeout=30):
        self.timeout = timeout
        self.driver = None
        self.headless = headless
        self.user_agents = [
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36',
            'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36',
            'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.3 Safari/605.1.15',
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36 Edg/123.0.0.0',
            'Mozilla/5.0 (iPhone; CPU iPhone OS 17_4 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/123.0.0.0 Mobile/15E148 Safari/604.1'
        ]
    
    def setup_driver(self):
        options = Options()
        if self.headless:
            options.add_argument('--headless=new')
        
        # Выбор случайного user-agent
        user_agent = random.choice(self.user_agents)
        options.add_argument(f'user-agent={user_agent}')
        
        # Стандартные настройки для стабильности и маскировки автоматизации
        options.add_argument('--no-sandbox')
        options.add_argument('--disable-dev-shm-usage')
        options.add_argument('--disable-blink-features=AutomationControlled')
        options.add_argument('--disable-extensions')
        options.add_argument('--disable-notifications')
        options.add_argument('--window-size=1920,1080')
        options.add_experimental_option('excludeSwitches', ['enable-automation'])
        options.add_experimental_option('useAutomationExtension', False)
        
        # Для улучшения производительности
        options.add_argument('--disable-gpu')
        options.add_argument('--disable-infobars')
        
        # Создаем драйвер
        self.driver = webdriver.Chrome(options=options)
        
        # Устанавливаем параметры ожидания по умолчанию
        self.driver.set_page_load_timeout(self.timeout)
        self.driver.implicitly_wait(5)
        
        # Устанавливаем антидетект-скрипты через JavaScript
        self.driver.execute_script('''
            Object.defineProperty(navigator, 'webdriver', {
                get: () => false,
            });
            
            // Override 'plugins' property
            Object.defineProperty(navigator, 'plugins', {
                get: () => [
                    { name: 'Chrome PDF Plugin' },
                    { name: 'Chrome PDF Viewer' },
                    { name: 'Native Client' }
                ],
            });
            
            // Modify language and platform settings to appear more genuine
            Object.defineProperty(navigator, 'language', {
                get: () => 'ru-RU'
            });
            
            Object.defineProperty(navigator, 'platform', {
                get: () => 'Win32'
            });
        ''')

    def close_driver(self):
        if self.driver:
            try:
                self.driver.quit()
            except Exception as e:
                print(f"Ошибка при закрытии драйвера: {str(e)}", file=sys.stderr)

    def safe_find_element(self, by, selector, timeout=None):
        """Безопасное получение элемента с заданным ожиданием"""
        timeout = timeout or self.timeout
        try:
            element = WebDriverWait(self.driver, timeout).until(
                EC.presence_of_element_located((by, selector))
            )
            return element
        except (TimeoutException, NoSuchElementException):
            return None

    def safe_find_elements(self, by, selector, timeout=None):
        """Безопасное получение списка элементов с заданным ожиданием"""
        timeout = timeout or self.timeout
        try:
            elements = WebDriverWait(self.driver, timeout).until(
                EC.presence_of_all_elements_located((by, selector))
            )
            return elements
        except (TimeoutException, NoSuchElementException):
            return []

    def extract_price_from_text(self, text):
        """Извлекает число цены из текста, удаляя все нецифровые символы"""
        if not text:
            return 0
        # Извлекаем только цифры
        price_numbers = re.sub(r'[^\d]', '', text)
        if price_numbers:
            return int(price_numbers)
        return 0

    def simulate_human_behavior(self):
        """Имитирует поведение человека на странице"""
        try:
            # Случайное время ожидания перед действиями
            time.sleep(random.uniform(0.5, 2.0))
            
            # Случайный скроллинг
            scroll_height = self.driver.execute_script("return document.body.scrollHeight")
            for i in range(3):
                scroll_to = random.randint(100, int(scroll_height * 0.7))
                self.driver.execute_script(f"window.scrollTo(0, {scroll_to});")
                time.sleep(random.uniform(0.3, 1.0))
            
            # Возврат наверх страницы
            self.driver.execute_script("window.scrollTo(0, 0);")
            time.sleep(random.uniform(0.3, 0.7))
        except Exception as e:
            print(f"Ошибка при имитации поведения человека: {str(e)}", file=sys.stderr)

    def detect_marketplace(self, url):
        """Определяет маркетплейс по URL"""
        domain = urlparse(url).netloc.lower()
        
        if 'ozon' in domain or 'oz.ru' in domain:
            return 'ozon'
        elif 'wildberries' in domain or 'wb.ru' in domain:
            return 'wildberries'
        elif 'aliexpress' in domain:
            return 'aliexpress'
        elif 'avito' in domain:
            return 'avito'
        else:
            return 'unknown'

    def parse_url(self, url):
        """Главный метод парсинга URL товара"""
        try:
            self.setup_driver()
            marketplace = self.detect_marketplace(url)
            
            # Загрузка страницы
            print(f"Загрузка страницы {url}", file=sys.stderr)
            self.driver.get(url)
            time.sleep(2)  # Даем время для загрузки
            
            # Делаем скриншот для отладки
            self.driver.save_screenshot(f"{marketplace}-screenshot.png")
            
            # Имитируем поведение человека
            self.simulate_human_behavior()
            
            # Выбираем парсер в зависимости от маркетплейса
            if marketplace == 'ozon':
                result = self.parse_ozon()
            elif marketplace == 'wildberries':
                result = self.parse_wildberries()
            elif marketplace == 'aliexpress':
                result = self.parse_aliexpress()
            else:
                result = self.parse_generic()
                
            # Добавляем информацию о URL и маркетплейсе в результат
            result['url'] = url
            result['marketplace'] = marketplace
            result['success'] = True
            
            return result
        except Exception as e:
            print(f"Ошибка при парсинге {url}: {str(e)}", file=sys.stderr)
            traceback.print_exc(file=sys.stderr)
            
            # Возвращаем объект с ошибкой
            return {
                'success': False,
                'error': str(e),
                'name': 'Не удалось загрузить товар',
                'price': 0,
                'originalPrice': 0,
                'discount': 0,
                'imageUrl': 'https://via.placeholder.com/400x400?text=Error+Loading+Image',
                'marketplace': self.detect_marketplace(url),
                'url': url
            }
        finally:
            self.close_driver()

    def parse_ozon(self):
        """Парсинг товара с Ozon"""
        print("Парсинг Ozon", file=sys.stderr)
        
        # Проверка на капчу или блокировку
        page_text = self.driver.page_source.lower()
        if any(keyword in page_text for keyword in ['captcha', 'капча', 'робот', 'заблокирован']):
            raise Exception("Обнаружена капча или блокировка на странице Ozon")
        
        # Название товара
        name = ""
        name_selectors = [
            "//h1[@data-widget='webProductHeading']",
            "//h1",
            "//div[@data-widget='webProductHeading']"
        ]
        
        for selector in name_selectors:
            try:
                name_element = self.safe_find_element(By.XPATH, selector)
                if name_element:
                    name = name_element.text.strip()
                    if name:
                        break
            except:
                continue
        
        # Цена товара
        current_price = 0
        price_selectors = [
            "//div[@data-widget='webPrice']//span[contains(@class, 'ln-c')]",
            "//div[@data-widget='webPrice']//span[contains(@class, 'c2h5')]",
            "//span[@data-widget='webOzonPrice']",
            "//span[@data-widget='webPrice']",
            "//div[@data-widget='webPrice']//span"
        ]
        
        for selector in price_selectors:
            try:
                price_element = self.safe_find_element(By.XPATH, selector)
                if price_element:
                    price_text = price_element.text.strip()
                    current_price = self.extract_price_from_text(price_text)
                    if current_price > 0:
                        break
            except:
                continue
        
        # Оригинальная цена (до скидки)
        original_price = 0
        old_price_selectors = [
            "//div[@data-widget='webPrice']//span[contains(@class, 'jn1')]",
            "//div[@data-widget='webPrice']//span[contains(@class, 'c2m7')]",
            "//div[@data-widget='webPrice']//span[contains(@class, 'old')]",
            "//div[@data-widget='webPrice']//span[contains(@class, 'lk3')]",
            "//div[@data-widget='webPrice']//span[contains(@class, 'ly2')]"
        ]
        
        for selector in old_price_selectors:
            try:
                old_price_element = self.safe_find_element(By.XPATH, selector)
                if old_price_element:
                    old_price_text = old_price_element.text.strip()
                    original_price = self.extract_price_from_text(old_price_text)
                    if original_price > 0:
                        break
            except:
                continue
        
        # URL изображения товара
        image_url = ""
        image_selectors = [
            "//div[@data-widget='webGallery']//img",
            "//div[contains(@class, 'jn2')]//img",
            "//div[contains(@class, 'lo7')]//img"
        ]
        
        for selector in image_selectors:
            try:
                image_element = self.safe_find_element(By.XPATH, selector)
                if image_element:
                    image_url = image_element.get_attribute('src')
                    if image_url:
                        break
            except:
                continue
        
        # Рассчитываем скидку
        discount = 0
        if original_price > 0 and current_price > 0 and original_price > current_price:
            discount = round((1 - current_price / original_price) * 100)
        
        # Если не смогли получить оригинальную цену, приравниваем к текущей
        if original_price == 0 and current_price > 0:
            original_price = current_price
        
        # Формируем результат
        return {
            'name': name or 'Товар Ozon',
            'price': current_price,
            'originalPrice': original_price,
            'discount': discount,
            'imageUrl': image_url or 'https://upload.wikimedia.org/wikipedia/commons/thumb/8/82/Logo_of_Ozon.ru_%28old%29.svg/320px-Logo_of_Ozon.ru_%28old%29.svg.png'
        }

    def parse_wildberries(self):
        """Парсинг товара с Wildberries"""
        print("Парсинг Wildberries", file=sys.stderr)
        
        # Название товара
        name = ""
        name_selectors = [
            "//h1",
            "//div[contains(@class, 'product-page__title')]"
        ]
        
        for selector in name_selectors:
            try:
                name_element = self.safe_find_element(By.XPATH, selector)
                if name_element:
                    name = name_element.text.strip()
                    if name:
                        break
            except:
                continue
        
        # Цена товара
        current_price = 0
        price_selectors = [
            "//ins[contains(@class, 'price-block__final-price')]",
            "//span[contains(@class, 'price-block__final-price')]",
            "//div[contains(@class, 'price-block__price-wrap')]//ins",
            "//div[contains(@class, 'price-block__price')]",
            "//div[contains(@class, 'product-page__price-block')]//span[contains(@class, 'price-block__final-price')]"
        ]
        
        for selector in price_selectors:
            try:
                price_element = self.safe_find_element(By.XPATH, selector)
                if price_element:
                    price_text = price_element.text.strip()
                    current_price = self.extract_price_from_text(price_text)
                    if current_price > 0:
                        break
            except:
                continue
        
        # Оригинальная цена (до скидки)
        original_price = 0
        old_price_selectors = [
            "//del[contains(@class, 'price-block__old-price')]",
            "//span[contains(@class, 'price-block__old-price')]",
            "//s[contains(@class, 'price-block__old-price')]",
            "//div[contains(@class, 'price-block__content')]//del"
        ]
        
        for selector in old_price_selectors:
            try:
                old_price_element = self.safe_find_element(By.XPATH, selector)
                if old_price_element:
                    old_price_text = old_price_element.text.strip()
                    original_price = self.extract_price_from_text(old_price_text)
                    if original_price > 0:
                        break
            except:
                continue
        
        # URL изображения товара
        image_url = ""
        image_selectors = [
            "//img[contains(@class, 'photo-zoom__preview')]",
            "//div[contains(@class, 'zoom-image-container')]//img",
            "//div[contains(@class, 'swiper-wrapper')]//img"
        ]
        
        for selector in image_selectors:
            try:
                image_element = self.safe_find_element(By.XPATH, selector)
                if image_element:
                    image_url = image_element.get_attribute('src')
                    if image_url:
                        break
            except:
                continue
        
        # Рассчитываем скидку
        discount = 0
        if original_price > 0 and current_price > 0 and original_price > current_price:
            discount = round((1 - current_price / original_price) * 100)
        
        # Если не смогли получить оригинальную цену, приравниваем к текущей
        if original_price == 0 and current_price > 0:
            original_price = current_price
        
        # Формируем результат
        return {
            'name': name or 'Товар Wildberries',
            'price': current_price,
            'originalPrice': original_price,
            'discount': discount,
            'imageUrl': image_url or 'https://upload.wikimedia.org/wikipedia/commons/thumb/8/88/Wildberries_logo.svg/320px-Wildberries_logo.svg.png'
        }

    def parse_aliexpress(self):
        """Парсинг товара с AliExpress"""
        print("Парсинг AliExpress", file=sys.stderr)
        
        # Название товара
        name = ""
        name_selectors = [
            "//h1",
            "//div[contains(@class, 'product-title')]",
            "//div[contains(@class, 'title')]",
            "//div[contains(@class, 'Title--title--')]"
        ]
        
        for selector in name_selectors:
            try:
                name_element = self.safe_find_element(By.XPATH, selector)
                if name_element:
                    name = name_element.text.strip()
                    if name:
                        break
            except:
                continue
        
        # Цена товара
        current_price = 0
        price_selectors = [
            "//div[contains(@class, 'product-price-value')]",
            "//div[contains(@class, 'product-price')]",
            "//div[contains(@class, 'price-current')]",
            "//div[contains(@class, 'snow-price')]//span",
            "//div[contains(@class, 'Price--promotion--')]",
            "//div[contains(@class, 'uni-product-price')]//div"
        ]
        
        for selector in price_selectors:
            try:
                price_element = self.safe_find_element(By.XPATH, selector)
                if price_element:
                    price_text = price_element.text.strip()
                    # Для AliExpress часто цена в формате "1 234,56 ₽" или "$12.34"
                    # Удаляем все нецифровые символы, кроме точки и запятой
                    cleaned_text = re.sub(r'[^\d.,]', '', price_text)
                    # Заменяем запятую на точку
                    cleaned_text = cleaned_text.replace(',', '.')
                    # Если есть точка, обрабатываем как float и умножаем на 100
                    if '.' in cleaned_text:
                        try:
                            price_float = float(cleaned_text)
                            current_price = int(price_float * 100)
                        except:
                            # Если не удалось преобразовать, просто оставляем цифры
                            current_price = self.extract_price_from_text(price_text)
                    else:
                        current_price = self.extract_price_from_text(price_text)
                    
                    if current_price > 0:
                        break
            except:
                continue
        
        # Оригинальная цена (до скидки)
        original_price = 0
        old_price_selectors = [
            "//div[contains(@class, 'product-price-original')]",
            "//div[contains(@class, 'price-original')]",
            "//div[contains(@class, 'Price--original--')]//span",
            "//span[contains(@class, 'uniform-banner-box-price')]"
        ]
        
        for selector in old_price_selectors:
            try:
                old_price_element = self.safe_find_element(By.XPATH, selector)
                if old_price_element:
                    old_price_text = old_price_element.text.strip()
                    # Аналогично обработке текущей цены
                    cleaned_text = re.sub(r'[^\d.,]', '', old_price_text)
                    cleaned_text = cleaned_text.replace(',', '.')
                    if '.' in cleaned_text:
                        try:
                            price_float = float(cleaned_text)
                            original_price = int(price_float * 100)
                        except:
                            original_price = self.extract_price_from_text(old_price_text)
                    else:
                        original_price = self.extract_price_from_text(old_price_text)
                    
                    if original_price > 0:
                        break
            except:
                continue
        
        # URL изображения товара
        image_url = ""
        image_selectors = [
            "//div[contains(@class, 'gallery-preview')]//img",
            "//div[contains(@class, 'product-gallery')]//img",
            "//img[contains(@class, 'magnifier-image')]",
            "//div[contains(@class, 'Image--wrap--')]//img"
        ]
        
        for selector in image_selectors:
            try:
                image_element = self.safe_find_element(By.XPATH, selector)
                if image_element:
                    image_url = image_element.get_attribute('src')
                    if image_url:
                        break
            except:
                continue
        
        # Рассчитываем скидку
        discount = 0
        if original_price > 0 and current_price > 0 and original_price > current_price:
            discount = round((1 - current_price / original_price) * 100)
        
        # Если не смогли получить оригинальную цену, приравниваем к текущей
        if original_price == 0 and current_price > 0:
            original_price = current_price
        
        # Формируем результат
        return {
            'name': name or 'Товар AliExpress',
            'price': current_price,
            'originalPrice': original_price,
            'discount': discount,
            'imageUrl': image_url or 'https://upload.wikimedia.org/wikipedia/commons/thumb/e/e1/AliExpress_logo.svg/320px-AliExpress_logo.svg.png'
        }

    def parse_generic(self):
        """Парсинг для неопознанных маркетплейсов"""
        print("Парсинг с использованием общих селекторов", file=sys.stderr)
        
        # Название товара
        name = ""
        name_selectors = [
            "//h1",
            "//div[contains(@class, 'title')]",
            "//div[contains(@class, 'name')]",
            "//span[contains(@class, 'title')]"
        ]
        
        for selector in name_selectors:
            try:
                name_element = self.safe_find_element(By.XPATH, selector)
                if name_element:
                    name = name_element.text.strip()
                    if name:
                        break
            except:
                continue
        
        # Цена товара - ищем элементы, потенциально содержащие цену
        current_price = 0
        price_selectors = [
            "//div[contains(@class, 'price')]//span",
            "//span[contains(@class, 'price')]",
            "//div[contains(@class, 'price')]",
            "//span[contains(@class, 'cost')]",
            "//div[contains(@class, 'cost')]"
        ]
        
        for selector in price_selectors:
            try:
                price_elements = self.safe_find_elements(By.XPATH, selector)
                for element in price_elements:
                    price_text = element.text.strip()
                    # Проверяем, содержит ли текст символы валюты (₽, $, €, руб)
                    if re.search(r'[$€₽р]|руб', price_text, re.IGNORECASE):
                        # Очищаем текст от нецифровых символов
                        cleaned_text = re.sub(r'[^\d.,]', '', price_text)
                        cleaned_text = cleaned_text.replace(',', '.')
                        # Если есть точка, обрабатываем как float
                        if '.' in cleaned_text:
                            try:
                                price_float = float(cleaned_text)
                                current_price = int(price_float * 100)
                            except:
                                current_price = self.extract_price_from_text(price_text)
                        else:
                            current_price = self.extract_price_from_text(price_text)
                        
                        if current_price > 0:
                            break
                
                if current_price > 0:
                    break
            except:
                continue
        
        # URL изображения товара
        image_url = ""
        image_selectors = [
            "//div[contains(@class, 'gallery')]//img",
            "//div[contains(@class, 'product')]//img",
            "//div[contains(@class, 'slider')]//img",
            "//img[contains(@id, 'product')]",
            "//img[contains(@class, 'product')]"
        ]
        
        for selector in image_selectors:
            try:
                image_element = self.safe_find_element(By.XPATH, selector)
                if image_element:
                    image_url = image_element.get_attribute('src')
                    if image_url:
                        break
            except:
                continue
        
        # Формируем результат
        return {
            'name': name or 'Неизвестный товар',
            'price': current_price,
            'originalPrice': current_price,  # Для общего случая приравниваем к текущей цене
            'discount': 0,
            'imageUrl': image_url or 'https://cdn-icons-png.flaticon.com/512/3176/3176363.png'
        }


def main():
    # Настраиваем аргументы командной строки
    parser = argparse.ArgumentParser(description='Парсер цен с маркетплейсов с использованием Selenium')
    parser.add_argument('--url', type=str, required=True, help='URL товара для парсинга')
    parser.add_argument('--headless', type=str, default='true', help='Запуск в фоновом режиме без UI')
    args = parser.parse_args()
    
    # Преобразуем строковый аргумент в булево значение
    headless = args.headless.lower() == 'true'
    
    # Создаем парсер
    product_parser = ProductParser(headless=headless)
    
    try:
        # Запускаем парсинг
        result = product_parser.parse_url(args.url)
        
        # Выводим результат в JSON
        print(json.dumps(result, ensure_ascii=False))
    except Exception as e:
        # В случае ошибки возвращаем JSON с ошибкой
        error_result = {
            'success': False,
            'error': str(e),
            'name': 'Не удалось загрузить товар',
            'price': 0,
            'originalPrice': 0,
            'discount': 0,
            'imageUrl': 'https://via.placeholder.com/400x400?text=Error+Loading+Image',
            'marketplace': 'unknown',
            'url': args.url
        }
        print(json.dumps(error_result, ensure_ascii=False))


if __name__ == "__main__":
    main() 