#!/bin/bash

# Скрипт для установки Python-зависимостей для парсера цен

echo "Настройка Python-парсера для PriceTrack..."

# Проверяем наличие Python
if ! command -v python3 &> /dev/null; then
  echo "Python 3 не установлен. Пожалуйста, установите Python 3 и запустите скрипт снова."
  exit 1
fi

# Проверяем версию Python
python_version=$(python3 -c 'import sys; print(".".join(map(str, sys.version_info[:2])))')
echo "Обнаружен Python версии $python_version"

# Изменяем сравнение версий для поддержки более новых версий
python_major=$(echo $python_version | cut -d. -f1)
python_minor=$(echo $python_version | cut -d. -f2)

if [[ $python_major -lt 3 || ($python_major -eq 3 && $python_minor -lt 7) ]]; then
  echo "Требуется Python 3.7 или выше. Пожалуйста, обновите Python и запустите скрипт снова."
  exit 1
fi

# Проверяем наличие pip
if ! command -v pip3 &> /dev/null; then
  echo "pip3 не установлен. Установка pip..."
  curl https://bootstrap.pypa.io/get-pip.py -o get-pip.py
  python3 get-pip.py
  rm get-pip.py
fi

echo "Установка необходимых Python-пакетов..."
pip3 install playwright

echo "Установка Playwright браузеров..."
python3 -m playwright install chromium

echo "Настройка прав доступа для скрипта парсера..."
chmod +x "$(dirname "$0")/price_parser.py"

echo "Настройка Python-парсера завершена успешно!"
echo "Теперь вы можете запустить сервер PriceTrack с поддержкой Python-парсера." 