import { Request, Response, NextFunction } from 'express';
import { AppDataSource } from '../data-source';
import { Product } from '../entities/Product';
import { Price } from '../entities/Price';
import { Repository } from 'typeorm';
import { ParserService } from '../services/ParserService';
import { SchedulerService } from '../services/SchedulerService';
import { User } from '../entities/User';
import { NewParserService, ProductDetails as JSProductDetails } from '../services/NewParserService';
import { PriceService } from '../services/PriceService';
import { ProductService } from '../services/ProductService';
import { PythonParserService, ProductDetails as PythonProductDetails } from '../services/PythonParserService';

// Объединенный тип для результатов обоих парсеров
type ProductParserResult = JSProductDetails | PythonProductDetails;

// Расширение типа Request для включения пользователя
interface AuthRequest extends Request {
  user?: User;
  init?: boolean;
}

// Для хранения времени последнего обновления цены для каждого продукта
interface PriceCooldown {
  lastUpdate: Date;
  nextUpdate: Date;
}

export class PriceController {
  private priceRepository: Repository<Price>;
  private productRepository: Repository<Product>;
  private parserService: ParserService;
  private initialized: boolean = false;
  
  // Кэш для хранения информации о последнем обновлении цены
  private static cooldownCache: Map<number, PriceCooldown> = new Map();
  // Период "остывания" между запросами обновления цены (30 минут)
  private static readonly COOLDOWN_PERIOD = 30 * 60 * 1000;

  constructor(
    private priceService: PriceService,
    private productService: ProductService
  ) {
    this.parserService = new ParserService();
    // Методы привязываются в методе initialize
    this.initialize().catch(err => {
      console.error('Failed to initialize PriceController:', err);
    });
  }

  private async initialize() {
    try {
      // Проверяем, инициализирован ли AppDataSource
      if (!AppDataSource.isInitialized) {
        await AppDataSource.initialize();
      }
      
      this.priceRepository = AppDataSource.getRepository(Price);
      this.productRepository = AppDataSource.getRepository(Product);
      
      // Привязка методов к this
      this.updatePrice = this.updatePrice.bind(this);
      this.getPrices = this.getPrices.bind(this);
      this.getCooldownInfo = this.getCooldownInfo.bind(this);
      
      this.initialized = true;
      console.log('PriceController initialized successfully');
      
      // Проверяем зависимости Python парсера
      try {
        await PythonParserService.checkDependencies();
        console.log('Python parser dependencies checked successfully');
      } catch (error) {
        console.warn('Python parser dependencies check failed, will use fallback parser:', error);
      }
    } catch (err) {
      this.initialized = false;
      const error = err instanceof Error ? err : new Error('Unknown error during initialization');
      console.error('Failed to initialize PriceController:', error.message);
      throw error;
    }
  }

  private async ensureInitialized() {
    if (!this.initialized) {
      await this.initialize();
      
      if (!this.initialized) {
        throw new Error('Failed to initialize repositories');
      }
    }
  }
  
  /**
   * Проверяет, можно ли обновить цену для продукта
   */
  private canUpdatePrice(productId: number): boolean {
    const cooldown = PriceController.cooldownCache.get(productId);
    if (!cooldown) return true;
    
    const now = new Date();
    return now > cooldown.nextUpdate;
  }
  
  /**
   * Обновляет информацию о кулдауне для продукта
   */
  private updateCooldownInfo(productId: number): void {
    const now = new Date();
    const nextUpdate = new Date(now.getTime() + PriceController.COOLDOWN_PERIOD);
    
    PriceController.cooldownCache.set(productId, {
      lastUpdate: now,
      nextUpdate: nextUpdate
    });
  }
  
  /**
   * Возвращает информацию о кулдауне для продукта
   */
  private getCooldownInfo(productId: number): {canUpdate: boolean, timeRemaining: number, nextUpdate: Date | null} {
    const cooldown = PriceController.cooldownCache.get(productId);
    const now = new Date();
    
    if (!cooldown) {
      return {
        canUpdate: true,
        timeRemaining: 0,
        nextUpdate: null
      };
    }
    
    const timeRemaining = Math.max(0, cooldown.nextUpdate.getTime() - now.getTime());
    const canUpdate = timeRemaining === 0;
    
    return {
      canUpdate,
      timeRemaining,
      nextUpdate: cooldown.nextUpdate
    };
  }
  
  /**
   * Форматирует оставшееся время в формате MM:SS
   */
  private formatTimeRemaining(timeRemaining: number): string {
    const minutes = Math.floor(timeRemaining / 60000);
    const seconds = Math.floor((timeRemaining % 60000) / 1000);
    return `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
  }

  async updatePrice(req: AuthRequest, res: Response, next: NextFunction) {
    try {
      if (!req.init) {
        return res.status(500).json({ message: 'Не удалось инициализировать запрос' });
      }

      const { productId } = req.params;

      if (!productId) {
        return res.status(400).json({ message: 'ID товара не указан' });
      }

      const product = await this.productService.getProductById(productId);

      if (!product) {
        return res.status(404).json({ message: 'Товар не найден' });
      }

      if (req.user && product.userId !== req.user.id && !req.user.isAdmin) {
        return res.status(403).json({ message: 'Нет доступа к обновлению цены этого товара' });
      }

      try {
        // Используем Python-парсер для получения актуальных данных о товаре
        console.log(`Updating price for product: ${product.name} (${product.url})`);
        
        // Сначала пробуем новый Python-парсер
        let productDetails: ProductParserResult;
        let isPythonResult = false;
        
        try {
          productDetails = await PythonParserService.updateProductPrice(product.url);
          isPythonResult = true;
        } catch (error) {
          console.warn(`Python parser failed, falling back to JavaScript parser:`, error);
          // В случае ошибки используем существующий JavaScript-парсер
          productDetails = await NewParserService.updateProductPrice(product.url);
        }
        
        // Проверяем успешность выполнения (только для Python результата)
        if (isPythonResult && !(productDetails as PythonProductDetails).success) {
          return res.status(500).json({ 
            message: 'Не удалось получить данные о товаре',
            error: (productDetails as PythonProductDetails).error || 'Unknown error'
          });
        }

        console.log(`Parsed product details:`, productDetails);

        // Создаем новую запись о цене
        const newPrice = await this.priceService.createPrice({
          productId: product.id,
          price: productDetails.price,
          date: new Date()
        });

        // Обновляем данные о товаре, если получилось спарсить новую информацию
        let updatedFields: Record<string, any> = {};
        
        if (productDetails.name && productDetails.name !== product.name) {
          updatedFields = { ...updatedFields, name: productDetails.name };
        }

        if (productDetails.imageUrl && productDetails.imageUrl !== product.imageUrl) {
          updatedFields = { ...updatedFields, imageUrl: productDetails.imageUrl };
        }
        
        // Если определился маркетплейс из URL и это результат Python-парсера
        if (isPythonResult) {
          const pythonResult = productDetails as PythonProductDetails;
          if (pythonResult.marketplace && pythonResult.marketplace !== 'unknown' && 
              pythonResult.marketplace !== product.marketplace) {
            updatedFields = { ...updatedFields, marketplace: pythonResult.marketplace };
          }
        }
        
        // Обновляем продукт, если есть что обновлять
        if (Object.keys(updatedFields).length > 0) {
          await this.productService.updateProduct(product.id, updatedFields);
        }

        // Подготавливаем ответ
        const response: Record<string, any> = {
          message: 'Цена успешно обновлена',
          price: newPrice,
          currentPrice: productDetails.price,
          originalPrice: productDetails.originalPrice || null,
          discount: productDetails.discount || null,
          name: productDetails.name || product.name,
          imageUrl: productDetails.imageUrl || product.imageUrl
        };
        
        // Добавляем маркетплейс в ответ, если это результат Python-парсера
        if (isPythonResult) {
          response.marketplace = (productDetails as PythonProductDetails).marketplace || product.marketplace;
        }
        
        // Возвращаем результат
        return res.status(200).json(response);
      } catch (error: any) {
        console.error('Error updating price:', error);
        
        // Проверяем, прошло ли достаточно времени с последнего обновления
        const cooldown = await this.priceService.getUpdateCooldown(productId);
        
        if (cooldown && cooldown > 0) {
          return res.status(429).json({
            message: `Слишком частое обновление. Пожалуйста, подождите ${cooldown} секунд.`,
            cooldown
          });
        }
        
        return res.status(500).json({ 
          message: 'Не удалось обновить цену товара',
          error: error.message
        });
      }
    } catch (error: any) {
      console.error('Error in updatePrice controller:', error);
      next(error);
    }
  }

  async getPrices(req: Request, res: Response) {
    try {
      await this.ensureInitialized();

      const productId = parseInt(req.params.productId);
      if (isNaN(productId)) {
        return res.status(400).json({ 
          success: false, 
          error: 'Invalid product ID. Please provide a valid number.' 
        });
      }

      // Проверяем, существует ли продукт
      const productExists = await this.productRepository.findOne({
        where: { id: productId }
      });

      if (!productExists) {
        return res.status(404).json({ 
          success: false, 
          error: 'Product not found. The requested product does not exist.' 
        });
      }

      const prices = await this.priceRepository.find({
        where: { product: { id: productId } },
        order: { createdAt: 'DESC' } // Используем createdAt вместо date
      });
      
      // Получаем информацию о кулдауне для продукта
      const cooldownInfo = this.getCooldownInfo(productId);

      return res.status(200).json({
        success: true,
        data: prices,
        cooldown: {
          canUpdate: cooldownInfo.canUpdate,
          timeRemaining: cooldownInfo.timeRemaining,
          nextUpdate: cooldownInfo.nextUpdate,
          formattedTime: this.formatTimeRemaining(cooldownInfo.timeRemaining)
        }
      });
    } catch (err) {
      const error = err instanceof Error ? err : new Error('Unknown error');
      console.error('Error in getPrices:', error.message);
      
      return res.status(500).json({ 
        success: false, 
        error: 'Failed to get prices: ' + error.message 
      });
    }
  }
  
  /**
   * Возвращает время до следующего возможного обновления цены
   */
  public async getUpdateCooldown(req: Request, res: Response): Promise<Response> {
    try {
      const productId = req.params.productId;
      if (!productId) {
        return res.status(400).json({ success: false, message: 'Product ID is required' });
      }

      const product = await this.productRepository.findOne({
        where: { id: parseInt(productId) },
        relations: ['prices'],
      });

      if (!product) {
        return res.status(404).json({ success: false, message: 'Product not found' });
      }

      // Если нет цен, значит обновление возможно сразу
      if (!product.prices || product.prices.length === 0) {
        return res.status(200).json({ cooldown: 0, canUpdate: true });
      }

      // Находим последнюю цену
      const latestPrice = product.prices.sort((a, b) => 
        new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
      )[0];

      const lastUpdateTime = new Date(latestPrice.createdAt).getTime();
      const currentTime = Date.now();
      const timeSinceLastUpdate = currentTime - lastUpdateTime;

      // Если прошло достаточно времени с последнего обновления
      if (timeSinceLastUpdate >= PriceController.COOLDOWN_PERIOD) {
        return res.status(200).json({ cooldown: 0, canUpdate: true });
      }

      // Иначе вычисляем оставшееся время
      const remainingCooldown = Math.ceil((PriceController.COOLDOWN_PERIOD - timeSinceLastUpdate) / 1000);
      return res.status(200).json({ 
        cooldown: remainingCooldown, 
        canUpdate: false,
        message: `Please wait ${remainingCooldown} seconds before updating the price again`
      });
    } catch (error: any) {
      console.error('Error getting update cooldown:', error);
      return res.status(500).json({ success: false, message: 'Internal server error', error: error.message });
    }
  }
} 