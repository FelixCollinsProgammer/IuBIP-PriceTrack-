import { Request, Response } from 'express';
import { AppDataSource } from '../data-source';
import { Product } from '../entities/Product';
import { Price } from '../entities/Price';
import { ParserService } from '../services/ParserService';
import { Repository } from 'typeorm';
import { User } from '../entities/User';

// Расширение типа Request для включения пользователя
declare global {
  namespace Express {
    interface Request {
      user?: User;
    }
  }
}

// Import ProductDetails type or interface
interface ProductDetails {
  name: string;
  price: number;
  imageUrl: string;
}

export class ProductController {
  private productRepository: Repository<Product>;
  private priceRepository: Repository<Price>;
  private userRepository: Repository<User>;
  private initialized: boolean = false;

  constructor() {
    // Методы привязываются в методе initialize
    this.initialize().catch(err => {
      console.error('Failed to initialize ProductController:', err);
    });
  }

  private async initialize() {
    try {
      // Проверяем, инициализирован ли AppDataSource
      if (!AppDataSource.isInitialized) {
        await AppDataSource.initialize();
      }
      
      this.productRepository = AppDataSource.getRepository(Product);
      this.priceRepository = AppDataSource.getRepository(Price);
      this.userRepository = AppDataSource.getRepository(User);
      
      // Привязка методов к this
      this.addProduct = this.addProduct.bind(this);
      this.getProducts = this.getProducts.bind(this);
      this.getProduct = this.getProduct.bind(this);
      this.deleteProduct = this.deleteProduct.bind(this);
      
      this.initialized = true;
      console.log('ProductController initialized successfully');
    } catch (err) {
      this.initialized = false;
      const error = err instanceof Error ? err : new Error('Unknown error during initialization');
      console.error('Failed to initialize ProductController:', error.message);
      throw error;
    }
  }

  private async ensureInitialized() {
    if (!this.initialized) {
      await this.initialize();
      
      if (!this.initialized) {
        throw new Error('Failed to initialize repositories');
      }
    }
  }

  /**
   * Инициализирует запрос, проверяя наличие пользователя
   */
  private initializeRequest(req: Request): void {
    // В демо режиме, если нет авторизации, используем null
    if (!req.user && process.env.DEMO_MODE === 'true') {
      console.log('DEMO MODE: Auto-authenticating user');
      // Установим пустой объект для совместимости типов
      req.user = undefined;
    }
  }

  /**
   * Добавляет новый товар
   */
  async addProduct(req: Request, res: Response): Promise<void> {
    this.initializeRequest(req);
    
    try {
      console.log('Attempting to add product with URL:', req.body.url);
      const { url, category } = req.body;
      
      // Проверка URL
      if (!url) {
        res.status(400).json({ message: 'URL обязателен' });
        return;
      }
      
      // Проверяем, есть ли уже такой продукт
      const existingProduct = await this.productRepository.findOne({ where: { url } });
      if (existingProduct) {
        res.status(400).json({ message: 'Товар с таким URL уже существует' });
        return;
      }
      
      let productDetails: ProductDetails;
      let parsingError = false;
      let errorMessage = '';
      
      try {
        // Парсим URL для получения информации о товаре
        productDetails = await ParserService.parseUrl(url);
        console.log('Parsed product details:', productDetails);
      } catch (error) {
        console.error('Error parsing product URL:', error);
        // Если не удалось распарсить, создаем заглушку
        parsingError = true;
        errorMessage = error instanceof Error ? error.message : 'Не удалось получить данные о товаре';
        
        const marketplace = ParserService.getMarketplaceFromUrl(url);
        let placeholderName = `Товар с ${marketplace}`;
        
        // Для коротких ссылок Ozon добавляем уточнение
        if (url.includes('ozon.ru/t/') || url.includes('ozon.ru/share/')) {
          placeholderName = `Товар с Ozon (короткая ссылка)`;
        }
        
        productDetails = {
          name: placeholderName,
          price: 0,
          imageUrl: ParserService.getMarketplacePlaceholder(marketplace)
        };
      }
      
      // Создаем новый товар
      const product = new Product();
      product.name = productDetails.name;
      product.url = url;
      product.imageUrl = productDetails.imageUrl;
      product.currentPrice = productDetails.price || 0; // Устанавливаем 0, если price null
      product.userId = null;
      
      // Если пользователь указал категорию, используем ее, иначе - значение по умолчанию
      product.category = category || 'Электроника';
      
      // Определяем маркетплейс из URL
      product.marketplace = ParserService.getMarketplaceFromUrl(url);
      
      // Если цена 0 и произошла ошибка парсинга, сохраняем продукт,
      // но помечаем для последующей обработки
      const savedProduct = await this.productRepository.save(product);
      console.log('Product saved:', savedProduct);
      
      // Создаем первую запись в истории цен
      const price = new Price();
      price.price = productDetails.price;
      price.product = savedProduct;
      await this.priceRepository.save(price);
      
      // Если цена равна 0, помечаем для повторной попытки парсинга через некоторое время
      if (productDetails.price === 0) {
        // Здесь можно добавить логику для планирования повторной попытки парсинга
        console.log(`Product ${savedProduct.id} saved with price 0, will retry parsing later`);
        
        // Запланировать повторный парсинг через 10 минут
        setTimeout(async () => {
          try {
            console.log(`Retrying parsing for product ${savedProduct.id} (${url})`);
            const updatedDetails = await ParserService.parseUrl(url);
            
            if (updatedDetails.price > 0) {
              console.log(`Successfully updated price for product ${savedProduct.id}: ${updatedDetails.price}`);
              
              // Обновляем продукт
              savedProduct.currentPrice = updatedDetails.price;
              savedProduct.name = updatedDetails.name || savedProduct.name;
              savedProduct.imageUrl = updatedDetails.imageUrl || savedProduct.imageUrl;
              await this.productRepository.save(savedProduct);
              
              // Добавляем новую запись цены
              const newPrice = new Price();
              newPrice.price = updatedDetails.price;
              newPrice.product = savedProduct;
              await this.priceRepository.save(newPrice);
            } else {
              console.log(`Still could not get price for product ${savedProduct.id}`);
            }
          } catch (retryError) {
            console.error(`Error during retry parsing for product ${savedProduct.id}:`, retryError);
          }
        }, 10 * 60 * 1000); // 10 минут
      }
      
      // Если была ошибка парсинга, но мы все равно создали товар,
      // возвращаем предупреждение вместе с данными товара
      if (parsingError) {
        res.status(201).json({
          product: savedProduct,
          warning: 'Товар добавлен, но произошла ошибка при получении данных. Цены будут обновлены позже.',
          error: errorMessage
        });
      } else {
        res.status(201).json({ product: savedProduct });
      }
    } catch (error) {
      console.error('Error in ProductController.addProduct:', error);
      // Более подробное логирование для диагностики
      console.error('Error details:', JSON.stringify(error, Object.getOwnPropertyNames(error)));
      res.status(500).json({ message: 'Внутренняя ошибка сервера при добавлении товара' });
    }
  }

  async getProducts(req: Request, res: Response) {
    try {
      console.log('GET /products endpoint called');
      console.log('Origin header:', req.headers.origin);
      console.log('Request query:', req.query);
      
      // Добавляем CORS-заголовки вручную
      res.header('Access-Control-Allow-Origin', '*');
      res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE');
      res.header('Access-Control-Allow-Headers', 'Content-Type, Authorization');

      await this.ensureInitialized();

      const { category } = req.query;
      
      const queryBuilder = this.productRepository
        .createQueryBuilder('product')
        .leftJoinAndSelect('product.prices', 'price')
        .orderBy('product.id', 'DESC');
      
      if (category) {
        queryBuilder.where('product.category = :category', { category });
      }

      const products = await queryBuilder.getMany();

      const formattedProducts = products.map(product => {
        return {
          id: product.id,
          name: product.name,
          url: product.url,
          imageUrl: product.imageUrl,
          currentPrice: product.currentPrice,
          category: product.category,
          marketplace: product.marketplace,
          createdAt: product.createdAt
        };
      });

      return res.status(200).json({
        success: true,
        data: formattedProducts
      });
    } catch (err) {
      const error = err instanceof Error ? err : new Error('Unknown error');
      console.error('Error getting products:', error.message);
      
      return res.status(500).json({ 
        success: false, 
        error: 'Failed to get products: ' + error.message 
      });
    }
  }

  async getProduct(req: Request, res: Response) {
    try {
      await this.ensureInitialized();

      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ 
          success: false, 
          error: 'Invalid product ID. Please provide a valid number.' 
        });
      }

      const product = await this.productRepository.findOne({
        where: { id },
        relations: ['prices']
      });

      if (!product) {
        return res.status(404).json({ 
          success: false, 
          error: 'Product not found. The requested product does not exist.' 
        });
      }

      return res.status(200).json({
        success: true,
        data: {
          id: product.id,
          name: product.name,
          url: product.url,
          imageUrl: product.imageUrl,
          currentPrice: product.currentPrice,
          createdAt: product.createdAt,
          prices: product.prices
        }
      });
    } catch (err) {
      const error = err instanceof Error ? err : new Error('Unknown error');
      console.error('Error getting product:', error.message);
      
      return res.status(500).json({ 
        success: false, 
        error: 'Failed to get product: ' + error.message 
      });
    }
  }

  async deleteProduct(req: Request, res: Response) {
    try {
      await this.ensureInitialized();

      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ 
          success: false, 
          error: 'Invalid product ID. Please provide a valid number.' 
        });
      }

      const product = await this.productRepository.findOne({
        where: { id },
        select: ['id'] // Загружаем только ID, это всё что нам нужно
      });

      if (!product) {
        return res.status(404).json({ 
          success: false, 
          error: 'Product not found. The requested product does not exist.' 
        });
      }

      // Удаление связанных цен
      await this.priceRepository.delete({ product: { id } });
      
      // Удаление продукта
      await this.productRepository.delete(id);

      return res.status(200).json({
        success: true,
        message: 'Product deleted successfully'
      });
    } catch (err) {
      const error = err instanceof Error ? err : new Error('Unknown error');
      console.error('Error deleting product:', error.message);
      
      return res.status(500).json({ 
        success: false, 
        error: 'Failed to delete product: ' + error.message 
      });
    }
  }

  // Вспомогательный метод для определения маркетплейса из URL
  private getMarketplaceFromUrl(url: string): string {
    try {
      if (url.includes('ozon.ru')) return 'Ozon';
      if (url.includes('wildberries.ru')) return 'Wildberries';
      if (url.includes('aliexpress')) return 'AliExpress';
      
      const domain = new URL(url).hostname.replace('www.', '');
      return domain.split('.')[0] || 'Unknown';
    } catch {
      return 'Unknown';
    }
  }

  // Добавляем новый метод для получения списка категорий
  async getCategories(req: Request, res: Response) {
    try {
      await this.ensureInitialized();
      
      const categories = await this.productRepository
        .createQueryBuilder('product')
        .select('product.category')
        .distinct(true)
        .getRawMany();
      
      const categoryList = categories.map(item => item.product_category);
      
      return res.status(200).json({
        success: true,
        data: categoryList
      });
    } catch (err) {
      const error = err instanceof Error ? err : new Error('Unknown error');
      console.error('Error getting categories:', error.message);
      
      return res.status(500).json({ 
        success: false, 
        error: 'Failed to get categories: ' + error.message 
      });
    }
  }

  // Метод для обновления категории товара
  async updateCategory(req: Request, res: Response) {
    try {
      await this.ensureInitialized();

      const id = parseInt(req.params.id);
      const { category } = req.body;
      
      if (isNaN(id)) {
        return res.status(400).json({ 
          success: false, 
          error: 'Invalid product ID. Please provide a valid number.' 
        });
      }
      
      if (!category || typeof category !== 'string') {
        return res.status(400).json({ 
          success: false, 
          error: 'Category is required and must be a string.' 
        });
      }
      
      const product = await this.productRepository.findOne({
        where: { id }
      });
      
      if (!product) {
        return res.status(404).json({ 
          success: false, 
          error: 'Product not found. The requested product does not exist.' 
        });
      }
      
      product.category = category;
      await this.productRepository.save(product);
      
      return res.status(200).json({
        success: true,
        data: {
          id: product.id,
          name: product.name,
          category: product.category
        }
      });
    } catch (err) {
      const error = err instanceof Error ? err : new Error('Unknown error');
      console.error('Error updating category:', error.message);
      
      return res.status(500).json({ 
        success: false, 
        error: 'Failed to update category: ' + error.message 
      });
    }
  }

  // Метод для обновления товара
  async updateProduct(req: Request, res: Response) {
    try {
      await this.ensureInitialized();

      const id = parseInt(req.params.id);
      const { category, marketplace } = req.body;
      
      if (isNaN(id)) {
        return res.status(400).json({ 
          success: false, 
          error: 'Invalid product ID. Please provide a valid number.' 
        });
      }
      
      const product = await this.productRepository.findOne({
        where: { id }
      });
      
      if (!product) {
        return res.status(404).json({ 
          success: false, 
          error: 'Product not found. The requested product does not exist.' 
        });
      }
      
      // Update category if provided
      if (category !== undefined) {
        product.category = category;
      }
      
      // Update marketplace if provided
      if (marketplace !== undefined) {
        product.marketplace = marketplace;
      }
      
      await this.productRepository.save(product);
      
      return res.status(200).json({
        success: true,
        data: {
          id: product.id,
          name: product.name,
          url: product.url,
          imageUrl: product.imageUrl,
          currentPrice: product.currentPrice,
          category: product.category,
          marketplace: product.marketplace,
          createdAt: product.createdAt
        }
      });
    } catch (err) {
      const error = err instanceof Error ? err : new Error('Unknown error');
      console.error('Error updating product:', error.message);
      
      return res.status(500).json({ 
        success: false, 
        error: 'Failed to update product: ' + error.message 
      });
    }
  }
} 