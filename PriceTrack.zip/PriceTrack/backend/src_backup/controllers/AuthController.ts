import { Request, Response } from 'express';
import { User } from '../entities/User';
import { AppDataSource } from '../data-source';
import * as bcrypt from 'bcrypt';
import * as jwt from 'jsonwebtoken';
import * as crypto from 'crypto';
import * as nodemailer from 'nodemailer';
import { MoreThan } from 'typeorm';

export class AuthController {
  private userRepository = AppDataSource.getRepository(User);
  private jwtSecret = process.env.JWT_SECRET || 'default-secret-key-change-in-production';
  private emailTransport = nodemailer.createTransport({
    host: process.env.SMTP_HOST || 'smtp.gmail.com',
    port: parseInt(process.env.SMTP_PORT || '587'),
    secure: process.env.SMTP_SECURE === 'true',
    auth: {
      user: process.env.SMTP_USER || '',
      pass: process.env.SMTP_PASS || ''
    }
  });
  private adminEmail = process.env.ADMIN_EMAIL || '';

  constructor() {
    this.register = this.register.bind(this);
    this.login = this.login.bind(this);
    this.forgotPassword = this.forgotPassword.bind(this);
    this.resetPassword = this.resetPassword.bind(this);
    this.getProfile = this.getProfile.bind(this);
    this.updateProfile = this.updateProfile.bind(this);
  }

  async register(req: Request, res: Response) {
    try {
      const { firstName, lastName, email, password } = req.body;

      // Проверка на наличие всех необходимых полей
      if (!firstName || !lastName || !email || !password) {
        return res.status(400).json({
          success: false,
          message: 'Все поля (имя, фамилия, email, пароль) обязательны для заполнения'
        });
      }

      // Проверка формата email
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(email)) {
        return res.status(400).json({
          success: false,
          message: 'Некорректный формат email'
        });
      }

      // Проверка длины пароля
      if (password.length < 6) {
        return res.status(400).json({
          success: false,
          message: 'Пароль должен содержать не менее 6 символов'
        });
      }

      // Проверка существования пользователя
      const existingUser = await this.userRepository.findOne({ where: { email } });
      if (existingUser) {
        return res.status(400).json({
          success: false,
          message: 'Пользователь с таким email уже существует'
        });
      }

      // Генерация токена для верификации email
      const verificationToken = crypto.randomBytes(32).toString('hex');

      // Создание нового пользователя
      const user = this.userRepository.create({
        firstName,
        lastName,
        email,
        password,
        verificationToken
      });

      await this.userRepository.save(user);

      // Отправка письма с верификацией
      try {
        const verificationUrl = `${req.protocol}://${req.get('host')}/api/auth/verify-email/${verificationToken}`;
        
        await this.emailTransport.sendMail({
          from: `"PriceTrack" <${this.adminEmail}>`,
          to: email,
          subject: 'Подтверждение регистрации в PriceTrack',
          html: `
            <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
              <h2>Здравствуйте, ${firstName}!</h2>
              <p>Благодарим вас за регистрацию в сервисе PriceTrack. Для завершения регистрации, пожалуйста, 
              подтвердите свой email, перейдя по ссылке ниже:</p>
              <p><a href="${verificationUrl}" style="display: inline-block; padding: 10px 20px; background-color: #2563eb; color: white; text-decoration: none; border-radius: 4px;">Подтвердить email</a></p>
              <p>Если вы не регистрировались на нашем сайте, просто проигнорируйте это письмо.</p>
              <p>С уважением,<br>Команда PriceTrack</p>
            </div>
          `
        });
        
        console.log('Verification email sent to:', email);
      } catch (emailError) {
        console.error('Error sending verification email:', emailError);
        // Ошибка отправки письма не блокирует регистрацию пользователя
      }

      return res.status(201).json({
        success: true,
        message: 'Регистрация успешна. Пожалуйста, проверьте вашу почту для подтверждения аккаунта'
      });
    } catch (error) {
      console.error('Registration error:', error);
      return res.status(500).json({
        success: false,
        message: 'Ошибка при регистрации. Пожалуйста, попробуйте позже'
      });
    }
  }

  async login(req: Request, res: Response) {
    try {
      const { email, password } = req.body;

      if (!email || !password) {
        return res.status(400).json({
          success: false,
          message: 'Email и пароль обязательны для входа'
        });
      }

      // Получаем пользователя по email с паролем
      const user = await this.userRepository
        .createQueryBuilder('user')
        .addSelect('user.password')
        .where('user.email = :email', { email })
        .getOne();

      if (!user) {
        return res.status(401).json({
          success: false,
          message: 'Неверный email или пароль'
        });
      }

      // Проверка пароля
      const isPasswordValid = await bcrypt.compare(password, user.password);
      if (!isPasswordValid) {
        return res.status(401).json({
          success: false,
          message: 'Неверный email или пароль'
        });
      }

      // Проверка верификации email
      if (!user.isEmailVerified) {
        return res.status(401).json({
          success: false,
          message: 'Пожалуйста, подтвердите свой email перед входом'
        });
      }

      // Генерация JWT токена
      const token = jwt.sign(
        { id: user.id, email: user.email, isAdmin: user.isAdmin },
        this.jwtSecret,
        { expiresIn: '7d' }
      );

      // Скрываем пароль из ответа
      const { password: _, ...userWithoutPassword } = user;

      return res.status(200).json({
        success: true,
        message: 'Успешный вход',
        token,
        user: userWithoutPassword
      });
    } catch (error) {
      console.error('Login error:', error);
      return res.status(500).json({
        success: false,
        message: 'Ошибка при входе. Пожалуйста, попробуйте позже'
      });
    }
  }

  async verifyEmail(req: Request, res: Response) {
    try {
      const { token } = req.params;

      const user = await this.userRepository.findOne({
        where: { verificationToken: token }
      });

      if (!user) {
        return res.status(400).json({
          success: false,
          message: 'Недействительный или устаревший токен верификации'
        });
      }

      user.isEmailVerified = true;
      user.verificationToken = '';
      await this.userRepository.save(user);

      return res.status(200).json({
        success: true,
        message: 'Email успешно подтвержден. Теперь вы можете войти в ваш аккаунт'
      });
    } catch (error) {
      console.error('Email verification error:', error);
      return res.status(500).json({
        success: false,
        message: 'Ошибка при верификации email. Пожалуйста, попробуйте позже'
      });
    }
  }

  async forgotPassword(req: Request, res: Response) {
    try {
      const { email } = req.body;

      if (!email) {
        return res.status(400).json({
          success: false,
          message: 'Email обязателен'
        });
      }

      const user = await this.userRepository.findOne({ where: { email } });
      if (!user) {
        // По соображениям безопасности не раскрываем, существует ли пользователь
        return res.status(200).json({
          success: true,
          message: 'Если пользователь с указанным email существует, инструкции по сбросу пароля будут отправлены'
        });
      }

      // Генерация токена для сброса пароля
      const resetToken = crypto.randomBytes(32).toString('hex');
      const resetTokenExpires = new Date();
      resetTokenExpires.setHours(resetTokenExpires.getHours() + 1); // Токен действителен 1 час

      user.resetPasswordToken = resetToken;
      user.resetPasswordExpires = resetTokenExpires;
      await this.userRepository.save(user);

      // Отправка письма с инструкциями по сбросу пароля
      try {
        const resetUrl = `${req.protocol}://${req.get('host')}/reset-password/${resetToken}`;
        
        await this.emailTransport.sendMail({
          from: `"PriceTrack" <${this.adminEmail}>`,
          to: email,
          subject: 'Сброс пароля в PriceTrack',
          html: `
            <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
              <h2>Сброс пароля</h2>
              <p>Вы (или кто-то другой) запросили сброс пароля для вашего аккаунта в PriceTrack.</p>
              <p>Для сброса пароля перейдите по ссылке ниже:</p>
              <p><a href="${resetUrl}" style="display: inline-block; padding: 10px 20px; background-color: #2563eb; color: white; text-decoration: none; border-radius: 4px;">Сбросить пароль</a></p>
              <p>Эта ссылка действительна в течение 1 часа.</p>
              <p>Если вы не запрашивали сброс пароля, просто проигнорируйте это письмо.</p>
              <p>С уважением,<br>Команда PriceTrack</p>
            </div>
          `
        });
        
        console.log('Password reset email sent to:', email);
      } catch (emailError) {
        console.error('Error sending password reset email:', emailError);
        // Ошибка отправки письма не блокирует процесс
      }

      return res.status(200).json({
        success: true,
        message: 'Если пользователь с указанным email существует, инструкции по сбросу пароля будут отправлены'
      });
    } catch (error) {
      console.error('Forgot password error:', error);
      return res.status(500).json({
        success: false,
        message: 'Ошибка при обработке запроса на сброс пароля. Пожалуйста, попробуйте позже'
      });
    }
  }

  async resetPassword(req: Request, res: Response) {
    try {
      const { token } = req.params;
      const { password } = req.body;

      if (!password) {
        return res.status(400).json({
          success: false,
          message: 'Необходимо указать новый пароль'
        });
      }

      if (password.length < 6) {
        return res.status(400).json({
          success: false,
          message: 'Пароль должен содержать не менее 6 символов'
        });
      }

      const user = await this.userRepository.findOne({
        where: {
          resetPasswordToken: token,
          resetPasswordExpires: MoreThan(new Date())
        }
      });

      if (!user) {
        return res.status(400).json({
          success: false,
          message: 'Недействительный или устаревший токен для сброса пароля'
        });
      }

      // Обновление пароля
      user.password = await bcrypt.hash(password, 10);
      user.resetPasswordToken = '';
      user.resetPasswordExpires = new Date();
      await this.userRepository.save(user);

      return res.status(200).json({
        success: true,
        message: 'Пароль успешно изменен. Теперь вы можете войти с новым паролем'
      });
    } catch (error) {
      console.error('Reset password error:', error);
      return res.status(500).json({
        success: false,
        message: 'Ошибка при сбросе пароля. Пожалуйста, попробуйте позже'
      });
    }
  }

  async getProfile(req: Request, res: Response) {
    try {
      if (!req.user) {
        return res.status(401).json({
          success: false,
          message: 'Пользователь не аутентифицирован'
        });
      }

      const userId = req.user.id;
      const user = await this.userRepository.findOne({ where: { id: userId } });

      if (!user) {
        return res.status(404).json({
          success: false,
          message: 'Пользователь не найден'
        });
      }

      const { password, resetPasswordToken, resetPasswordExpires, verificationToken, ...userProfile } = user;

      return res.status(200).json({
        success: true,
        user: userProfile
      });
    } catch (error) {
      console.error('Get profile error:', error);
      return res.status(500).json({
        success: false,
        message: 'Ошибка при получении профиля. Пожалуйста, попробуйте позже'
      });
    }
  }

  async updateProfile(req: Request, res: Response) {
    try {
      if (!req.user) {
        return res.status(401).json({
          success: false,
          message: 'Пользователь не аутентифицирован'
        });
      }
      
      const userId = req.user.id;
      const { firstName, lastName } = req.body;
      
      if (!firstName && !lastName) {
        return res.status(400).json({
          success: false,
          message: 'Необходимо указать имя или фамилию для обновления'
        });
      }

      const user = await this.userRepository.findOne({ where: { id: userId } });
      if (!user) {
        return res.status(404).json({
          success: false,
          message: 'Пользователь не найден'
        });
      }

      if (firstName) user.firstName = firstName;
      if (lastName) user.lastName = lastName;

      await this.userRepository.save(user);

      const { password, resetPasswordToken, resetPasswordExpires, verificationToken, ...updatedProfile } = user;

      return res.status(200).json({
        success: true,
        message: 'Профиль успешно обновлен',
        user: updatedProfile
      });
    } catch (error) {
      console.error('Update profile error:', error);
      return res.status(500).json({
        success: false,
        message: 'Ошибка при обновлении профиля. Пожалуйста, попробуйте позже'
      });
    }
  }
} 