import { Request, Response } from 'express';
import { AppDataSource } from '../data-source';
import { User } from '../entities/User';
import { Ticket, TicketPriority, TicketStatus } from '../entities/Ticket';
import * as nodemailer from 'nodemailer';

export class TicketController {
  private ticketRepository = AppDataSource.getRepository(Ticket);
  private userRepository = AppDataSource.getRepository(User);
  private emailTransport = nodemailer.createTransport({
    host: process.env.SMTP_HOST || 'smtp.gmail.com',
    port: parseInt(process.env.SMTP_PORT || '587'),
    secure: process.env.SMTP_SECURE === 'true',
    auth: {
      user: process.env.SMTP_USER || '',
      pass: process.env.SMTP_PASS || ''
    }
  });
  private adminEmail = process.env.ADMIN_EMAIL || '';

  constructor() {
    this.createTicket = this.createTicket.bind(this);
    this.getUserTickets = this.getUserTickets.bind(this);
    this.getTicketById = this.getTicketById.bind(this);
    this.updateTicket = this.updateTicket.bind(this);
    this.respondToTicket = this.respondToTicket.bind(this);
    this.getAllTickets = this.getAllTickets.bind(this);
  }

  async createTicket(req: Request, res: Response) {
    try {
      const userId = req.user.id;
      const { subject, message, priority = TicketPriority.MEDIUM } = req.body;

      // Валидация данных
      if (!subject || !message) {
        return res.status(400).json({
          success: false,
          message: 'Тема и сообщение обязательны для создания тикета'
        });
      }

      // Получение пользователя
      const user = await this.userRepository.findOne({ where: { id: userId } });
      if (!user) {
        return res.status(404).json({
          success: false,
          message: 'Пользователь не найден'
        });
      }

      // Создание нового тикета
      const ticket = this.ticketRepository.create({
        subject,
        message,
        priority,
        user
      });

      await this.ticketRepository.save(ticket);

      // Отправка уведомления администратору
      try {
        await this.emailTransport.sendMail({
          from: `"PriceTrack System" <${process.env.SMTP_USER || 'noreply@pricetrack.com'}>`,
          to: this.adminEmail,
          subject: `Новый тикет: ${subject}`,
          html: `
            <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
              <h2>Новый тикет в системе PriceTrack</h2>
              <p><strong>От пользователя:</strong> ${user.firstName} ${user.lastName} (${user.email})</p>
              <p><strong>Тема:</strong> ${subject}</p>
              <p><strong>Приоритет:</strong> ${priority}</p>
              <p><strong>Сообщение:</strong></p>
              <div style="background-color: #f9f9f9; padding: 15px; border-radius: 5px; margin: 10px 0;">
                ${message.replace(/\n/g, '<br>')}
              </div>
              <p><a href="${req.protocol}://${req.get('host')}/admin/tickets/${ticket.id}" style="display: inline-block; padding: 10px 20px; background-color: #2563eb; color: white; text-decoration: none; border-radius: 4px;">Ответить на тикет</a></p>
            </div>
          `
        });
        
        console.log('Ticket notification email sent to admin');
      } catch (emailError) {
        console.error('Error sending ticket notification email:', emailError);
        // Ошибка отправки письма не блокирует создание тикета
      }

      return res.status(201).json({
        success: true,
        message: 'Тикет успешно создан',
        ticket: {
          id: ticket.id,
          subject: ticket.subject,
          message: ticket.message,
          status: ticket.status,
          priority: ticket.priority,
          createdAt: ticket.createdAt
        }
      });
    } catch (error) {
      console.error('Create ticket error:', error);
      return res.status(500).json({
        success: false,
        message: 'Ошибка при создании тикета. Пожалуйста, попробуйте позже'
      });
    }
  }

  async getUserTickets(req: Request, res: Response) {
    try {
      const userId = req.user.id;

      const tickets = await this.ticketRepository.find({
        where: { user: { id: userId } },
        order: { createdAt: 'DESC' }
      });

      return res.status(200).json({
        success: true,
        tickets
      });
    } catch (error) {
      console.error('Get user tickets error:', error);
      return res.status(500).json({
        success: false,
        message: 'Ошибка при получении тикетов. Пожалуйста, попробуйте позже'
      });
    }
  }

  async getTicketById(req: Request, res: Response) {
    try {
      const userId = req.user.id;
      const { id } = req.params;

      const ticket = await this.ticketRepository.findOne({
        where: { id: parseInt(id), user: { id: userId } },
        relations: ['user']
      });

      if (!ticket) {
        return res.status(404).json({
          success: false,
          message: 'Тикет не найден'
        });
      }

      return res.status(200).json({
        success: true,
        ticket
      });
    } catch (error) {
      console.error('Get ticket by id error:', error);
      return res.status(500).json({
        success: false,
        message: 'Ошибка при получении тикета. Пожалуйста, попробуйте позже'
      });
    }
  }

  async updateTicket(req: Request, res: Response) {
    try {
      const userId = req.user.id;
      const { id } = req.params;
      const { message } = req.body;

      if (!message) {
        return res.status(400).json({
          success: false,
          message: 'Сообщение обязательно для обновления'
        });
      }

      const ticket = await this.ticketRepository.findOne({
        where: { id: parseInt(id), user: { id: userId } },
        relations: ['user']
      });

      if (!ticket) {
        return res.status(404).json({
          success: false,
          message: 'Тикет не найден'
        });
      }

      // Обновление возможно только для открытых тикетов
      if (ticket.status !== TicketStatus.OPEN && ticket.status !== TicketStatus.IN_PROGRESS) {
        return res.status(400).json({
          success: false,
          message: 'Нельзя обновить закрытый или решенный тикет'
        });
      }

      // Добавление нового сообщения в тикет (аппенд)
      const updatedMessage = `${ticket.message}\n\n--- ${new Date().toLocaleString()} (Пользователь) ---\n${message}`;
      ticket.message = updatedMessage;

      // Если статус был Resolved, меняем на In Progress
      if (ticket.status === TicketStatus.RESOLVED) {
        ticket.status = TicketStatus.IN_PROGRESS;
      }

      await this.ticketRepository.save(ticket);

      // Отправка уведомления администратору
      try {
        await this.emailTransport.sendMail({
          from: `"PriceTrack System" <${process.env.SMTP_USER || 'noreply@pricetrack.com'}>`,
          to: this.adminEmail,
          subject: `Обновление тикета: ${ticket.subject}`,
          html: `
            <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
              <h2>Обновление тикета в системе PriceTrack</h2>
              <p><strong>От пользователя:</strong> ${ticket.user.firstName} ${ticket.user.lastName} (${ticket.user.email})</p>
              <p><strong>Тема:</strong> ${ticket.subject}</p>
              <p><strong>Новое сообщение:</strong></p>
              <div style="background-color: #f9f9f9; padding: 15px; border-radius: 5px; margin: 10px 0;">
                ${message.replace(/\n/g, '<br>')}
              </div>
              <p><a href="${req.protocol}://${req.get('host')}/admin/tickets/${ticket.id}" style="display: inline-block; padding: 10px 20px; background-color: #2563eb; color: white; text-decoration: none; border-radius: 4px;">Ответить на тикет</a></p>
            </div>
          `
        });
        
        console.log('Ticket update notification email sent to admin');
      } catch (emailError) {
        console.error('Error sending ticket update notification email:', emailError);
      }

      return res.status(200).json({
        success: true,
        message: 'Тикет успешно обновлен',
        ticket
      });
    } catch (error) {
      console.error('Update ticket error:', error);
      return res.status(500).json({
        success: false,
        message: 'Ошибка при обновлении тикета. Пожалуйста, попробуйте позже'
      });
    }
  }

  // Метод для администраторов, чтобы ответить на тикет
  async respondToTicket(req: Request, res: Response) {
    try {
      const isAdmin = req.user.isAdmin;
      if (!isAdmin) {
        return res.status(403).json({
          success: false,
          message: 'Только администраторы могут отвечать на тикеты'
        });
      }

      const { id } = req.params;
      const { response, status } = req.body;

      if (!response) {
        return res.status(400).json({
          success: false,
          message: 'Ответ обязателен'
        });
      }

      const ticket = await this.ticketRepository.findOne({
        where: { id: parseInt(id) },
        relations: ['user']
      });

      if (!ticket) {
        return res.status(404).json({
          success: false,
          message: 'Тикет не найден'
        });
      }

      // Добавление ответа администратора и обновление статуса
      const updatedMessage = `${ticket.message}\n\n--- ${new Date().toLocaleString()} (Администратор) ---\n${response}`;
      ticket.message = updatedMessage;
      ticket.adminResponse = response;
      
      if (status && Object.values(TicketStatus).includes(status)) {
        ticket.status = status;
      } else {
        ticket.status = TicketStatus.IN_PROGRESS;
      }

      await this.ticketRepository.save(ticket);

      // Отправка уведомления пользователю
      try {
        await this.emailTransport.sendMail({
          from: `"PriceTrack Support" <${process.env.SMTP_USER || 'support@pricetrack.com'}>`,
          to: ticket.user.email,
          subject: `Ответ на ваш тикет: ${ticket.subject}`,
          html: `
            <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
              <h2>Ответ на ваш тикет в системе PriceTrack</h2>
              <p><strong>Тема:</strong> ${ticket.subject}</p>
              <p><strong>Статус:</strong> ${ticket.status}</p>
              <p><strong>Ответ администратора:</strong></p>
              <div style="background-color: #f9f9f9; padding: 15px; border-radius: 5px; margin: 10px 0;">
                ${response.replace(/\n/g, '<br>')}
              </div>
              <p><a href="${req.protocol}://${req.get('host')}/tickets/${ticket.id}" style="display: inline-block; padding: 10px 20px; background-color: #2563eb; color: white; text-decoration: none; border-radius: 4px;">Просмотреть тикет</a></p>
              <p>Вы можете ответить на это сообщение, добавив комментарий к тикету в вашем личном кабинете.</p>
            </div>
          `
        });
        
        console.log('Ticket response email sent to user');
      } catch (emailError) {
        console.error('Error sending ticket response email:', emailError);
      }

      return res.status(200).json({
        success: true,
        message: 'Ответ на тикет успешно отправлен',
        ticket
      });
    } catch (error) {
      console.error('Respond to ticket error:', error);
      return res.status(500).json({
        success: false,
        message: 'Ошибка при ответе на тикет. Пожалуйста, попробуйте позже'
      });
    }
  }

  // Метод для администраторов, чтобы получить все тикеты
  async getAllTickets(req: Request, res: Response) {
    try {
      const isAdmin = req.user.isAdmin;
      if (!isAdmin) {
        return res.status(403).json({
          success: false,
          message: 'Только администраторы могут просматривать все тикеты'
        });
      }

      const { status } = req.query;
      let whereClause: any = {};
      
      if (status && Object.values(TicketStatus).includes(status as TicketStatus)) {
        whereClause.status = status;
      }

      const tickets = await this.ticketRepository.find({
        where: whereClause,
        relations: ['user'],
        order: { 
          status: 'ASC', // Сначала открытые и в прогрессе
          createdAt: 'DESC' // Затем по дате создания (новые сверху)
        }
      });

      return res.status(200).json({
        success: true,
        count: tickets.length,
        tickets: tickets.map(ticket => ({
          ...ticket,
          user: {
            id: ticket.user.id,
            email: ticket.user.email,
            firstName: ticket.user.firstName,
            lastName: ticket.user.lastName
          }
        }))
      });
    } catch (error) {
      console.error('Get all tickets error:', error);
      return res.status(500).json({
        success: false,
        message: 'Ошибка при получении тикетов. Пожалуйста, попробуйте позже'
      });
    }
  }
} 