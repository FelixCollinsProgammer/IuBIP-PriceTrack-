import { Entity, PrimaryGeneratedColumn, Column, ManyToOne, CreateDateColumn } from 'typeorm';
import { Product } from './Product';

@Entity()
export class Price {
  @PrimaryGeneratedColumn()
  id: number;

  @Column('decimal', { precision: 10, scale: 2 })
  price: number;

  @CreateDateColumn()
  createdAt: Date;

  @ManyToOne(() => Product, product => product.prices, { onDelete: 'CASCADE' })
  product: Product;
} 