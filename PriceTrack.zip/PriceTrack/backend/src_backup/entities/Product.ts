import { Entity, PrimaryGeneratedColumn, Column, OneToMany, CreateDateColumn, ManyToOne, JoinColumn } from 'typeorm';
import { Price } from './Price';
import { User } from './User';

@Entity()
export class Product {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  name: string;

  @Column()
  url: string;

  @Column()
  imageUrl: string;

  @Column({ type: 'decimal', precision: 10, scale: 2, default: 0 })
  currentPrice: number;

  @Column({ nullable: true, default: 'Прочее' })
  category: string;

  @Column({ nullable: true })
  marketplace: string;

  @CreateDateColumn()
  createdAt: Date;

  @OneToMany(() => Price, price => price.product, { eager: true })
  prices: Price[];

  @Column({ nullable: true })
  userId: number | null;

  @ManyToOne(() => User, user => user.products, { nullable: true, onDelete: 'SET NULL' })
  @JoinColumn({ name: "userId" })
  user: User;

  getLatestPrice(): number {
    if (!this.prices || this.prices.length === 0) return 0;
    return this.prices[this.prices.length - 1].price;
  }
} 