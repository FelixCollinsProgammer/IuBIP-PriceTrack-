import { Request, Response, NextFunction } from 'express';
import * as jwt from 'jsonwebtoken';
import { AppDataSource } from '../data-source';
import { User } from '../entities/User';

// Расширяем интерфейс Request для включения пользователя
declare global {
  namespace Express {
    interface Request {
      user?: User;
    }
  }
}

interface JwtPayload {
  id: number;
  email: string;
  isAdmin: boolean;
}

export const authMiddleware = async (req: Request, res: Response, next: NextFunction) => {
  try {
    // ДЕМО-РЕЖИМ: автоматическая авторизация вместо проверки токена
    console.log('DEMO MODE: Auto-authenticating user');
    
    // Создаем демо-пользователя с ID 1
    // В реальном приложении здесь была бы проверка JWT токена
    const demoUser = new User();
    demoUser.id = 1;
    demoUser.email = 'demo@example.com';
    demoUser.firstName = 'Demo';
    demoUser.lastName = 'User';
    demoUser.isAdmin = true;
    
    // Прикрепляем пользователя к запросу
    req.user = demoUser;
    next();
    
    /* Original auth code (commented out for demo)
    // Извлечение токена из заголовка Authorization
    const authHeader = req.headers.authorization;
    
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({
        success: false,
        message: 'Доступ запрещен. Токен авторизации не предоставлен'
      });
    }

    const token = authHeader.split(' ')[1];
    
    // Проверка токена
    const jwtSecret = process.env.JWT_SECRET || 'default-secret-key-change-in-production';
    const decoded = jwt.verify(token, jwtSecret) as JwtPayload;
    
    // Получение пользователя из базы данных
    const user = await AppDataSource.getRepository(User).findOne({
      where: { id: decoded.id }
    });
    
    if (!user) {
      return res.status(401).json({
        success: false,
        message: 'Пользователь, связанный с токеном, не найден'
      });
    }
    
    // Добавление пользователя в объект запроса
    req.user = user;
    next();
    */
  } catch (error) {
    if (error instanceof jwt.JsonWebTokenError) {
      return res.status(401).json({
        success: false,
        message: 'Недействительный токен авторизации'
      });
    }
    
    if (error instanceof jwt.TokenExpiredError) {
      return res.status(401).json({
        success: false,
        message: 'Срок действия токена истек. Пожалуйста, войдите снова'
      });
    }
    
    console.error('Auth middleware error:', error);
    return res.status(500).json({
      success: false,
      message: 'Ошибка при авторизации. Пожалуйста, попробуйте позже'
    });
  }
};

// Middleware для проверки прав администратора
export const adminMiddleware = (req: Request, res: Response, next: NextFunction) => {
  if (!req.user || !req.user.isAdmin) {
    return res.status(403).json({
      success: false,
      message: 'Доступ запрещен. Требуются права администратора'
    });
  }
  next();
}; 