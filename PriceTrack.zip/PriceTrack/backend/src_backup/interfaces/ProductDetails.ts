export interface ProductDetails {
  name: string;
  imageUrl: string;
  price: number;
  marketplace: string;
} 