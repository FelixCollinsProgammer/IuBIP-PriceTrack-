import { Router } from 'express';
import { ProductController } from '../controllers/ProductController';
import { authMiddleware } from '../middleware/authMiddleware';

const router = Router();
const productController = new ProductController();

// Публичные маршруты
router.get('/', productController.getProducts.bind(productController));
router.get('/:id', productController.getProduct.bind(productController));
router.get('/categories/list', productController.getCategories.bind(productController));

// Защищенные маршруты (требуют аутентификации)
router.post('/', authMiddleware, productController.addProduct.bind(productController));
router.delete('/:id', authMiddleware, productController.deleteProduct.bind(productController));
router.put('/:id/category', authMiddleware, productController.updateCategory.bind(productController));
router.put('/:id', authMiddleware, productController.updateProduct.bind(productController));

export default router; 