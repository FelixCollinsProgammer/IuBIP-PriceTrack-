import { Router } from 'express';
import { PriceController } from '../controllers/PriceController';
import { authMiddleware, adminMiddleware } from '../middleware/authMiddleware';
import { PriceService } from '../services/PriceService';
import { ProductService } from '../services/ProductService';

const router = Router();
const priceService = new PriceService();
const productService = new ProductService();
const priceController = new PriceController(priceService, productService);

// Публичные маршруты
router.get('/:productId', priceController.getPrices.bind(priceController));
router.get('/:productId/cooldown', priceController.getUpdateCooldown.bind(priceController));

// Защищенные маршруты (только для администраторов)
router.post('/:productId', authMiddleware, adminMiddleware, priceController.updatePrice.bind(priceController));

export default router; 