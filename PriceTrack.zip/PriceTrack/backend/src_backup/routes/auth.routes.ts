import { Router } from 'express';
import { AuthController } from '../controllers/AuthController';
import { authMiddleware, adminMiddleware } from '../middleware/authMiddleware';

const router = Router();
const authController = new AuthController();

// Публичные маршруты
router.post('/register', authController.register);
router.post('/login', authController.login);
router.get('/verify-email/:token', authController.verifyEmail);
router.post('/forgot-password', authController.forgotPassword);
router.post('/reset-password/:token', authController.resetPassword);

// Защищенные маршруты (требуют аутентификации)
router.get('/profile', authMiddleware, authController.getProfile);
router.put('/profile', authMiddleware, authController.updateProfile);

export default router; 