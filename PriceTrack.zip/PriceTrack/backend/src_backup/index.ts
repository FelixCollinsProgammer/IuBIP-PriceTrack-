import 'reflect-metadata';
import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import { AppDataSource } from './data-source';
import productRoutes from './routes/product.routes';
import priceRoutes from './routes/price.routes';
import authRoutes from './routes/auth.routes';
import { SchedulerService } from './services/SchedulerService';
import { NotificationService } from './services/NotificationService';
import { errorMiddleware } from './middleware/error.middleware';
import { ProductController } from './controllers/ProductController';
import { PriceController } from './controllers/PriceController';
import { createTestAccount } from 'nodemailer';
import net from 'net';
import { PriceService } from './services/PriceService';
import { ProductService } from './services/ProductService';

// Загрузка переменных окружения
dotenv.config();

// Создание экземпляра Express приложения
const app = express();

// Инициализация контроллеров
const priceService = new PriceService();
const productService = new ProductService();
const priceController = new PriceController(priceService, productService);
const productController = new ProductController();
const notificationService = new NotificationService();

// Функция для проверки доступности порта
function isPortAvailable(port: number): Promise<boolean> {
  return new Promise((resolve) => {
    const server = net.createServer();
    
    server.once('error', (err: NodeJS.ErrnoException) => {
      if (err.code === 'EADDRINUSE') {
        resolve(false);
      } else {
        resolve(false);
      }
    });
    
    server.once('listening', () => {
      server.close();
      resolve(true);
    });
    
    server.listen(port);
  });
}

// Находит первый доступный порт начиная с basePort
async function findAvailablePort(basePort: number, maxTries: number = 100): Promise<number> {
  for (let port = basePort; port < basePort + maxTries; port++) {
    if (await isPortAvailable(port)) {
      return port;
    }
    console.log(`Port ${port} is in use, trying another one...`);
  }
  throw new Error(`No available ports found after ${maxTries} attempts starting from ${basePort}`);
}

// Настройка CORS
const frontendUrl = process.env.FRONTEND_URL || 'http://localhost:3011';
app.use(cors({
  origin: [frontendUrl, 'http://localhost:3000', 'http://localhost:3001', 'http://localhost:3002', 'http://localhost:3011', 'http://localhost:3012', 'http://localhost:3013', 'http://localhost:3014', 'http://localhost:3015', 'http://localhost:4001', 'http://localhost:5173'], // Адрес фронтенда
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization'],
  credentials: true
}));

// Middleware для парсинга JSON
app.use(express.json());

// Определение роутов
app.use('/api/auth', authRoutes);
app.use('/api/products', productRoutes);
app.use('/api/prices', priceRoutes);

// Health check endpoint
app.get('/health', (req, res) => {
  res.status(200).json({ status: 'ok' });
});

// Middleware для обработки ошибок
app.use(errorMiddleware);

// Создаем подключение к базе данных и запускаем сервер
async function bootstrap() {
  try {
    // Инициализация соединения с базой данных
    await AppDataSource.initialize();
    console.log('Database connection established');
    
    // Создание тестового аккаунта для отправки email
    const testAccount = await createTestAccount();
    console.log('Test account details:');
    console.log('User:', testAccount.user);
    console.log('Pass:', testAccount.pass);
    console.log('Preview URL:', testAccount.web);
    
    // Инициализируем планировщик задач
    const schedulerService = new SchedulerService();
    
    // Получаем базовый порт из .env или используем 5000 по умолчанию
    const basePort = parseInt(process.env.PORT || '5000');
    
    try {
      // Находим доступный порт
      const port = await findAvailablePort(basePort);
      
      // Запуск сервера
      app.listen(port, () => {
        console.log(`Server is running on port ${port}`);
        
        // Обновляем значение переменной окружения PORT
        process.env.PORT = port.toString();
        
        // Запускаем обновление цен для товаров при запуске сервера
        SchedulerService.initialize();
        
        // Вывод информации для подключения
        console.log(`API is accessible at http://localhost:${port}/api`);
      });
    } catch (portError) {
      console.error('Failed to find available port:', portError);
      process.exit(1);
    }
  } catch (error) {
    console.error('Error during bootstrap:', error);
    
    // Проверяем, связана ли ошибка с подключением к PostgreSQL
    if (error instanceof Error && error.message.includes('connect ECONNREFUSED')) {
      console.error('Could not connect to the database. Make sure PostgreSQL is running.');
    } else if (error instanceof Error && error.message.includes('password authentication failed')) {
      console.error('Database authentication failed. Check your DB_USER and DB_PASSWORD in .env file.');
    }
    
    process.exit(1);
  }
}

// Запускаем приложение
bootstrap();

// Обработка сигналов остановки для корректного завершения работы
process.on('SIGINT', async () => {
  console.log('Shutting down gracefully...');
  try {
    if (AppDataSource.isInitialized) {
      await AppDataSource.destroy();
      console.log('Database connection closed');
    }
  } catch (error) {
    console.error('Error during shutdown:', error);
  }
  process.exit(0);
});

process.on('SIGTERM', async () => {
  console.log('Termination signal received. Shutting down...');
  try {
    if (AppDataSource.isInitialized) {
      await AppDataSource.destroy();
      console.log('Database connection closed');
    }
  } catch (error) {
    console.error('Error during termination:', error);
  }
  process.exit(0);
}); 