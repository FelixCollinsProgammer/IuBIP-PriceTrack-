import 'reflect-metadata';
import { AppDataSource } from './data-source';
import { Product } from './entities/Product';
import { Price } from './entities/Price';
import { ParserService } from './services/ParserService';

async function updateAllPrices() {
  try {
    // Initialize the database connection
    await AppDataSource.initialize();
    console.log('Database connection established');

    // Get repositories
    const productRepository = AppDataSource.getRepository(Product);
    const priceRepository = AppDataSource.getRepository(Price);

    // Get all products
    const products = await productRepository.find();
    console.log(`Found ${products.length} products to update`);

    // Update each product's price
    for (const product of products) {
      try {
        console.log(`Updating price for product: ${product.name} (${product.id})`);
        
        // Get current price for product using the static method
        const currentPrice = await ParserService.parseUrl(product.url);
        
        // Create a new price entry
        const price = priceRepository.create({
          price: currentPrice.price,
          product
        });
        
        await priceRepository.save(price);
        
        // Update the current price in the product
        product.currentPrice = currentPrice.price;
        await productRepository.save(product);
        
        console.log(`Updated price for ${product.name}: ${currentPrice.price}`);
      } catch (error) {
        console.error(`Failed to update price for product ${product.id}:`, error);
      }
    }

    console.log('Price update completed successfully');
  } catch (error) {
    console.error('Error during price update:', error);
  } finally {
    // Close the database connection
    if (AppDataSource.isInitialized) {
      await AppDataSource.destroy();
      console.log('Database connection closed');
    }
  }
}

// Run the update
updateAllPrices(); 