import nodemailer from 'nodemailer';
import { User } from '../entities/User';
import { Product } from '../entities/Product';
import { AppDataSource } from '../data-source';
import { Price } from '../entities/Price';

/**
 * Сервис для отправки уведомлений пользователям
 */
export class NotificationService {
  private static transporter: nodemailer.Transporter;
  private static initialized = false;
  
  /**
   * Инициализирует транспортер для отправки email
   */
  static async initialize() {
    if (this.initialized) return;
  
    try {
      // Для разработки используем тестовый аккаунт
      // В продакшен-версии здесь нужно использовать реальные SMTP-настройки
      const testAccount = await nodemailer.createTestAccount();
      
      this.transporter = nodemailer.createTransport({
        host: 'smtp.ethereal.email',
        port: 587,
        secure: false,
        auth: {
          user: testAccount.user,
          pass: testAccount.pass
        }
      });
      
      this.initialized = true;
      console.log('NotificationService initialized successfully');
      console.log('Test account details:');
      console.log(`User: ${testAccount.user}`);
      console.log(`Pass: ${testAccount.pass}`);
      console.log(`Preview URL: https://ethereal.email/login`);
    } catch (error) {
      console.error('Failed to initialize NotificationService:', error);
    }
  }
  
  /**
   * Отправляет уведомление о снижении цены
   */
  static async sendPriceDropNotification(
    user: User, 
    product: Product, 
    oldPrice: number, 
    newPrice: number
  ) {
    await this.initialize();
    
    if (!this.initialized) {
      console.error('NotificationService not initialized');
      return;
    }
    
    // Рассчитываем процент снижения
    const priceDrop = oldPrice - newPrice;
    const dropPercentage = (priceDrop / oldPrice) * 100;
    
    // Форматируем цены для отображения
    const formattedOldPrice = new Intl.NumberFormat('ru-RU', { 
      style: 'currency', 
      currency: 'RUB' 
    }).format(oldPrice);
    
    const formattedNewPrice = new Intl.NumberFormat('ru-RU', { 
      style: 'currency', 
      currency: 'RUB' 
    }).format(newPrice);
    
    // Подготавливаем HTML для письма
    const htmlContent = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #2c3e50;">Снижение цены на отслеживаемый товар!</h2>
        <div style="padding: 15px; background-color: #f8f9fa; border-radius: 5px; margin-bottom: 20px;">
          <h3 style="margin-top: 0; color: #3498db;">${product.name}</h3>
          <p>Цена снизилась на <strong style="color: #e74c3c;">${dropPercentage.toFixed(2)}%</strong></p>
          <p>Старая цена: <span style="text-decoration: line-through;">${formattedOldPrice}</span></p>
          <p>Новая цена: <span style="color: #27ae60; font-weight: bold;">${formattedNewPrice}</span></p>
          <a href="${product.url}" style="display: inline-block; padding: 10px 15px; background-color: #3498db; color: white; text-decoration: none; border-radius: 4px; margin-top: 10px;">Перейти к товару</a>
        </div>
        <p style="color: #7f8c8d; font-size: 12px;">Вы получили это письмо, так как подписаны на уведомления о снижении цен в сервисе PriceTrack.</p>
        <p style="color: #7f8c8d; font-size: 12px;">Чтобы отписаться от уведомлений, перейдите в настройки своего профиля.</p>
      </div>
    `;
    
    try {
      const info = await this.transporter.sendMail({
        from: '"PriceTrack" <notifications@pricetrack.ru>',
        to: user.email,
        subject: `Снижение цены на ${product.name}`,
        html: htmlContent
      });
      
      console.log('Notification sent successfully:', info.messageId);
      console.log('Preview URL: %s', nodemailer.getTestMessageUrl(info));
      
      return info;
    } catch (error) {
      console.error('Failed to send notification:', error);
      throw error;
    }
  }
  
  /**
   * Отправляет тестовое уведомление
   */
  static async sendTestNotification(email: string) {
    await this.initialize();
    
    if (!this.initialized) {
      console.error('NotificationService not initialized');
      return;
    }
    
    try {
      const info = await this.transporter.sendMail({
        from: '"PriceTrack" <notifications@pricetrack.ru>',
        to: email,
        subject: 'Тестовое уведомление от PriceTrack',
        html: `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
            <h2 style="color: #2c3e50;">Тестовое уведомление</h2>
            <p>Это тестовое уведомление от сервиса PriceTrack. Если вы получили это письмо, значит система уведомлений работает корректно.</p>
            <p style="color: #7f8c8d; font-size: 12px;">Вы получили это письмо, так как подписаны на уведомления в сервисе PriceTrack.</p>
          </div>
        `
      });
      
      console.log('Test notification sent successfully:', info.messageId);
      console.log('Preview URL: %s', nodemailer.getTestMessageUrl(info));
      
      return info;
    } catch (error) {
      console.error('Failed to send test notification:', error);
      throw error;
    }
  }
  
  /**
   * Проверяет и отправляет уведомления о снижении цен всем подписанным пользователям
   */
  static async checkPriceDropsAndNotify() {
    // Получаем все продукты с их последними ценами
    const productRepository = AppDataSource.getRepository(Product);
    const priceRepository = AppDataSource.getRepository(Price);
    const userRepository = AppDataSource.getRepository(User);
    
    try {
      // Получаем все продукты
      const products = await productRepository.find({
        relations: ['user']
      });
      
      for (const product of products) {
        // Пропускаем продукты без пользователя или если пользователь отписался от уведомлений
        if (!product.user || !product.user.notificationsEnabled) continue;
        
        // Получаем две последние цены для продукта
        const prices = await priceRepository.find({
          where: { product: { id: product.id } },
          order: { createdAt: 'DESC' },
          take: 2
        });
        
        // Если есть хотя бы две цены и новая цена меньше предыдущей
        if (prices.length >= 2 && prices[0].price < prices[1].price) {
          // Проверяем, есть ли пользователь для этого товара
          if (product.userId) {
            // Получаем пользователя из базы
            const user = await userRepository.findOne({ where: { id: product.userId } });
            
            if (user && user.notificationsEnabled && user.email) {
              await this.sendPriceDropNotification(
                user, 
                product, 
                prices[1].price, 
                prices[0].price
              );
              
              console.log(`Sent price drop notification for product ${product.id} to user ${user.id}`);
            }
          }
        }
      }
      
      console.log('Price drop check completed');
    } catch (error) {
      console.error('Error checking price drops:', error);
    }
  }
} 