import puppeteer, { Page, ElementHandle } from 'puppeteer';
import { ProductDetails } from '../types/ProductDetails';
import axios from 'axios';

export class ParserService {
  // Кэш для хранения последних цен продуктов
  private static productPriceCache: Map<string, number> = new Map();
  // Время последнего обновления цены для каждого URL
  private static lastUpdateTime: Map<string, Date> = new Map();
  // Кулдаун для обновления цен (30 минут)
  private readonly PRICE_UPDATE_COOLDOWN = 30 * 60 * 1000; // 30 минут в миллисекундах

  /**
   * Проверяет, можно ли обновить цену для данного URL
   */
  canUpdatePrice(url: string): boolean {
    const lastUpdate = ParserService.lastUpdateTime.get(url);
    if (!lastUpdate) return true;
    
    const now = new Date();
    const elapsed = now.getTime() - lastUpdate.getTime();
    return elapsed > this.PRICE_UPDATE_COOLDOWN;
  }

  getTimeUntilNextUpdate(url: string): number {
    const lastUpdate = ParserService.lastUpdateTime.get(url);
    if (!lastUpdate) return 0;
    
    const now = new Date();
    const elapsed = now.getTime() - lastUpdate.getTime();
    
    if (elapsed > this.PRICE_UPDATE_COOLDOWN) {
      return 0;
    }
    
    return this.PRICE_UPDATE_COOLDOWN - elapsed;
  }

  /**
   * Обновляет время последнего обновления цены
   */
  updateLastPriceTime(url: string): void {
    ParserService.lastUpdateTime.set(url, new Date());
  }

  static async parseUrl(url: string): Promise<ProductDetails> {
    console.log(`[ParserService] Starting to parse URL: ${url}`);
    
    if (!url || typeof url !== 'string') {
      console.error(`[ParserService] Invalid URL provided: ${url}`);
      return {
        name: `Неизвестный товар`,
        price: 0,
        imageUrl: ParserService.getMarketplacePlaceholder('Other')
      };
    }

    // Нормализуем URL
    let validUrl = url.trim();
    
    // Добавляем протокол, если он отсутствует
    if (!validUrl.startsWith('http://') && !validUrl.startsWith('https://')) {
      validUrl = 'https://' + validUrl;
      console.log(`[ParserService] Added https:// protocol: ${validUrl}`);
    }

    try {
      // Валидация URL
      new URL(validUrl);
    } catch (err) {
      console.error(`[ParserService] Invalid URL format: ${validUrl}`, err);
      return {
        name: `Неизвестный товар`,
        price: 0,
        imageUrl: ParserService.getMarketplacePlaceholder('Other')
      };
    }
    
    // Создаем экземпляр сервиса для вызова нестатических методов
    const service = new ParserService();
    
    try {
      // Определяем маркетплейс из URL
      const marketplace = ParserService.getMarketplaceFromUrl(validUrl);

      // Проверка кулдауна - если цена была обновлена недавно, возвращаем кэшированное значение
      if (!service.canUpdatePrice(validUrl) && ParserService.productPriceCache.has(validUrl)) {
        const cachedPrice = ParserService.productPriceCache.get(validUrl)!;
        
        console.log(`[ParserService] Using cached price for ${validUrl}: ${cachedPrice}`);
        return {
          name: `Товар с ${marketplace}`,
          price: cachedPrice,
          imageUrl: ParserService.getMarketplacePlaceholder(marketplace)
        };
      }

      // Проверяем на короткую ссылку Ozon
      if (validUrl.includes('ozon.ru/t/') || validUrl.includes('ozon.ru/share/')) {
        console.log('[ParserService] Detected Ozon short URL, handling specifically');
        try {
          // Сначала попробуем API метод, который умеет обрабатывать короткие URL
          const result = await service.parseOzonApi(validUrl);
          service.updateLastPriceTime(validUrl);
          return result;
        } catch (error) {
          console.log('[ParserService] Failed to parse Ozon short URL with API, returning placeholder', error);
          return {
            name: `Товар с Ozon (короткая ссылка)`,
            price: 0,
            imageUrl: ParserService.getMarketplacePlaceholder('Ozon')
          };
        }
      }
      
      // Для обычных ссылок Ozon
      if (validUrl.includes('ozon.ru')) {
        try {
          console.log('[ParserService] Trying to parse Ozon via API approach');
          const result = await service.parseOzonApi(validUrl);
          service.updateLastPriceTime(validUrl);
          return result;
        } catch (error) {
          console.log('[ParserService] Ozon API parsing failed, returning placeholder', error);
          return {
            name: `Товар с Ozon`,
            price: 0,
            imageUrl: ParserService.getMarketplacePlaceholder('Ozon')
          };
        }
      }
      
      // Для Wildberries используем API
      if (validUrl.includes('wildberries.ru') || validUrl.includes('wb.ru')) {
        try {
          console.log('[ParserService] Trying to parse Wildberries via API approach');
          const result = await service.parseWildberriesApi(validUrl);
          service.updateLastPriceTime(validUrl);
          return result;
        } catch (error) {
          console.log('[ParserService] API parsing failed, returning placeholder', error);
          return {
            name: `Товар с Wildberries`,
            price: 0,
            imageUrl: ParserService.getMarketplacePlaceholder('Wildberries')
          };
        }
      }
      
      // Для AliExpress
      if (validUrl.includes('aliexpress') || validUrl.includes('aliexpress.com')) {
        try {
          console.log('[ParserService] Trying to parse AliExpress via Puppeteer');
          const result = await service.parseWithPuppeteer(validUrl);
          service.updateLastPriceTime(validUrl);
          return result;
        } catch (error) {
          console.error('[ParserService] AliExpress parsing failed', error);
          return {
            name: `Товар с AliExpress`,
            price: 0,
            imageUrl: ParserService.getMarketplacePlaceholder('AliExpress')
          };
        }
      }

      // Для других магазинов используем заглушку
      return {
        name: `Товар с ${marketplace}`,
        price: 0,
        imageUrl: ParserService.getMarketplacePlaceholder(marketplace)
      };
    } catch (error) {
      console.error('[ParserService] Error in parseUrl:', error);
      const marketplace = ParserService.getMarketplaceFromUrl(validUrl);
      return {
        name: `Товар с ${marketplace}`,
        price: 0,
        imageUrl: ParserService.getMarketplacePlaceholder(marketplace)
      };
    }
  }

  /**
   * Парсинг URL через Puppeteer
   */
  private async parseWithPuppeteer(url: string): Promise<ProductDetails> {
    console.log('[ParserService] Parsing with Puppeteer:', url);
    let browser = null;
    let retries = 0;
    const maxRetries = 2;
    
    while (retries <= maxRetries) {
      try {
        if (browser) {
          await browser.close().catch(e => console.error('[ParserService] Error closing browser:', e));
          browser = null;
        }
        
        // Увеличиваем таймауты и добавляем больше аргументов для стабильности
        browser = await puppeteer.launch({
          headless: 'new',
          timeout: 120000, // Увеличиваем таймаут
          executablePath: process.env.PUPPETEER_EXECUTABLE_PATH || undefined, // Добавляем возможность указать путь к Chrome
          ignoreDefaultArgs: ['--disable-extensions'],
          args: [
            '--no-sandbox',
            '--disable-setuid-sandbox',
            '--disable-dev-shm-usage',
            '--disable-accelerated-2d-canvas',
            '--disable-gpu',
            '--window-size=1920x1080',
            '--disable-web-security',
            '--disable-features=IsolateOrigins,site-per-process',
            '--disable-extensions',
            '--disable-infobars',
            '--ignore-certificate-errors',
            '--no-first-run',
            '--disable-notifications'
          ]
        });
        
        // Создаем новую страницу с более длинными таймаутами
        const page = await browser.newPage();
        
        // Устанавливаем более длинный таймаут для всех операций
        page.setDefaultTimeout(60000); // Увеличиваем с 30000 до 60000
        page.setDefaultNavigationTimeout(60000); // Увеличиваем с 30000 до 60000
        
        // Установка HTTP-заголовков для эмуляции реального браузера
        await page.setExtraHTTPHeaders({
          'Accept-Language': 'ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7',
          'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
          'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
          'Referer': 'https://www.google.com/', // Добавляем реферер
          'Cache-Control': 'no-cache',  // Отключаем кэширование
          'Pragma': 'no-cache'
        });
        
        // Обработка диалоговых окон
        page.on('dialog', async dialog => {
          console.log('[ParserService] Dialog appeared:', dialog.type(), dialog.message());
          await dialog.dismiss().catch(e => console.error('[ParserService] Error dismissing dialog:', e));
        });
        
        // Блокируем ненужные ресурсы для ускорения загрузки
        await page.setRequestInterception(true);
        page.on('request', (request) => {
          const resourceType = request.resourceType();
          const url = request.url();
          
          // Блокируем ненужные ресурсы и некоторые трекеры
          if (['image', 'media', 'font'].includes(resourceType) || 
              url.includes('google-analytics') || 
              url.includes('metrika') || 
              url.includes('facebook') || 
              url.includes('tracking')) {
            request.abort('blockedbyclient');
          } else {
            request.continue();
          }
        });
        
        // Подавляем ошибки для заблокированных ресурсов
        page.on('requestfailed', (request) => {
          const failure = request.failure();
          const errorText = failure ? failure.errorText : '';
          const url = request.url();
          
          // Не логируем ошибки для заблокированных ресурсов или известные ошибки
          if (errorText === 'net::ERR_FAILED' && 
             (['image', 'media', 'font'].includes(request.resourceType()) || 
              url.includes('google-analytics') || 
              url.includes('metrika') || 
              url.includes('facebook') || 
              url.includes('tracking'))) {
            // Игнорируем эти ошибки
            return;
          }
          
          // Логируем другие ошибки запросов
          console.error(`[ParserService] Request failed: ${url}, Error: ${errorText}`);
        });
        
        // Перехватываем ошибки страницы
        page.on('error', error => {
          console.error('[ParserService] Page error:', error);
        });
        
        // Перехватываем ошибки консоли 
        page.on('console', msg => {
          if (msg.type() === 'error') {
            console.log('[ParserService] Console error:', msg.text());
          }
        });
        
        // Получаем маркетплейс из URL для использования в логах ошибок
        const marketplace = ParserService.getMarketplaceFromUrl(url);

        try {
          // Навигация с более надежными параметрами
          await page.goto(url, { 
            waitUntil: 'domcontentloaded',
            timeout: 30000 
          });
          
          // Ждем дополнительное время для загрузки динамического контента
          await page.waitForTimeout(3000);
          
          // Парсинг в зависимости от маркетплейса
          let result;
          
          switch (marketplace.toLowerCase()) {
            case 'ozon':
              result = await this.parseOzon(page);
              break;
            case 'wildberries':
              result = await this.parseWildberries(page);
              break;
            case 'aliexpress':
              result = await this.parseAliexpress(page);
              break;
            default:
              result = await this.parseGeneric(page);
          }
          
          // Закрываем браузер после успешного парсинга
          await browser.close().catch(e => console.error('[ParserService] Error closing browser after success:', e));
          browser = null;
          
          return result;
        } catch (innerError) {
          console.error(`[ParserService] Error parsing ${marketplace} page:`, innerError);
          
          // Делаем скриншот при ошибке для отладки
          try {
            await page.screenshot({ path: `error-${Date.now()}.png` });
            console.log('[ParserService] Screenshot saved for debugging');
          } catch (screenshotError) {
            console.error('[ParserService] Failed to save screenshot:', screenshotError);
          }
          
          // Пробуем получить хотя бы заголовок и URL
          try {
            const title = await page.title();
            const currentUrl = page.url();
            console.log(`[ParserService] Page title: "${title}", current URL: ${currentUrl}`);
          } catch (titleError) {
            console.error('[ParserService] Failed to get page title:', titleError);
          }
          
          // Если это последняя попытка, бросаем ошибку дальше
          if (retries === maxRetries) {
            throw innerError;
          }
        } finally {
          // Закрываем страницу
          if (page && !page.isClosed()) {
            await page.close().catch(e => console.error('[ParserService] Error closing page:', e));
          }
        }
        
        // Увеличиваем счетчик попыток
        retries++;
        console.log(`[ParserService] Retrying (${retries}/${maxRetries})...`);
        
        // Ждем перед следующей попыткой
        await new Promise(resolve => setTimeout(resolve, 2000));
        
      } catch (error) {
        console.error('[ParserService] Error parsing URL with browser:', error);
        
        // Если это последняя попытка, возвращаем заглушку
        if (retries === maxRetries) {
          const marketplace = ParserService.getMarketplaceFromUrl(url);
          return {
            name: `Товар с ${marketplace}`,
            price: 0,
            imageUrl: ParserService.getMarketplacePlaceholder(marketplace)
          };
        }
        
        retries++;
        console.log(`[ParserService] Retrying browser launch (${retries}/${maxRetries})...`);
        await new Promise(resolve => setTimeout(resolve, 3000));
      } finally {
        // Убедимся, что браузер закрыт в любом случае
        if (browser) {
          await browser.close().catch(e => console.error('[ParserService] Error in final browser close:', e));
        }
      }
    }
    
    // Если все попытки не удались, возвращаем заглушку
    console.log('[ParserService] All puppeteer attempts failed, returning placeholder');
    const marketplace = ParserService.getMarketplaceFromUrl(url);
    return {
      name: `Товар с ${marketplace} (короткая ссылка)`,
      price: 0,
      imageUrl: ParserService.getMarketplacePlaceholder(marketplace)
    };
  }

  /**
   * Создает URL для изображения маркетплейса
   */
  static getMarketplacePlaceholder(marketplace: string): string {
    // Use actual hosted images instead of local files
    switch (marketplace.toLowerCase()) {
      case 'ozon':
        return 'https://upload.wikimedia.org/wikipedia/commons/thumb/8/82/Logo_of_Ozon.ru_%28old%29.svg/320px-Logo_of_Ozon.ru_%28old%29.svg.png';
      case 'wildberries':
        return 'https://upload.wikimedia.org/wikipedia/commons/thumb/8/88/Wildberries_logo.svg/320px-Wildberries_logo.svg.png';
      case 'aliexpress':
        return 'https://upload.wikimedia.org/wikipedia/commons/thumb/e/e1/AliExpress_logo.svg/320px-AliExpress_logo.svg.png';
      case 'amazon':
        return 'https://upload.wikimedia.org/wikipedia/commons/thumb/a/a9/Amazon_logo.svg/320px-Amazon_logo.svg.png';
      case 'yandex market':
        return 'https://upload.wikimedia.org/wikipedia/commons/thumb/5/55/Yandex_Market_logo.svg/320px-Yandex_Market_logo.svg.png';
      default:
        // For unknown marketplaces use a generic placeholder
        return 'https://cdn-icons-png.flaticon.com/512/3176/3176363.png';
    }
  }

  /**
   * Определяет маркетплейс из URL
   */
  static getMarketplaceFromUrl(url: string): string {
    try {
      // Преобразуем URL в нижний регистр для унификации
      const lowercaseUrl = url.toLowerCase();
      
      // Проверка на основные маркетплейсы по вхождению в URL
      if (lowercaseUrl.includes('ozon.ru')) {
        return 'Ozon';
      }
      
      if (lowercaseUrl.includes('wildberries.ru') || lowercaseUrl.includes('wb.ru')) {
        return 'Wildberries';
      }
      
      if (lowercaseUrl.includes('aliexpress.ru') || lowercaseUrl.includes('aliexpress.com')) {
        return 'AliExpress';
      }
      
      if (lowercaseUrl.includes('amazon.') || lowercaseUrl.includes('amzn.')) {
        return 'Amazon';
      }
      
      if (lowercaseUrl.includes('yandex.market') || lowercaseUrl.includes('market.yandex')) {
        return 'Yandex Market';
      }
      
      // Если не нашли соответствие, пробуем получить домен
      try {
        const domain = new URL(url).hostname.replace('www.', '');
        // Возвращаем домен с большой буквы для первого слова
        return domain.split('.')[0].charAt(0).toUpperCase() + domain.split('.')[0].slice(1);
      } catch (e) {
        console.error('Error parsing URL domain:', e);
        return 'Other';
      }
    } catch (e) {
      console.error('Error determining marketplace from URL:', e);
      return 'Other';
    }
  }

  /**
   * Парсинг Wildberries через API
   */
  private async parseWildberriesApi(url: string): Promise<ProductDetails> {
    console.log('[ParserService] Parsing Wildberries via API');
    
    try {
      // Извлекаем ID товара из URL
      const matches = url.match(/wildberries\.ru\/catalog\/(\d+)\/detail/);
      let productId = matches ? matches[1] : null;
      
      if (!productId) {
        // Альтернативный способ извлечения ID товара
        const altMatches = url.match(/wildberries\.ru\/[a-z]+\/product\?card=(\d+)/);
        productId = altMatches ? altMatches[1] : null;
        
        // Попробуем третий формат URL
        if (!productId) {
          const thirdMatches = url.match(/wb\.ru\/([^/]+)\/detail\/([^/]+)/);
          if (thirdMatches) {
            // Попытка извлечь ID из URL формата wb.ru
            // Для этого формата часто ID находится в пути
            try {
              const fullUrl = url;
              console.log(`[ParserService] Using full URL for Wildberries: ${fullUrl}`);
              
              // Выполняем HTTP запрос для получения ID товара из содержимого страницы
              const response = await axios.get(fullUrl, {
                headers: {
                  'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                  'Accept-Language': 'ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7',
                  'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
                  'Referer': 'https://www.wildberries.ru/',
                  'sec-ch-ua': '"Not_A Brand";v="8", "Chromium";v="120", "Google Chrome";v="120"',
                  'sec-ch-ua-mobile': '?0',
                  'sec-ch-ua-platform': '"macOS"',
                  'Cache-Control': 'no-cache',
                  'Pragma': 'no-cache'
                },
                timeout: 10000
              });
              
              // Поиск ID товара в HTML
              const idMatch = response.data.match(/productCard\s*:\s*{\s*id\s*:\s*(\d+)/);
              if (idMatch && idMatch[1]) {
                productId = idMatch[1];
                console.log(`[ParserService] Extracted product ID from response: ${productId}`);
                // Убедимся, что productId не null перед вызовом
                if (productId) {
                  return this.fetchWildberriesProductById(productId);
                }
              }
              
              // Попробуем еще один формат поиска ID
              const jsMatch = response.data.match(/data-nm-id="(\d+)"/);
              if (jsMatch && jsMatch[1]) {
                productId = jsMatch[1];
                console.log(`[ParserService] Extracted product ID from nm-id attribute: ${productId}`);
                if (productId) {
                  return this.fetchWildberriesProductById(productId);
                }
              }
            } catch (error) {
              console.error('[ParserService] Error parsing Wildberries short URL:', error);
            }
          }
        }
        
        // Последняя попытка для любого URL Wildberries - попробуем puppeteer
        if (url.includes('wildberries.ru') || url.includes('wb.ru')) {
          console.log(`[ParserService] Using Puppeteer for generic Wildberries URL: ${url}`);
          try {
            return await this.parseWithPuppeteer(url);
          } catch (puppeteerError) {
            console.error('[ParserService] Puppeteer parsing failed:', puppeteerError);
            throw new Error('Failed to parse Wildberries URL with Puppeteer');
          }
        }
        
        throw new Error('Could not extract product ID from Wildberries URL');
      }
      
      // Используем извлеченный ID для запроса к API
      if (typeof productId === 'string') {
        return this.fetchWildberriesProductById(productId);
      } else {
        throw new Error('Invalid product ID: productId is null');
      }
    } catch (error) {
      console.error('[ParserService] Error parsing Wildberries API:', error);
      throw error;
    }
  }
  
  private async fetchWildberriesProductById(productId: string): Promise<ProductDetails> {
    try {
      // Используем Wildberries API для получения данных о товаре
      console.log(`[ParserService] Fetch product ${productId} from Wildberries API`);
      
      // Используем новый API эндпоинт, более устойчивый к блокировкам
      const apiUrls = [
        `https://card.wb.ru/cards/detail?nm=${productId}`,
        `https://wbxcatalog-ru.wildberries.ru/nm-2-card/catalog/${productId}/detail.json`,
        `https://wbx-content-v2.wbstatic.net/ru/${productId}.json`
      ];
      
      let response = null;
      let successUrl = '';
      
      // Пробуем разные эндпоинты для получения данных
      for (const apiUrl of apiUrls) {
        try {
          response = await axios.get(apiUrl, {
            headers: {
              'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
              'Accept-Language': 'ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7',
              'Accept': 'application/json',
              'Referer': `https://www.wildberries.ru/catalog/${productId}/detail.aspx`,
              'Origin': 'https://www.wildberries.ru',
              'sec-ch-ua': '"Not_A Brand";v="8", "Chromium";v="120", "Google Chrome";v="120"',
              'sec-ch-ua-mobile': '?0',
              'sec-ch-ua-platform': '"macOS"'
            },
            timeout: 5000
          });
          
          if (response.data && 
              ((response.data.data && response.data.data.products) || 
               (response.data.data && response.data.data.nm) || 
               response.data.name)) {
            successUrl = apiUrl;
            break;
          }
        } catch (e) {
          console.log(`[ParserService] Failed to fetch from ${apiUrl}, trying next`);
        }
      }
      
      if (!response || !successUrl) {
        console.log('[ParserService] All API endpoints failed, trying Puppeteer');
        return this.parseWildberries(await this.createPuppeteerPage(`https://www.wildberries.ru/catalog/${productId}/detail.aspx`));
      }
      
      console.log(`[ParserService] Successfully fetched data from ${successUrl}`);
      
      // Проверяем ответ API в зависимости от формата
      if (successUrl.includes('card.wb.ru')) {
        if (response.data && response.data.data && response.data.data.products && response.data.data.products.length > 0) {
          const product = response.data.data.products[0];
          
          // Извлекаем цену из ответа
          const price = product.salePriceU ? (product.salePriceU / 100) : (product.priceU / 100);
          const name = product.name || `Товар ${productId} с Wildberries`;
          const imageUrl = product.pics && product.pics.length > 0 
            ? `https://images.wbstatic.net/big/new/${Math.floor(Number(productId) / 10000)}0000/${productId}-1.jpg`
            : ParserService.getMarketplacePlaceholder('Wildberries');
          
          console.log(`[ParserService] Successfully parsed Wildberries product: ID=${productId}, Name=${name}, Price=${price}`);
          
          return {
            name,
            price,
            imageUrl
          };
        }
      } else if (successUrl.includes('wbxcatalog-ru')) {
        if (response.data && response.data.data && response.data.data.nm) {
          const product = response.data.data.nm;
          
          const price = product.sale > 0 ? product.price * (1 - product.sale/100) : product.price;
          const name = product.name || `Товар ${productId} с Wildberries`;
          const imageUrl = `https://images.wbstatic.net/big/new/${Math.floor(Number(productId) / 10000)}0000/${productId}-1.jpg`;
          
          return { name, price, imageUrl };
        }
      } else if (successUrl.includes('wbx-content-v2')) {
        if (response.data && response.data.name) {
          // Этот эндпоинт не содержит цену, будем парсить через Puppeteer
          const name = response.data.name;
          return this.parseWildberries(await this.createPuppeteerPage(`https://www.wildberries.ru/catalog/${productId}/detail.aspx`));
        }
      }
      
      console.error('[ParserService] Invalid response from Wildberries API, using fallback');
      // Если не удалось получить данные через API, возвращаем заглушку с нулевой ценой
      return {
        name: `Товар ${productId} с Wildberries`,
        price: 0,
        imageUrl: ParserService.getMarketplacePlaceholder('Wildberries')
      };
    } catch (error) {
      console.error('[ParserService] Error fetching Wildberries product data:', error);
      throw error;
    }
  }

  /**
   * Создает и настраивает страницу в Puppeteer с необходимыми параметрами
   */
  private async createPuppeteerPage(url: string): Promise<Page> {
    let browser = null;
    
    try {
      browser = await puppeteer.launch({
        headless: 'new',
        timeout: 120000, // Увеличиваем таймаут
        executablePath: process.env.PUPPETEER_EXECUTABLE_PATH || undefined, // Добавляем возможность указать путь к Chrome
        ignoreDefaultArgs: ['--disable-extensions'],
        args: [
          '--no-sandbox',
          '--disable-setuid-sandbox',
          '--disable-dev-shm-usage',
          '--disable-accelerated-2d-canvas',
          '--disable-gpu',
          '--window-size=1920x1080',
          '--disable-web-security',
          '--disable-features=IsolateOrigins,site-per-process',
          '--disable-extensions',
          '--disable-infobars',
          '--ignore-certificate-errors',
          '--no-first-run',
          '--disable-notifications'
        ]
      });
      
      const page = await browser.newPage();
      
      // Установка более длительных таймаутов
      page.setDefaultTimeout(60000); // Увеличиваем с 30000 до 60000
      page.setDefaultNavigationTimeout(60000); // Увеличиваем с 30000 до 60000
      
      // Установка HTTP-заголовков для эмуляции реального браузера
      await page.setExtraHTTPHeaders({
        'Accept-Language': 'ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7',
        'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
        'Referer': 'https://www.google.com/',
        'Sec-Fetch-Site': 'same-origin',
        'Sec-Fetch-Mode': 'navigate',
        'Sec-Fetch-User': '?1',
        'Sec-Fetch-Dest': 'document',
        'Sec-Ch-Ua': '"Not_A Brand";v="8", "Chromium";v="120", "Google Chrome";v="120"',
        'Sec-Ch-Ua-Mobile': '?0',
        'Sec-Ch-Ua-Platform': '"macOS"',
        'Cache-Control': 'no-cache',
        'Pragma': 'no-cache'
      });
      
      // Эмулируем мобильное устройство для некоторых сайтов, если это поможет
      if (url.includes('aliexpress') || url.includes('wildberries') || Math.random() > 0.5) {
        await page.setUserAgent('Mozilla/5.0 (iPhone; CPU iPhone OS 14_7_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.1.2 Mobile/15E148 Safari/604.1');
        
        // Устанавливаем viewport как у телефона
        await page.setViewport({
          width: 390,
          height: 844,
          deviceScaleFactor: 2,
          isMobile: true,
          hasTouch: true
        });
      } else {
        // Устанавливаем desktop viewport
        await page.setViewport({
          width: 1280,
          height: 800,
          deviceScaleFactor: 1,
          isMobile: false,
          hasTouch: false
        });
      }
      
      // Блокируем ненужные ресурсы для ускорения загрузки
      await page.setRequestInterception(true);
      page.on('request', (request) => {
        const resourceType = request.resourceType();
        const url = request.url();
        
        // Блокируем ненужные ресурсы и некоторые трекеры
        if (['image', 'media', 'font'].includes(resourceType) || 
            url.includes('google-analytics') || 
            url.includes('metrika') || 
            url.includes('facebook') || 
            url.includes('tracking')) {
          request.abort('blockedbyclient');
        } else {
          request.continue();
        }
      });
      
      // Подавляем ошибки для заблокированных ресурсов
      page.on('requestfailed', (request) => {
        const failure = request.failure();
        const errorText = failure ? failure.errorText : '';
        const url = request.url();
        
        // Не логируем ошибки для заблокированных ресурсов или известные ошибки
        if (errorText === 'net::ERR_FAILED' && 
           (['image', 'media', 'font'].includes(request.resourceType()) || 
            url.includes('google-analytics') || 
            url.includes('metrika') || 
            url.includes('facebook') || 
            url.includes('tracking'))) {
          // Игнорируем эти ошибки
          return;
        }
        
        // Логируем другие ошибки запросов
        console.error(`[ParserService] Request failed: ${url}, Error: ${errorText}`);
      });
      
      // Настраиваем обработчики ошибок
      page.on('error', error => {
        console.error('[ParserService] Page error:', error);
      });
      
      // Подавляем вывод ошибок в консоль для заблокированных ресурсов
      page.on('console', msg => {
        if (msg.type() === 'error') {
          const text = msg.text();
          // Фильтруем ошибки загрузки ресурсов "Failed to load resource: net::ERR_FAILED"
          if (text.includes('net::ERR_FAILED') && 
             (text.includes('.jpg') || text.includes('.png') || text.includes('.gif') || 
              text.includes('.woff') || text.includes('.ttf') || text.includes('.mp4') || 
              text.includes('.css') || text.includes('google-analytics') || 
              text.includes('metrika') || text.includes('facebook'))) {
            // Игнорируем эти ошибки
            return;
          }
          console.log('[ParserService] Console error:', text);
        }
      });
      
      // Обработка диалоговых окон
      page.on('dialog', async dialog => {
        console.log('[ParserService] Dialog appeared:', dialog.type(), dialog.message());
        await dialog.dismiss().catch(e => console.error('[ParserService] Error dismissing dialog:', e));
      });
      
      try {
        await page.goto(url, { 
          waitUntil: 'domcontentloaded',
          timeout: 30000 
        });
        
        // Дополнительная задержка для загрузки динамического контента
        await page.waitForTimeout(3000);
        
        return page;
      } catch (navigationError) {
        console.error('[ParserService] Navigation error:', navigationError);
        
        // Если навигация не удалась, попробуем еще раз с другими параметрами
        try {
          console.log('[ParserService] Retrying navigation with different parameters');
          await page.goto(url, { 
            waitUntil: 'networkidle2',
            timeout: 45000 
          });
          await page.waitForTimeout(2000);
          return page;
        } catch (retryError) {
          console.error('[ParserService] Retry navigation failed:', retryError);
          // Закрываем браузер при неудаче
          if (browser) await browser.close().catch(e => {});
          throw new Error(`Navigation to ${url} failed after retry`);
        }
      }
    } catch (error) {
      console.error('[ParserService] Error creating Puppeteer page:', error);
      // Убедимся, что браузер закрыт при ошибке
      if (browser) await browser.close().catch(e => {});
      throw error;
    }
  }
}