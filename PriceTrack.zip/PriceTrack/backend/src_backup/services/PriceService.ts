import { AppDataSource } from '../data-source';
import { Price } from '../entities/Price';
import { Product } from '../entities/Product';

interface CreatePriceParams {
  productId: number;
  price: number;
  date: Date;
}

export class PriceService {
  private priceRepository = AppDataSource.getRepository(Price);
  private productRepository = AppDataSource.getRepository(Product);
  
  // Период между обновлениями цены в миллисекундах (30 минут)
  private readonly COOLDOWN_PERIOD = 30 * 60 * 1000;

  /**
   * Создает новую запись о цене товара
   */
  async createPrice(params: CreatePriceParams): Promise<Price> {
    const { productId, price, date } = params;
    
    // Получаем товар
    const product = await this.productRepository.findOne({ 
      where: { id: productId },
      relations: ['prices']
    });
    
    if (!product) {
      throw new Error(`Товар с ID ${productId} не найден`);
    }
    
    // Создаем новую запись цены
    const newPrice = this.priceRepository.create({
      price: price,
      createdAt: date,
      product
    });
    
    // Сохраняем цену
    return await this.priceRepository.save(newPrice);
  }
  
  /**
   * Получает все цены для товара
   */
  async getPricesForProduct(productId: number | string): Promise<Price[]> {
    const product = await this.productRepository.findOne({ 
      where: { id: Number(productId) },
      relations: ['prices']
    });
    
    if (!product) {
      throw new Error(`Товар с ID ${productId} не найден`);
    }
    
    return product.prices.sort((a, b) => a.createdAt.getTime() - b.createdAt.getTime());
  }
  
  /**
   * Проверяет, не слишком ли часто обновляется цена товара
   * Возвращает оставшееся время ожидания в секундах или null, если можно обновлять
   */
  async getUpdateCooldown(productId: number | string): Promise<number | null> {
    try {
      const product = await this.productRepository.findOne({ 
        where: { id: Number(productId) },
        relations: ['prices']
      });
      
      if (!product || !product.prices.length) {
        return null; // Можно обновлять, если товар не найден или нет цен
      }
      
      // Сортируем цены по времени, чтобы получить самую последнюю
      const latestPrice = product.prices.sort((a, b) => 
        b.createdAt.getTime() - a.createdAt.getTime()
      )[0];
      
      // Вычисляем, сколько времени прошло с последнего обновления
      const timeSinceLastUpdate = Date.now() - latestPrice.createdAt.getTime();
      
      // Если прошло меньше времени, чем период остывания
      if (timeSinceLastUpdate < this.COOLDOWN_PERIOD) {
        // Возвращаем оставшееся время в секундах
        return Math.ceil((this.COOLDOWN_PERIOD - timeSinceLastUpdate) / 1000);
      }
      
      // Возвращаем null, если можно обновлять
      return null;
    } catch (error) {
      console.error(`Error in getUpdateCooldown:`, error);
      return null; // В случае ошибки разрешаем обновление
    }
  }
} 