import * as cron from 'node-cron';
import { AppDataSource } from '../data-source';
import { Product } from '../entities/Product';
import { Price } from '../entities/Price';
import { ParserService } from './ParserService';
import { NotificationService } from './NotificationService';

/**
 * Сервис для планирования регулярных задач
 */
export class SchedulerService {
  private static isInitialized = false;
  private static priceUpdateTask: cron.ScheduledTask;
  private static notificationTask: cron.ScheduledTask;
  
  /**
   * Инициализирует планировщик задач
   */
  static initialize() {
    if (this.isInitialized) return;
    
    try {
      // Обновление цен каждый час (раньше было '0 * * * *')
      this.priceUpdateTask = cron.schedule('0 * * * *', () => {
        console.log('[SchedulerService] Running scheduled price update task at ' + new Date().toISOString());
        this.updateAllPrices();
      });
      
      // Отправка уведомлений о снижении цен каждые 2 часа
      this.notificationTask = cron.schedule('0 */2 * * *', () => {
        console.log('[SchedulerService] Running scheduled price drop notification task at ' + new Date().toISOString());
        NotificationService.checkPriceDropsAndNotify();
      });
      
      // Запускаем первоначальное обновление цен через 30 секунд после старта
      setTimeout(() => {
        console.log('[SchedulerService] Running initial price update after server start');
        this.updateAllPrices();
      }, 30000);
      
      this.isInitialized = true;
      console.log('SchedulerService initialized successfully');
    } catch (error) {
      console.error('Failed to initialize SchedulerService:', error);
    }
  }
  
  /**
   * Останавливает все задачи
   */
  static stop() {
    if (this.priceUpdateTask) {
      this.priceUpdateTask.stop();
    }
    
    if (this.notificationTask) {
      this.notificationTask.stop();
    }
    
    this.isInitialized = false;
    console.log('SchedulerService stopped');
  }
  
  /**
   * Обновляет цены всех продуктов
   */
  static async updateAllPrices() {
    try {
      const productRepository = AppDataSource.getRepository(Product);
      const priceRepository = AppDataSource.getRepository(Price);
      
      // Получаем все продукты
      const products = await productRepository.find();
      console.log(`Found ${products.length} products to update prices`);
      
      // Обновляем цены для каждого продукта
      for (const product of products) {
        try {
          console.log(`Updating price for product ${product.id}: ${product.name}`);
          
          // Получаем свежие данные о продукте
          const productDetails = await ParserService.parseUrl(product.url);
          
          if (productDetails && productDetails.price > 0) {
            // Создаем новую запись цены
            const price = new Price();
            price.price = productDetails.price;
            price.product = product;
            await priceRepository.save(price);
            
            // Обновляем текущую цену в продукте
            product.currentPrice = productDetails.price;
            await productRepository.save(product);
            
            console.log(`Updated price for product ${product.id} to ${productDetails.price}`);
          } else {
            console.warn(`Failed to update price for product ${product.id}: invalid data`);
          }
        } catch (error) {
          console.error(`Error updating price for product ${product.id}:`, error);
        }
        
        // Добавляем задержку между запросами, чтобы не перегружать систему
        await new Promise(resolve => setTimeout(resolve, 5000));
      }
      
      console.log('Price update task completed');
    } catch (error) {
      console.error('Error in updateAllPrices:', error);
    }
  }
  
  /**
   * Обновляет цену для конкретного продукта
   */
  static async updateProductPrice(productId: number) {
    try {
      const productRepository = AppDataSource.getRepository(Product);
      const priceRepository = AppDataSource.getRepository(Price);
      
      // Получаем продукт по ID
      const product = await productRepository.findOne({ where: { id: productId } });
      
      if (!product) {
        console.error(`Product with ID ${productId} not found`);
        return;
      }
      
      console.log(`Manually updating price for product ${product.id}: ${product.name}`);
      
      // Получаем свежие данные о продукте
      const productDetails = await ParserService.parseUrl(product.url);
      
      if (productDetails && productDetails.price > 0) {
        // Создаем новую запись цены
        const price = new Price();
        price.price = productDetails.price;
        price.product = product;
        await priceRepository.save(price);
        
        // Обновляем текущую цену в продукте
        product.currentPrice = productDetails.price;
        await productRepository.save(product);
        
        console.log(`Updated price for product ${product.id} to ${productDetails.price}`);
        return price;
      } else {
        console.warn(`Failed to update price for product ${product.id}: invalid data`);
        throw new Error('Failed to get valid product details');
      }
    } catch (error) {
      console.error(`Error updating price for product ${productId}:`, error);
      throw error;
    }
  }
} 