import { AppDataSource } from '../data-source';
import { Product } from '../entities/Product';
import { User } from '../entities/User';
import { FindOptionsWhere, Like, Not, IsNull } from 'typeorm';

interface CreateProductParams {
  name: string;
  url: string;
  imageUrl?: string;
  category?: string;
  marketplace?: string;
  userId: number;
}

interface UpdateProductParams {
  name?: string;
  url?: string;
  imageUrl?: string;
  category?: string;
  marketplace?: string;
}

interface ProductFilter {
  category?: string;
  marketplace?: string;
  search?: string;
  userId?: number;
}

export class ProductService {
  private productRepository = AppDataSource.getRepository(Product);
  private userRepository = AppDataSource.getRepository(User);

  /**
   * Получить товар по ID
   */
  async getProductById(productId: number | string, withPrices: boolean = false): Promise<Product> {
    const relations = withPrices ? ['prices', 'user'] : ['user'];
    
    const product = await this.productRepository.findOne({
      where: { id: Number(productId) },
      relations
    });
    
    if (!product) {
      throw new Error(`Товар с ID ${productId} не найден`);
    }
    
    return product;
  }
  
  /**
   * Получить все товары с фильтрацией
   */
  async getProducts(filter: ProductFilter = {}): Promise<Product[]> {
    const { category, marketplace, search, userId } = filter;
    
    // Строим условия для запроса
    const where: FindOptionsWhere<Product> = {};
    
    if (category) {
      where.category = category;
    }
    
    if (marketplace) {
      where.marketplace = marketplace;
    }
    
    if (userId) {
      where.user = { id: userId };
    }
    
    if (search) {
      where.name = Like(`%${search}%`);
    }
    
    // Выполняем запрос
    return await this.productRepository.find({
      where,
      relations: ['prices', 'user'],
      order: { createdAt: 'DESC' }
    });
  }
  
  /**
   * Создать новый товар
   */
  async createProduct(params: CreateProductParams): Promise<Product> {
    const { name, url, imageUrl, category, marketplace, userId } = params;
    
    // Проверяем существование пользователя
    const user = await this.userRepository.findOneBy({ id: userId });
    
    if (!user) {
      throw new Error(`Пользователь с ID ${userId} не найден`);
    }
    
    // Проверяем, не существует ли уже товар с таким URL
    const existingProduct = await this.productRepository.findOneBy({ url });
    
    if (existingProduct) {
      throw new Error(`Товар с URL ${url} уже существует`);
    }
    
    // Создаем новый товар
    const product = this.productRepository.create({
      name,
      url,
      imageUrl,
      category,
      marketplace,
      user
    });
    
    // Сохраняем товар
    return await this.productRepository.save(product);
  }
  
  /**
   * Обновить товар
   */
  async updateProduct(productId: number | string, params: UpdateProductParams): Promise<Product> {
    // Находим товар
    const product = await this.getProductById(productId);
    
    // Обновляем поля
    Object.assign(product, params);
    
    // Сохраняем изменения
    return await this.productRepository.save(product);
  }
  
  /**
   * Удалить товар
   */
  async deleteProduct(productId: number | string): Promise<boolean> {
    const product = await this.getProductById(productId);
    
    // Удаляем товар
    await this.productRepository.remove(product);
    
    return true;
  }
  
  /**
   * Получить все уникальные категории товаров
   */
  async getCategories(): Promise<string[]> {
    const products = await this.productRepository.find({
      select: { category: true },
      where: { category: Not(IsNull()) }
    });
    
    // Извлекаем уникальные категории
    const categories = [...new Set(products.map(p => p.category))];
    
    return categories.filter(Boolean) as string[];
  }
} 