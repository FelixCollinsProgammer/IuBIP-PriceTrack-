import { exec } from 'child_process';
import path from 'path';
import fs from 'fs';
import { promisify } from 'util';

const execAsync = promisify(exec);

// Интерфейс для данных о товаре, возвращаемых Python-скриптом
export interface ProductDetails {
  name: string;
  price: number;
  originalPrice: number;
  discount: number;
  imageUrl: string;
  marketplace: string;
  url: string;
  success: boolean;
  error?: string;
}

export class PythonParserService {
  private static pythonScriptPath = path.join(process.cwd(), 'scripts', 'price_parser.py');
  
  /**
   * Проверяет, установлен ли Python и необходимые пакеты
   */
  public static async checkDependencies(): Promise<boolean> {
    try {
      // Проверяем Python
      await execAsync('python3 --version');
      
      // Проверяем Playwright
      try {
        await execAsync('python3 -c "from playwright.async_api import async_playwright"');
      } catch (error) {
        console.log('Playwright not found, attempting to install...');
        await execAsync('pip install playwright');
        await execAsync('playwright install chromium');
      }
      
      // Проверяем существование скрипта
      if (!fs.existsSync(this.pythonScriptPath)) {
        throw new Error(`Python script not found at: ${this.pythonScriptPath}`);
      }
      
      return true;
    } catch (error) {
      console.error('Error checking Python dependencies:', error);
      return false;
    }
  }
  
  /**
   * Парсит URL товара с использованием Python-скрипта
   */
  public static async parseUrl(url: string): Promise<ProductDetails> {
    try {
      // Проверяем зависимости при первом вызове
      const checkResult = await this.checkDependencies();
      if (!checkResult) {
        throw new Error('Python dependencies check failed');
      }
      
      // Формируем команду для запуска скрипта
      const command = `python3 "${this.pythonScriptPath}" --url "${url}"`;
      
      console.log(`Running Python parser command: ${command}`);
      
      // Запускаем скрипт
      const { stdout, stderr } = await execAsync(command, { timeout: 60000 });
      
      if (stderr) {
        console.warn(`Python script warnings/errors: ${stderr}`);
      }
      
      // Парсим результат
      const result: ProductDetails = JSON.parse(stdout);
      
      // Проверяем успешность выполнения
      if (!result.success) {
        throw new Error(result.error || 'Python script failed without specific error');
      }
      
      return result;
    } catch (error: any) {
      console.error(`Error parsing URL ${url} with Python:`, error);
      
      // Возвращаем запасной вариант с информацией об ошибке
      return {
        name: `Товар (не удалось загрузить)`,
        price: 0,
        originalPrice: 0,
        discount: 0,
        imageUrl: "https://via.placeholder.com/400x400?text=Error+Loading+Image",
        marketplace: this.detectMarketplace(url),
        url: url,
        success: false,
        error: error.message || 'Unknown error'
      };
    }
  }
  
  /**
   * Обновляет цену товара с помощью Python-скрипта
   */
  public static async updateProductPrice(url: string): Promise<ProductDetails> {
    return await this.parseUrl(url);
  }
  
  /**
   * Определяет маркетплейс по URL
   */
  private static detectMarketplace(url: string): string {
    try {
      const domain = new URL(url).hostname.toLowerCase();
      
      if (domain.includes('ozon')) {
        return 'ozon';
      } else if (domain.includes('wildberries') || domain.includes('wb.ru')) {
        return 'wildberries';
      } else if (domain.includes('aliexpress')) {
        return 'aliexpress';
      } else if (domain.includes('avito')) {
        return 'avito';
      } else {
        return 'unknown';
      }
    } catch (error) {
      console.error('Error detecting marketplace:', error);
      return 'unknown';
    }
  }
} 