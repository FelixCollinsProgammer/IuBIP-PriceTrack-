export interface ProductDetails {
  name: string;
  price: number;
  imageUrl: string;
} 