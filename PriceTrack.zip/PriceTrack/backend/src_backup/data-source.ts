import 'reflect-metadata';
import { DataSource } from 'typeorm';
import { Product } from './entities/Product';
import { Price } from './entities/Price';
import { User } from './entities/User';
import { Ticket } from './entities/Ticket';
import { InitialMigration1744425712773 } from './migrations/1744425712773-InitialMigration';
import { AddUserIdToProduct1744464215817 } from './migrations/1744464215817-AddUserIdToProduct';
import { AddNotificationsEnabled1744550000000 } from './migrations/1744550000000-AddNotificationsEnabled';
import dotenv from 'dotenv';

// Load environment variables
dotenv.config();

export const AppDataSource = new DataSource({
  type: 'postgres',
  host: process.env.DB_HOST || 'localhost',
  port: parseInt(process.env.DB_PORT || '5432', 10),
  username: process.env.DB_USER || 'postgres',
  password: process.env.DB_PASSWORD || 'postgres',
  database: process.env.DB_NAME || 'pricetrack',
  synchronize: false,
  logging: true,
  entities: [Product, Price, User, Ticket],
  migrations: [
    InitialMigration1744425712773, 
    AddUserIdToProduct1744464215817,
    AddNotificationsEnabled1744550000000
  ],
  subscribers: [],
}); 