import { MigrationInterface, QueryRunner } from "typeorm";

export class AddCurrentPriceColumn1744459908669 implements MigrationInterface {

    public async up(queryRunner: QueryRunner): Promise<void> {
        // Проверяем, существует ли уже колонка
        const hasColumn = await queryRunner.hasColumn('product', 'currentPrice');
        if (!hasColumn) {
            await queryRunner.query(`
                ALTER TABLE "product" 
                ADD COLUMN "currentPrice" DECIMAL(10,2) DEFAULT 0
            `);

            // Обновляем значения currentPrice на основе последних цен
            await queryRunner.query(`
                UPDATE "product" p
                SET "currentPrice" = (
                    SELECT price FROM "price"
                    WHERE "productId" = p.id
                    ORDER BY "createdAt" DESC
                    LIMIT 1
                )
                WHERE EXISTS (
                    SELECT 1 FROM "price"
                    WHERE "productId" = p.id
                )
            `);
        }
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        const hasColumn = await queryRunner.hasColumn('product', 'currentPrice');
        if (hasColumn) {
            await queryRunner.query(`
                ALTER TABLE "product" 
                DROP COLUMN "currentPrice"
            `);
        }
    }

}
