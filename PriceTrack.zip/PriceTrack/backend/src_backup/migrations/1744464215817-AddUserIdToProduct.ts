import { MigrationInterface, QueryRunner } from "typeorm";

export class AddUserIdToProduct1744464215817 implements MigrationInterface {

    public async up(queryRunner: QueryRunner): Promise<void> {
        // Пропускаем добавление колонки, так как она уже существует
        // await queryRunner.query(`ALTER TABLE "product" ADD "userId" integer NULL`);
        
        // Добавляем внешний ключ
        await queryRunner.query(`ALTER TABLE "product" ADD CONSTRAINT "FK_product_user" FOREIGN KEY ("userId") REFERENCES "user"("id") ON DELETE SET NULL ON UPDATE NO ACTION`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        // Удаляем внешний ключ
        await queryRunner.query(`ALTER TABLE "product" DROP CONSTRAINT "FK_product_user"`);
        
        // Пропускаем удаление колонки, так как она была создана через synchronize
        // await queryRunner.query(`ALTER TABLE "product" DROP COLUMN "userId"`);
    }

}
