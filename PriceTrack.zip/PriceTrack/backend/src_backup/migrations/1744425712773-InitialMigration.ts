import { MigrationInterface, QueryRunner } from "typeorm";

export class InitialMigration1744425712773 implements MigrationInterface {
    name = 'InitialMigration1744425712773'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            CREATE TABLE "product" (
                "id" SERIAL NOT NULL,
                "name" character varying NOT NULL,
                "url" character varying NOT NULL,
                "imageUrl" character varying NOT NULL,
                "createdAt" TIMESTAMP NOT NULL DEFAULT now(),
                CONSTRAINT "PK_bebc9158e480b949565b4dc7a82" PRIMARY KEY ("id")
            )
        `);

        await queryRunner.query(`
            CREATE TABLE "price" (
                "id" SERIAL NOT NULL,
                "price" decimal(10,2) NOT NULL,
                "createdAt" TIMESTAMP NOT NULL DEFAULT now(),
                "productId" integer,
                CONSTRAINT "PK_d163e55e8cce6908b2e0f27cea4" PRIMARY KEY ("id")
            )
        `);

        await queryRunner.query(`
            ALTER TABLE "price"
            ADD CONSTRAINT "FK_ac8cd79f77674c83956f6c11bfe"
            FOREIGN KEY ("productId")
            REFERENCES "product"("id")
            ON DELETE CASCADE
        `);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`
            ALTER TABLE "price" DROP CONSTRAINT "FK_ac8cd79f77674c83956f6c11bfe"
        `);
        await queryRunner.query(`DROP TABLE "price"`);
        await queryRunner.query(`DROP TABLE "product"`);
    }
}
