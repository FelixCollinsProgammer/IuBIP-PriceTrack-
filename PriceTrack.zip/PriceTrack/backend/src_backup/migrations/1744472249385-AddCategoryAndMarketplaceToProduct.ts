import { MigrationInterface, QueryRunner } from "typeorm";

export class AddCategoryAndMarketplaceToProduct1744472249385 implements MigrationInterface {
    name = 'AddCategoryAndMarketplaceToProduct1744472249385'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "product" ADD "category" character varying DEFAULT 'Прочее'`);
        await queryRunner.query(`ALTER TABLE "product" ADD "marketplace" character varying`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "product" DROP COLUMN "marketplace"`);
        await queryRunner.query(`ALTER TABLE "product" DROP COLUMN "category"`);
    }
}
