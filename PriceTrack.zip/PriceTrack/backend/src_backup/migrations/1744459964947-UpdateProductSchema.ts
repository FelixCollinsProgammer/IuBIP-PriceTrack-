import { MigrationInterface, QueryRunner } from "typeorm";

export class UpdateProductSchema1744459964947 implements MigrationInterface {

    public async up(queryRunner: QueryRunner): Promise<void> {
        try {
            // Проверяем, существует ли уже колонка
            const tableColumns = await queryRunner.query(`
                SELECT column_name
                FROM information_schema.columns
                WHERE table_name = 'product'
            `);
            
            const hasCurrentPriceColumn = tableColumns.some(
                (column: any) => column.column_name === 'currentPrice'
            );
            
            if (!hasCurrentPriceColumn) {
                console.log('Добавление колонки currentPrice в таблицу product');
                
                await queryRunner.query(`
                    ALTER TABLE "product" 
                    ADD COLUMN "currentPrice" DECIMAL(10,2) DEFAULT 0
                `);
                
                console.log('Обновление значений currentPrice на основе последних цен');
                
                await queryRunner.query(`
                    UPDATE "product" p
                    SET "currentPrice" = (
                        SELECT price FROM "price"
                        WHERE "productId" = p.id
                        ORDER BY "createdAt" DESC
                        LIMIT 1
                    )
                    WHERE EXISTS (
                        SELECT 1 FROM "price"
                        WHERE "productId" = p.id
                    )
                `);
                
                console.log('Колонка currentPrice успешно добавлена и заполнена');
            } else {
                console.log('Колонка currentPrice уже существует в таблице product');
            }
        } catch (error) {
            console.error('Ошибка при обновлении схемы:', error);
            throw error;
        }
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        try {
            // Проверяем, существует ли колонка
            const tableColumns = await queryRunner.query(`
                SELECT column_name
                FROM information_schema.columns
                WHERE table_name = 'product'
            `);
            
            const hasCurrentPriceColumn = tableColumns.some(
                (column: any) => column.column_name === 'currentPrice'
            );
            
            if (hasCurrentPriceColumn) {
                console.log('Удаление колонки currentPrice из таблицы product');
                
                await queryRunner.query(`
                    ALTER TABLE "product" 
                    DROP COLUMN "currentPrice"
                `);
                
                console.log('Колонка currentPrice успешно удалена');
            } else {
                console.log('Колонка currentPrice не существует в таблице product');
            }
        } catch (error) {
            console.error('Ошибка при откате схемы:', error);
            throw error;
        }
    }
}
