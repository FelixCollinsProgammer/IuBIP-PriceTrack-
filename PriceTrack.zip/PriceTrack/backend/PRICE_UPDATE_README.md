# Price Update System

This system automatically updates the prices of all products in the PriceTrack database at regular intervals. It helps keep product prices current and maintains a price history for each product.

## How It Works

The price update system does the following:
1. Connects to the database
2. Retrieves all products
3. For each product:
   - Parses the URL to get the current price
   - Creates a new price record in the database
   - Updates the product's current price
4. Logs the results

## Setup

### Manual Execution

To run the price update manually:

```bash
cd /path/to/backend
./update-prices.sh
```

### Automated Execution (Cron Job)

To set up automatic price updates every hour:

```bash
cd /path/to/backend
./setup-cron.sh
```

This will create a cron job that runs the update script every hour. You can check the logs in:
- `cron.log` - For any cron-related messages
- `update-prices.log` - For a record of update completions

## Customizing Update Frequency

To change how often prices are updated:

1. Edit the `setup-cron.sh` script
2. Change the cron schedule expression (default is `0 * * * *` which runs hourly)

Common cron schedules:
- Every 2 hours: `0 */2 * * *`
- Daily at midnight: `0 0 * * *`
- Every 15 minutes: `*/15 * * * *`

## Troubleshooting

If you encounter issues:

1. Check the logs in `cron.log` and `update-prices.log`
2. Make sure the database connection parameters in `.env` are correct
3. Ensure the scripts have execute permissions: `chmod +x update-prices.sh setup-cron.sh`
4. If you're getting parsing errors, check if the `ParserService` can correctly parse the marketplace URLs

For more information, please refer to the main documentation. 