import { DefaultTheme } from 'styled-components';

// Add DefaultTheme interface extension
declare module 'styled-components' {
  export interface DefaultTheme {
    colors: {
      primary: string;
      primaryLight: string;
      secondary: string;
      secondaryLight: string;
      background: string;
      backgroundSecondary: string;
      backgroundAlt: string;
      backgroundHover: string;
      backgroundDisabled: string;
      cardBackground: string;
      surface: string;
      surfaceAlt: string;
      text: string;
      textSecondary: string;
      textTertiary: string;
      textLight: string;
      textDark: string;
      border: string;
      inputBackground: string;
      error: string;
      success: string;
      warning: string;
      info: string;
      accent: string;
      lightText: string;
      borderColor: string;
      buttonText: string;
      modalBackground: string;
      chart: {
        background: string;
        grid: string;
        tooltip: string;
        tooltipText: string;
        line?: string;
        text?: string;
        area?: string;
      };
    };
    shadows: {
      sm: string;
      md: string;
      lg: string;
      small: string;
      medium: string;
      large: string;
    };
    borderRadius: {
      small: string;
      medium: string;
      large: string;
    };
    transitions: {
      default: string;
      fast: string;
      slow: string;
      medium: string;
    };
    spacing: {
      xs: string;
      sm: string;
      md: string;
      lg: string;
      xl: string;
      small: string;
      medium: string;
      large: string;
    };
  }
}

// Base theme with shared properties
const baseTheme = {
  shadows: {
    sm: '0 1px 3px rgba(0, 0, 0, 0.12)',
    md: '0 4px 6px rgba(0, 0, 0, 0.15)',
    lg: '0 10px 20px rgba(0, 0, 0, 0.18)',
    small: '0 1px 3px rgba(0, 0, 0, 0.12)',
    medium: '0 4px 6px rgba(0, 0, 0, 0.15)',
    large: '0 10px 20px rgba(0, 0, 0, 0.18)'
  },
  transitions: {
    slow: '0.5s ease-in-out',
    medium: '0.25s ease-in-out',
    fast: '0.15s ease-in-out',
    default: '0.25s ease-in-out'
  },
  borderRadius: {
    small: '4px',
    medium: '8px',
    large: '16px',
  },
  spacing: {
    xs: '4px',
    sm: '8px',
    md: '16px',
    lg: '24px',
    xl: '32px',
    small: '8px',
    medium: '16px',
    large: '24px'
  },
};

export const lightTheme: DefaultTheme = {
  ...baseTheme,
  colors: {
    primary: '#2563eb',
    primaryLight: '#3b82f6',
    secondary: '#4f46e5',
    secondaryLight: '#6366f1',
    background: '#ffffff',
    backgroundSecondary: '#f9fafb',
    backgroundAlt: '#f3f4f6',
    backgroundHover: '#f3f4f6',
    backgroundDisabled: '#e5e7eb',
    cardBackground: '#ffffff',
    surface: '#ffffff',
    surfaceAlt: '#f9fafb',
    text: '#1f2937',
    textSecondary: '#6b7280',
    textTertiary: '#9ca3af',
    textLight: '#9ca3af',
    textDark: '#111827',
    buttonText: '#ffffff',
    border: '#e5e7eb',
    borderColor: '#e5e7eb',
    inputBackground: '#ffffff',
    error: '#ef4444',
    success: '#22c55e',
    warning: '#f59e0b',
    info: '#3b82f6',
    accent: '#8b5cf6',
    lightText: '#ffffff',
    modalBackground: '#ffffff',
    chart: {
      background: '#ffffff',
      grid: '#e5e7eb',
      tooltip: '#1f2937',
      tooltipText: '#ffffff',
      line: '#3b82f6',
      text: '#6b7280',
      area: 'rgba(59, 130, 246, 0.2)'
    }
  },
};

export const darkTheme: DefaultTheme = {
  ...baseTheme,
  colors: {
    primary: '#3b82f6',
    primaryLight: '#60a5fa',
    secondary: '#6366f1',
    secondaryLight: '#818cf8',
    background: '#111827',
    backgroundSecondary: '#1f2937',
    backgroundAlt: '#374151',
    backgroundHover: '#374151',
    backgroundDisabled: '#4b5563',
    cardBackground: '#1f2937',
    surface: '#1f2937',
    surfaceAlt: '#374151',
    text: '#f3f4f6',
    textSecondary: '#9ca3af',
    textTertiary: '#6b7280',
    textLight: '#d1d5db',
    textDark: '#111827',
    buttonText: '#ffffff',
    border: '#374151',
    borderColor: '#374151',
    inputBackground: '#374151',
    error: '#f87171',
    success: '#4ade80',
    warning: '#fbbf24',
    info: '#60a5fa',
    accent: '#a78bfa',
    lightText: '#ffffff',
    modalBackground: '#1f2937',
    chart: {
      background: '#1f2937',
      grid: '#374151', 
      tooltip: '#f3f4f6',
      tooltipText: '#111827',
      line: '#60a5fa',
      text: '#9ca3af',
      area: 'rgba(96, 165, 250, 0.2)'
    }
  },
}; 