import React, { useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { ThemeProvider as StyledThemeProvider } from 'styled-components';
import { ThemeProvider as MuiThemeProvider, createTheme } from '@mui/material/styles';
import CssBaseline from '@mui/material/CssBaseline';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { darkTheme, lightTheme } from './theme';
import { GlobalStyle } from './globalStyles';
import Navbar from './components/Navbar';
import Home from './pages/Home';
import Products from './pages/Products';
import ProductDetails from './pages/ProductDetails';
import Analytics from './pages/Analytics';
import Contact from './pages/Contact';
import Profile from './pages/Profile';
import Categories from './pages/Categories';
import { useTheme } from './hooks/useTheme';
import AddProduct from './pages/AddProduct';
import ParserTest from './pages/ParserTest';
import AuthWrapper from './components/AuthWrapper';

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: 1,
      refetchOnWindowFocus: false,
    },
  },
});

const App: React.FC = () => {
  const { theme, toggleTheme } = useTheme();
  const currentTheme = theme === 'dark' ? darkTheme : lightTheme;

  // Создаем тему Material UI
  const muiTheme = createTheme({
    palette: {
      mode: theme === 'dark' ? 'dark' : 'light',
      primary: {
        main: currentTheme.colors.primary,
        light: currentTheme.colors.primaryLight,
      },
      secondary: {
        main: currentTheme.colors.secondary,
        light: currentTheme.colors.secondaryLight,
      },
      error: {
        main: currentTheme.colors.error,
      },
      warning: {
        main: currentTheme.colors.warning,
      },
      info: {
        main: currentTheme.colors.info,
      },
      success: {
        main: currentTheme.colors.success,
      },
      background: {
        default: currentTheme.colors.background,
        paper: currentTheme.colors.cardBackground,
      },
      text: {
        primary: currentTheme.colors.text,
        secondary: currentTheme.colors.textSecondary,
      },
    },
    shape: {
      borderRadius: parseInt(currentTheme.borderRadius.medium),
    },
    typography: {
      fontFamily: '"Roboto", "Helvetica", "Arial", sans-serif',
    },
  });

  useEffect(() => {
    console.log('App component mounted');
  }, []);

  // Выводим информацию о подключении к API в консоль
  console.log('App initialized');
  // @ts-ignore - игнорируем ошибку TS для env переменных
  console.log('Using API URL:', import.meta.env.VITE_API_URL || 'http://localhost:5002/api');

  return (
    <QueryClientProvider client={queryClient}>
      <MuiThemeProvider theme={muiTheme}>
        <StyledThemeProvider theme={currentTheme}>
          <CssBaseline />
          <GlobalStyle />
          <AuthWrapper>
            <Router>
              <div style={{ minHeight: '100vh' }}>
                <Navbar onThemeToggle={toggleTheme} isDark={theme === 'dark'} />
                <Routes>
                  <Route path="/" element={<Home />} />
                  <Route path="/products" element={<Products />} />
                  <Route path="/products/:id" element={<ProductDetails />} />
                  <Route path="/analytics" element={<Analytics />} />
                  <Route path="/contact" element={<Contact />} />
                  <Route path="/profile" element={<Profile />} />
                  <Route path="/add" element={<AddProduct />} />
                  <Route path="/categories" element={<Categories />} />
                  <Route path="/parsers" element={<ParserTest />} />
                  <Route path="*" element={<Navigate to="/" replace />} />
                </Routes>
              </div>
            </Router>
            <ToastContainer
              position="top-right"
              autoClose={3000}
              hideProgressBar={false}
              newestOnTop
              closeOnClick
              rtl={false}
              pauseOnFocusLoss
              draggable
              pauseOnHover
              theme={theme}
            />
          </AuthWrapper>
        </StyledThemeProvider>
      </MuiThemeProvider>
    </QueryClientProvider>
  );
};

export default App; 