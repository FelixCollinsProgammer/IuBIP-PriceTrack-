import 'styled-components';
import { Theme as MuiTheme } from '@mui/material/styles';

declare module 'styled-components' {
  export interface DefaultTheme {
    colors: {
      primary: string;
      primaryLight: string;
      secondary: string;
      secondaryLight: string;
      background: string;
      backgroundSecondary: string;
      backgroundAlt: string;
      backgroundHover: string;
      backgroundDisabled: string;
      cardBackground: string;
      inputBackground: string;
      text: string;
      textSecondary: string;
      textLight: string;
      textDark: string;
      buttonText: string;
      border: string;
      error: string;
      success: string;
      warning: string;
      info: string;
      surface: string;
      modalBackground: string;
      chart: {
        background: string;
        grid: string;
        tooltip: string;
        tooltipText: string;
      };
    };
    shadows: {
      sm: string;
      md: string;
      lg: string;
    };
    borderRadius: {
      small: string;
      medium: string;
      large: string;
    };
    transitions: {
      slow: string;
      medium: string;
      fast: string;
    };
    spacing: {
      xs: string;
      sm: string;
      md: string;
      lg: string;
      xl: string;
    };
    // Для совместимости с Material UI
    mui?: MuiTheme;
  }
} 