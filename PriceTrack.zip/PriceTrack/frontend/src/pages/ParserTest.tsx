import React from 'react';
import { Helmet } from 'react-helmet';
import ParserTester from '../components/ParserTester';

const ParserTest: React.FC = () => {
  return (
    <>
      <Helmet>
        <title>Тестирование парсеров | PriceTrack</title>
      </Helmet>
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-2xl font-bold mb-6">Тестирование парсеров маркетплейсов</h1>
        
        <div className="grid grid-cols-1 gap-6">
          <ParserTester />
          
          <div className="bg-white dark:bg-gray-900 rounded-lg shadow-sm p-6 mt-6">
            <h2 className="text-xl font-bold mb-4">О парсерах</h2>
            <p className="mb-3">
              PriceTrack использует две технологии для парсинга данных с маркетплейсов:
            </p>
            
            <div className="mb-4">
              <h3 className="text-lg font-semibold mb-2">Selenium Parser</h3>
              <ul className="list-disc list-inside ml-4">
                <li>Более надёжное обнаружение товаров и цен</li>
                <li>Лучше справляется с защитой от ботов</li>
                <li>Имитирует поведение реального пользователя</li>
                <li>Может быть медленнее Playwright</li>
              </ul>
            </div>
            
            <div className="mb-4">
              <h3 className="text-lg font-semibold mb-2">Playwright Parser</h3>
              <ul className="list-disc list-inside ml-4">
                <li>Быстрее на некоторых маркетплейсах</li>
                <li>Меньше зависимостей от системы</li>
                <li>Может работать менее стабильно на сайтах с защитой от ботов</li>
              </ul>
            </div>
            
            <p className="mt-3">
              Поддерживаемые маркетплейсы: <strong>Ozon, Wildberries, AliExpress</strong>
            </p>
          </div>
        </div>
      </div>
    </>
  );
};

export default ParserTest; 