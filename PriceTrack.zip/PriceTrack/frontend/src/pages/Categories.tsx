import React, { useState, useEffect } from 'react';
import styled from 'styled-components';
import { motion } from 'framer-motion';
import { toast } from 'react-toastify';
import axios from 'axios';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';

const Container = styled.div`
  max-width: 800px;
  margin: 0 auto;
  padding: 2rem;
  background-color: ${({ theme }) => theme.colors.surface};
  border-radius: ${({ theme }) => theme.borderRadius.medium};
  box-shadow: ${({ theme }) => theme.shadows.md};
`;

const Title = styled.h1`
  color: ${({ theme }) => theme.colors.text};
  margin-bottom: 1.5rem;
  font-size: 1.8rem;
`;

const Description = styled.p`
  color: ${({ theme }) => theme.colors.textLight};
  margin-bottom: 2rem;
  font-size: 1rem;
`;

const CategoryList = styled.div`
  display: flex;
  flex-wrap: wrap;
  gap: 1rem;
  margin-bottom: 2rem;
`;

const CategoryItem = styled.div`
  display: flex;
  flex-direction: column;
  background-color: ${({ theme }) => theme.colors.backgroundAlt};
  border-radius: ${({ theme }) => theme.borderRadius.medium};
  box-shadow: ${({ theme }) => theme.shadows.sm};
  padding: 1rem;
  width: calc(33.333% - 1rem);
  min-width: 200px;
  
  @media (max-width: 768px) {
    width: calc(50% - 1rem);
  }
  
  @media (max-width: 480px) {
    width: 100%;
  }
`;

const CategoryName = styled.div`
  color: ${({ theme }) => theme.colors.text};
  font-size: 1.1rem;
  font-weight: 500;
  margin-bottom: 0.5rem;
`;

const CategoryCount = styled.div`
  color: ${({ theme }) => theme.colors.textLight};
  font-size: 0.9rem;
  margin-bottom: 1rem;
`;

const CategoryActions = styled.div`
  display: flex;
  justify-content: flex-end;
  gap: 0.5rem;
  margin-top: auto;
`;

const ActionButton = styled.button`
  background: none;
  border: none;
  cursor: pointer;
  font-size: 1rem;
  color: ${({ theme }) => theme.colors.textLight};
  padding: 0.25rem;
  
  &:hover {
    color: ${({ theme }) => theme.colors.primary};
  }
`;

const DeleteButton = styled(ActionButton)`
  &:hover {
    color: ${({ theme }) => theme.colors.error};
  }
`;

const AddCategoryForm = styled.form`
  display: flex;
  gap: 1rem;
  margin-bottom: 2rem;
  padding: 1.5rem;
  background-color: ${({ theme }) => theme.colors.backgroundAlt};
  border-radius: ${({ theme }) => theme.borderRadius.medium};
  box-shadow: ${({ theme }) => theme.shadows.sm};
`;

const Input = styled.input`
  padding: 0.75rem;
  border-radius: ${({ theme }) => theme.borderRadius.small};
  border: 1px solid ${({ theme }) => theme.colors.border};
  background-color: ${({ theme }) => theme.colors.background};
  color: ${({ theme }) => theme.colors.text};
  flex: 1;
  
  &:focus {
    outline: none;
    border-color: ${({ theme }) => theme.colors.primary};
  }
`;

const Button = styled(motion.button)`
  padding: 0.75rem 1.5rem;
  background-color: ${({ theme }) => theme.colors.primary};
  color: white;
  border: none;
  border-radius: ${({ theme }) => theme.borderRadius.small};
  cursor: pointer;
  font-weight: 500;
  transition: ${({ theme }) => theme.transitions.fast};
  
  &:hover {
    opacity: 0.9;
  }
  
  &:disabled {
    background-color: ${({ theme }) => theme.colors.border};
    cursor: not-allowed;
  }
`;

const Modal = styled.div`
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1000;
`;

const ModalBackdrop = styled.div`
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: rgba(0, 0, 0, 0.5);
`;

const ModalContent = styled.div`
  position: relative;
  width: 90%;
  max-width: 500px;
  background-color: ${({ theme }) => theme.colors.surface};
  border-radius: ${({ theme }) => theme.borderRadius.medium};
  padding: 2rem;
  z-index: 1001;
`;

const ModalTitle = styled.h2`
  color: ${({ theme }) => theme.colors.text};
  margin-bottom: 1.5rem;
  font-size: 1.5rem;
`;

const ModalForm = styled.form`
  display: flex;
  flex-direction: column;
  gap: 1rem;
`;

const ModalActions = styled.div`
  display: flex;
  justify-content: flex-end;
  gap: 1rem;
  margin-top: 1.5rem;
`;

const CancelButton = styled(Button)`
  background-color: ${({ theme }) => theme.colors.border};
`;

// Get API_URL from environment
const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:5002/api';

// API service for categories
const CategoryService = {
  // Get categories from local storage (fallback if not implemented on backend yet)
  getLocalCategories: (): string[] => {
    const savedCategories = localStorage.getItem('productCategories');
    return savedCategories ? JSON.parse(savedCategories) : ['Электроника', 'Одежда', 'Бытовая техника', 'Продукты', 'Книги', 'Прочее'];
  },
  
  // Save categories to local storage
  saveLocalCategories: (categories: string[]): void => {
    localStorage.setItem('productCategories', JSON.stringify(categories));
  },
  
  // Get all categories with counts (for future backend implementation)
  getAllCategories: async () => {
    try {
      const response = await axios.get(`${API_URL}/categories`);
      return response.data;
    } catch (error) {
      console.error('Error fetching categories:', error);
      // Fallback to local storage if API endpoint not implemented
      const localCategories = CategoryService.getLocalCategories();
      return localCategories.map(name => ({ name, count: 0 }));
    }
  },
  
  // Add a new category (for future backend implementation)
  addCategory: async (name: string) => {
    try {
      const response = await axios.post(`${API_URL}/categories`, { name });
      return response.data;
    } catch (error) {
      console.error('Error adding category:', error);
      // Fallback for local storage
      const categories = CategoryService.getLocalCategories();
      if (!categories.includes(name)) {
        categories.push(name);
        CategoryService.saveLocalCategories(categories);
      }
      return { name, count: 0 };
    }
  },
  
  // Update a category (for future backend implementation)
  updateCategory: async (id: string, name: string) => {
    try {
      const response = await axios.put(`${API_URL}/categories/${id}`, { name });
      return response.data;
    } catch (error) {
      console.error('Error updating category:', error);
      // Fallback for local storage
      const categories = CategoryService.getLocalCategories();
      const index = categories.findIndex(c => c === id);
      if (index !== -1) {
        categories[index] = name;
        CategoryService.saveLocalCategories(categories);
      }
      return { name, count: 0 };
    }
  },
  
  // Delete a category (for future backend implementation)
  deleteCategory: async (id: string) => {
    try {
      await axios.delete(`${API_URL}/categories/${id}`);
      return true;
    } catch (error) {
      console.error('Error deleting category:', error);
      // Fallback for local storage
      const categories = CategoryService.getLocalCategories();
      const filteredCategories = categories.filter(c => c !== id);
      CategoryService.saveLocalCategories(filteredCategories);
      return true;
    }
  },
  
  // Get product count for category (for future backend implementation)
  getCategoryProductCount: async (category: string) => {
    try {
      const response = await axios.get(`${API_URL}/products?category=${category}`);
      return response.data.data.length;
    } catch (error) {
      console.error('Error getting product count:', error);
      return 0;
    }
  }
};

interface Category {
  name: string;
  count: number;
}

const Categories: React.FC = () => {
  const [newCategory, setNewCategory] = useState('');
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [currentCategory, setCurrentCategory] = useState<{originalName: string, newName: string} | null>(null);
  
  const queryClient = useQueryClient();
  
  // Query for fetching categories
  const { data: categories = [], isLoading, error } = useQuery<Category[]>({
    queryKey: ['categories'],
    queryFn: async () => {
      try {
        // Try to get categories from backend
        return await CategoryService.getAllCategories();
      } catch (error) {
        console.error('Error fetching categories, falling back to local storage:', error);
        // Fallback to local storage
        const localCategories = CategoryService.getLocalCategories();
        // Fetch product counts for each category
        const categoriesWithCounts = await Promise.all(
          localCategories.map(async (name) => {
            const count = await CategoryService.getCategoryProductCount(name);
            return { name, count };
          })
        );
        return categoriesWithCounts;
      }
    }
  });
  
  // Mutation for adding a category
  const addCategoryMutation = useMutation({
    mutationFn: (name: string) => CategoryService.addCategory(name),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['categories'] });
      toast.success('Категория успешно добавлена');
      setNewCategory('');
    },
    onError: (error) => {
      console.error('Error adding category:', error);
      toast.error('Ошибка при добавлении категории');
    }
  });
  
  // Mutation for updating a category
  const updateCategoryMutation = useMutation({
    mutationFn: ({ originalName, newName }: { originalName: string, newName: string }) => 
      CategoryService.updateCategory(originalName, newName),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['categories'] });
      toast.success('Категория успешно обновлена');
      setIsEditModalOpen(false);
      setCurrentCategory(null);
    },
    onError: (error) => {
      console.error('Error updating category:', error);
      toast.error('Ошибка при обновлении категории');
    }
  });
  
  // Mutation for deleting a category
  const deleteCategoryMutation = useMutation({
    mutationFn: (name: string) => CategoryService.deleteCategory(name),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['categories'] });
      toast.success('Категория успешно удалена');
    },
    onError: (error) => {
      console.error('Error deleting category:', error);
      toast.error('Ошибка при удалении категории');
    }
  });
  
  // Handle adding a new category
  const handleAddCategory = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!newCategory.trim()) {
      toast.error('Название категории не может быть пустым');
      return;
    }
    
    // Check for duplicates
    if (categories.some(cat => cat.name.toLowerCase() === newCategory.trim().toLowerCase())) {
      toast.error('Категория с таким названием уже существует');
      return;
    }
    
    addCategoryMutation.mutate(newCategory.trim());
  };
  
  // Handle editing a category
  const handleEditCategory = (category: Category) => {
    setCurrentCategory({
      originalName: category.name,
      newName: category.name
    });
    setIsEditModalOpen(true);
  };
  
  // Handle saving edited category
  const handleSaveEdit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!currentCategory) return;
    
    if (!currentCategory.newName.trim()) {
      toast.error('Название категории не может быть пустым');
      return;
    }
    
    // Check for duplicates
    if (
      currentCategory.originalName.toLowerCase() !== currentCategory.newName.toLowerCase() &&
      categories.some(cat => cat.name.toLowerCase() === currentCategory.newName.trim().toLowerCase())
    ) {
      toast.error('Категория с таким названием уже существует');
      return;
    }
    
    updateCategoryMutation.mutate({
      originalName: currentCategory.originalName,
      newName: currentCategory.newName.trim()
    });
  };
  
  // Handle deleting a category
  const handleDeleteCategory = (category: Category) => {
    // Check if it's the last category
    if (categories.length <= 1) {
      toast.error('Должна остаться хотя бы одна категория');
      return;
    }
    
    // Confirm deletion
    if (window.confirm(`Вы уверены, что хотите удалить категорию "${category.name}"?`)) {
      deleteCategoryMutation.mutate(category.name);
    }
  };
  
  if (isLoading) return <Container>Загрузка категорий...</Container>;
  if (error) return <Container>Ошибка загрузки категорий</Container>;
  
  return (
    <Container>
      <Title>Управление категориями</Title>
      <Description>
        Создавайте, редактируйте и удаляйте категории товаров для более удобной организации ваших отслеживаемых товаров.
      </Description>
      
      <AddCategoryForm onSubmit={handleAddCategory}>
        <Input
          type="text"
          value={newCategory}
          onChange={(e) => setNewCategory(e.target.value)}
          placeholder="Введите название новой категории"
        />
        <Button 
          type="submit" 
          disabled={!newCategory.trim() || addCategoryMutation.isPending}
        >
          {addCategoryMutation.isPending ? 'Добавление...' : 'Добавить категорию'}
        </Button>
      </AddCategoryForm>
      
      <CategoryList>
        {categories.map((category) => (
          <CategoryItem key={category.name}>
            <CategoryName>{category.name}</CategoryName>
            <CategoryCount>
              {category.count} {category.count === 1 ? 'товар' : 
                category.count > 1 && category.count < 5 ? 'товара' : 'товаров'}
            </CategoryCount>
            <CategoryActions>
              <ActionButton 
                onClick={() => handleEditCategory(category)}
                title="Редактировать"
              >
                ✎
              </ActionButton>
              <DeleteButton 
                onClick={() => handleDeleteCategory(category)}
                title="Удалить"
              >
                ✕
              </DeleteButton>
            </CategoryActions>
          </CategoryItem>
        ))}
      </CategoryList>
      
      {isEditModalOpen && currentCategory && (
        <Modal>
          <ModalBackdrop onClick={() => setIsEditModalOpen(false)} />
          <ModalContent>
            <ModalTitle>Редактировать категорию</ModalTitle>
            <ModalForm onSubmit={handleSaveEdit}>
              <Input
                type="text"
                value={currentCategory.newName}
                onChange={(e) => setCurrentCategory({
                  ...currentCategory,
                  newName: e.target.value
                })}
                placeholder="Название категории"
                autoFocus
              />
              <ModalActions>
                <CancelButton 
                  type="button" 
                  onClick={() => setIsEditModalOpen(false)}
                >
                  Отмена
                </CancelButton>
                <Button 
                  type="submit"
                  disabled={!currentCategory.newName.trim() || updateCategoryMutation.isPending}
                >
                  {updateCategoryMutation.isPending ? 'Сохранение...' : 'Сохранить'}
                </Button>
              </ModalActions>
            </ModalForm>
          </ModalContent>
        </Modal>
      )}
    </Container>
  );
};

export default Categories; 