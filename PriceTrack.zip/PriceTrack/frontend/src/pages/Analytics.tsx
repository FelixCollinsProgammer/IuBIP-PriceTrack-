import React, { useMemo, useState } from 'react';
import styled from 'styled-components';
import { useQuery } from '@tanstack/react-query';
import { ProductService } from '../services/ProductService';
import { motion } from 'framer-motion';
import { ErrorBoundary } from 'react-error-boundary';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  ArcElement,
  Title as ChartTitle,
  Tooltip,
  Legend,
  Filler,
} from 'chart.js';
import { Line, Bar, Pie } from 'react-chartjs-2';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  ArcElement,
  ChartTitle,
  Tooltip,
  Legend,
  Filler
);

const Container = styled.div`
  max-width: 1200px;
  margin: 0 auto;
  padding: 2rem;
`;

const PageHeader = styled.div`
  margin-bottom: 2rem;
`;

const Card = styled(motion.div)`
  background: ${({ theme }) => theme.colors?.cardBackground || '#ffffff'};
  border-radius: ${({ theme }) => theme.borderRadius?.medium || '8px'};
  padding: 2rem;
  box-shadow: ${({ theme }) => theme.shadows?.md || '0 4px 6px rgba(0, 0, 0, 0.1)'};
  margin-bottom: 2rem;
  overflow: hidden;
`;

const AnalyticsTitle = styled.h1`
  color: ${({ theme }) => theme.colors?.text || '#333333'};
  margin-bottom: 1rem;
`;

const Subtitle = styled.h2`
  color: ${({ theme }) => theme.colors?.primary || '#0066cc'};
  margin-bottom: 1rem;
  font-size: 1.5rem;
`;

const Text = styled.p`
  color: ${({ theme }) => theme.colors?.text || '#333333'};
  line-height: 1.6;
  margin-bottom: 1.5rem;
`;

const StatGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
  gap: 1.5rem;
  margin: 2rem 0;
`;

const StatCard = styled(motion.div)`
  background: ${({ theme }) => theme.colors.surface};
  border-radius: ${({ theme }) => theme.borderRadius.medium};
  padding: 1.5rem;
  box-shadow: ${({ theme }) => theme.shadows.sm};
  text-align: center;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  height: 180px;
`;

const StatValue = styled.div`
  font-size: 2.5rem;
  font-weight: bold;
  color: ${({ theme }) => theme.colors.primary};
  margin-bottom: 0.5rem;
`;

const StatLabel = styled.div`
  color: ${({ theme }) => theme.colors.text};
  font-size: 1rem;
`;

const Grid = styled.div`
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 2rem;
  margin: 2rem 0;
  
  @media (max-width: 768px) {
    grid-template-columns: 1fr;
  }
`;

const LoadingContainer = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  height: 300px;
`;

const Spinner = styled(motion.div)`
  width: 40px;
  height: 40px;
  border: 3px solid ${({ theme }) => theme.colors.background};
  border-top: 3px solid ${({ theme }) => theme.colors.primary};
  border-radius: 50%;
`;

const MarketplaceLabel = styled.div`
  display: flex;
  align-items: center;
  margin-bottom: 0.5rem;
  font-size: 0.9rem;
  
  &:before {
    content: '';
    display: inline-block;
    width: 12px;
    height: 12px;
    border-radius: 50%;
    margin-right: 8px;
    background-color: ${props => props.color || '#ccc'};
  }
`;

const PriceTable = styled.table`
  width: 100%;
  border-collapse: collapse;
  margin: 1.5rem 0;
`;

const TableHeader = styled.th`
  text-align: left;
  padding: 1rem;
  border-bottom: 1px solid ${({ theme }) => theme.colors.border};
  color: ${({ theme }) => theme.colors.text};
`;

const TableRow = styled.tr`
  &:nth-child(even) {
    background-color: ${({ theme }) => theme.colors.backgroundAlt};
  }
  
  &:hover {
    background-color: ${({ theme }) => theme.colors.backgroundHover};
  }
`;

const TableCell = styled.td`
  padding: 1rem;
  border-bottom: 1px solid ${({ theme }) => theme.colors.border};
  color: ${({ theme }) => theme.colors.text};
`;

const PriceChange = styled.span<{ isPositive: boolean }>`
  color: ${props => props.isPositive ? 'green' : 'red'};
  font-weight: bold;
  display: flex;
  align-items: center;
  
  &:before {
    content: '${props => props.isPositive ? '↑' : '↓'}';
    margin-right: 4px;
  }
`;

const NoData = styled.div`
  text-align: center;
  padding: 3rem;
  color: ${({ theme }) => theme.colors.textLight};
  font-size: 1.2rem;
`;

const ErrorFallback = ({ error, resetErrorBoundary }) => {
  return (
    <ErrorState>
      <h3>Ошибка при загрузке аналитики</h3>
      <p>{error.message}</p>
      <button onClick={resetErrorBoundary}>Попробовать снова</button>
    </ErrorState>
  );
};

const ErrorState = styled.div`
  padding: 2rem;
  margin: 2rem 0;
  background-color: ${({ theme }) => theme.colors.error + '10'};
  border-radius: ${({ theme }) => theme.borderRadius.medium};
  text-align: center;
  
  h3 {
    color: ${({ theme }) => theme.colors.error};
    margin-bottom: 1rem;
  }
  
  button {
    background-color: ${({ theme }) => theme.colors.primary};
    color: white;
    border: none;
    padding: 0.5rem 1rem;
    border-radius: ${({ theme }) => theme.borderRadius.small};
    cursor: pointer;
    margin-top: 1rem;
  }
`;

const Analytics: React.FC = () => {
  const [selectedTimeRange, setSelectedTimeRange] = useState('all');
  
  // Fetch all products with price history
  const { data: products, isLoading, error, refetch } = useQuery({
    queryKey: ['products-analytics'],
    queryFn: ProductService.getProducts,
    retry: 2,
    refetchOnWindowFocus: false,
  });

  // Calculate statistics based on product data
  const stats = useMemo(() => {
    if (!products || products.length === 0) return null;
    
    try {
      let totalPriceDecreases = 0;
      let totalPriceIncreases = 0;
      let totalSaved = 0;
      let totalItems = products.length;
      let marketplaces: Record<string, number> = {};
      
      // Price histories for overall trend chart
      let allPricePoints: {date: string, price: number, product: string}[] = [];
      
      // Latest price changes for top products
      let priceChanges: {
        id: number,
        name: string,
        currentPrice: number,
        previousPrice: number | null,
        change: number,
        changePercent: number,
        url: string
      }[] = [];
      
      products.forEach(product => {
        // Check if product has the necessary data
        if (!product || !product.prices) return;
        
        // Extract marketplace
        const marketplace = product.marketplace || 'Другое';
        marketplaces[marketplace] = (marketplaces[marketplace] || 0) + 1;
        
        const prices = product.prices || [];
        if (prices.length >= 2) {
          const currentPrice = prices[0].price;
          const previousPrice = prices[1].price;
          const change = currentPrice - previousPrice;
          
          if (change < 0) {
            totalPriceDecreases++;
            totalSaved += Math.abs(change);
          } else if (change > 0) {
            totalPriceIncreases++;
          }
          
          // Add to price changes list
          priceChanges.push({
            id: product.id,
            name: product.name,
            currentPrice,
            previousPrice,
            change,
            changePercent: (change / previousPrice) * 100,
            url: product.url
          });
          
          // Add price points for the trend chart
          prices.forEach(price => {
            if (price && price.createdAt) {
              allPricePoints.push({
                date: new Date(price.createdAt).toLocaleDateString('ru-RU'),
                price: price.price,
                product: product.name
              });
            }
          });
        }
      });
      
      // Sort price changes by absolute change value
      priceChanges.sort((a, b) => Math.abs(b.change) - Math.abs(a.change));
      
      // Calculate average savings
      const avgSaving = totalPriceDecreases > 0 
        ? (totalSaved / totalPriceDecreases).toFixed(2) 
        : 0;
      
      return {
        totalItems,
        totalPriceDecreases,
        totalPriceIncreases,
        avgSaving,
        marketplaces,
        allPricePoints,
        priceChanges: priceChanges.slice(0, 5) // Top 5 price changes
      };
    } catch (error) {
      console.error("Error calculating analytics stats:", error);
      return null;
    }
  }, [products]);
  
  // Prepare chart data
  const marketplaceChartData = useMemo(() => {
    if (!stats || !stats.marketplaces || Object.keys(stats.marketplaces).length === 0) {
      return {
        labels: ['Нет данных'],
        datasets: [{
          data: [1],
          backgroundColor: ['#ccc'],
          borderWidth: 0
        }]
      };
    }
    
    const labels = Object.keys(stats.marketplaces);
    const data = labels.map(key => stats.marketplaces[key]);
    const backgroundColors = [
      'rgba(255, 99, 132, 0.8)',
      'rgba(54, 162, 235, 0.8)',
      'rgba(255, 206, 86, 0.8)',
      'rgba(75, 192, 192, 0.8)',
      'rgba(153, 102, 255, 0.8)'
    ];
    
    return {
      labels,
      datasets: [
        {
          data,
          backgroundColor: backgroundColors.slice(0, labels.length),
          borderWidth: 0
        }
      ]
    };
  }, [stats]);
  
  const priceChangesChartData = useMemo(() => {
    if (!stats || !stats.priceChanges || stats.priceChanges.length === 0) {
      return {
        labels: ['Нет данных'],
        datasets: [{
          label: 'Изменение цены (₽)',
          data: [0],
          backgroundColor: ['#ccc'],
          borderColor: ['#ccc'],
          borderWidth: 1
        }]
      };
    }
    
    return {
      labels: stats.priceChanges.map(item => item.name.substring(0, 15) + '...'),
      datasets: [
        {
          label: 'Изменение цены (₽)',
          data: stats.priceChanges.map(item => item.change),
          backgroundColor: stats.priceChanges.map(item => 
            item.change < 0 ? 'rgba(75, 192, 192, 0.8)' : 'rgba(255, 99, 132, 0.8)'
          ),
          borderColor: stats.priceChanges.map(item => 
            item.change < 0 ? 'rgb(75, 192, 192)' : 'rgb(255, 99, 132)'
          ),
          borderWidth: 1
        }
      ]
    };
  }, [stats]);
  
  const priceTrendChartData = useMemo(() => {
    if (!stats || !stats.allPricePoints || stats.allPricePoints.length === 0) {
      return {
        labels: ['Нет данных'],
        datasets: [{
          label: 'Средняя цена',
          data: [0],
          borderColor: 'rgb(53, 162, 235)',
          backgroundColor: 'rgba(53, 162, 235, 0.5)',
          borderWidth: 1
        }]
      };
    }
    
    try {
      // Group price points by date for average price calculation
      const dateGroups: Record<string, number[]> = {};
      stats.allPricePoints.forEach(point => {
        if (!dateGroups[point.date]) {
          dateGroups[point.date] = [];
        }
        dateGroups[point.date].push(point.price);
      });
      
      // Calculate average prices for each date
      const sortedDates = Object.keys(dateGroups).sort((a, b) => 
        new Date(a).getTime() - new Date(b).getTime()
      );
      
      const avgPrices = sortedDates.map(date => {
        const prices = dateGroups[date];
        return prices.reduce((sum, price) => sum + price, 0) / prices.length;
      });
      
      return {
        labels: sortedDates,
        datasets: [
          {
            label: 'Средняя цена',
            data: avgPrices,
            borderColor: 'rgb(53, 162, 235)',
            backgroundColor: 'rgba(53, 162, 235, 0.5)',
            tension: 0.3,
            fill: true
          }
        ]
      };
    } catch (error) {
      console.error("Error creating price trend chart:", error);
      return {
        labels: ['Ошибка данных'],
        datasets: [{
          label: 'Средняя цена',
          data: [0],
          borderColor: 'rgb(53, 162, 235)',
          backgroundColor: 'rgba(53, 162, 235, 0.5)',
          borderWidth: 1
        }]
      };
    }
  }, [stats]);
  
  if (isLoading) {
    return (
      <Container>
        <LoadingContainer>
          <Spinner animate={{ rotate: 360 }} transition={{ duration: 1, repeat: Infinity, ease: "linear" }} />
        </LoadingContainer>
      </Container>
    );
  }
  
  if (error) {
    return (
      <Container>
        <PageHeader>
          <AnalyticsTitle>Аналитика</AnalyticsTitle>
        </PageHeader>
        <ErrorState>
          <h3>Ошибка при загрузке аналитики</h3>
          <p>{error instanceof Error ? error.message : 'Неизвестная ошибка'}</p>
          <button onClick={() => refetch()}>Попробовать снова</button>
        </ErrorState>
      </Container>
    );
  }
  
  if (!products || products.length === 0) {
    return (
      <Container>
        <PageHeader>
          <AnalyticsTitle>Аналитика</AnalyticsTitle>
          <Text>Добавьте товары для отслеживания, чтобы увидеть аналитические данные</Text>
        </PageHeader>
        <Card>
          <NoData>Нет данных для отображения</NoData>
        </Card>
      </Container>
    );
  }

  if (!stats) {
    return (
      <Container>
        <PageHeader>
          <AnalyticsTitle>Аналитика</AnalyticsTitle>
        </PageHeader>
        <Card>
          <NoData>Не удалось обработать данные для аналитики</NoData>
        </Card>
      </Container>
    );
  }

  return (
    <Container>
      <PageHeader>
        <AnalyticsTitle>Аналитика цен</AnalyticsTitle>
        <Text>
          Отслеживайте динамику цен на ваши товары, анализируйте тренды 
          и выявляйте лучшие предложения для покупки.
        </Text>
      </PageHeader>
      
      <ErrorBoundary FallbackComponent={ErrorFallback} onReset={() => refetch()}>
        <Card>
          <Subtitle>Ключевые показатели</Subtitle>
          <StatGrid>
            <StatCard>
              <StatValue>{stats.totalItems || 0}</StatValue>
              <StatLabel>Товаров в отслеживании</StatLabel>
            </StatCard>
            <StatCard>
              <StatValue>{stats.totalPriceDecreases || 0}</StatValue>
              <StatLabel>Товаров со снижением цены</StatLabel>
            </StatCard>
            <StatCard>
              <StatValue>{stats.totalPriceIncreases || 0}</StatValue>
              <StatLabel>Товаров с ростом цены</StatLabel>
            </StatCard>
            <StatCard>
              <StatValue>{stats.avgSaving || 0}₽</StatValue>
              <StatLabel>Средняя экономия</StatLabel>
            </StatCard>
          </StatGrid>
        </Card>
        
        <Grid>
          <Card>
            <Subtitle>Распределение по магазинам</Subtitle>
            <div style={{ height: '300px', position: 'relative' }}>
              <Pie data={marketplaceChartData} options={{ responsive: true, maintainAspectRatio: false }} />
            </div>
          </Card>
          
          <Card>
            <Subtitle>Динамика изменения цен</Subtitle>
            <div style={{ height: '300px', position: 'relative' }}>
              <Bar data={priceChangesChartData} options={{
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                  y: {
                    beginAtZero: true,
                    grid: { display: false }
                  },
                  x: {
                    grid: { display: false }
                  }
                }
              }} />
            </div>
          </Card>
        </Grid>
        
        <Card>
          <Subtitle>Тренд средних цен</Subtitle>
          <div style={{ height: '300px', position: 'relative' }}>
            <Line data={priceTrendChartData} options={{
              responsive: true,
              maintainAspectRatio: false,
              scales: {
                y: {
                  grid: { color: 'rgba(200, 200, 200, 0.2)' }
                },
                x: {
                  grid: { display: false }
                }
              }
            }} />
          </div>
        </Card>
      </ErrorBoundary>
    </Container>
  );
};

export default Analytics; 