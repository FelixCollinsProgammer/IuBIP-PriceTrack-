import React from 'react';
import styled from 'styled-components';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';

// Контейнер для всей страницы
const Container = styled.div`
  max-width: 1400px;
  margin: 0 auto;
  padding: 0 2rem;
`;

// Секция Hero
const HeroSection = styled.section`
  display: flex;
  flex-direction: column;
  align-items: center;
  text-align: center;
  padding: 6rem 0 4rem;
  
  @media (min-width: 768px) {
    padding: 8rem 0 6rem;
  }
`;

const HeroTitle = styled.h1`
  font-size: 2.5rem;
  font-weight: 800;
  margin-bottom: 1.5rem;
  color: ${({ theme }) => theme.colors.text};
  max-width: 800px;
  line-height: 1.2;
  letter-spacing: -0.5px;
  
  span {
    background: linear-gradient(90deg, ${({ theme }) => theme.colors.primary}, ${({ theme }) => theme.colors.secondary});
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
  }
  
  @media (min-width: 768px) {
    font-size: 3.5rem;
  }
`;

const HeroSubtitle = styled.p`
  font-size: 1.25rem;
  color: ${({ theme }) => theme.colors.textSecondary};
  max-width: 700px;
  margin: 0 auto 2.5rem;
  line-height: 1.6;
  
  @media (min-width: 768px) {
    font-size: 1.5rem;
  }
`;

const ButtonGroup = styled.div`
  display: flex;
  flex-wrap: wrap;
  gap: 1rem;
  justify-content: center;
  margin-bottom: 4rem;
`;

const PrimaryButton = styled(motion(Link))`
  display: inline-flex;
  align-items: center;
  padding: 0.875rem 1.75rem;
  background: linear-gradient(90deg, ${({ theme }) => theme.colors.primary}, ${({ theme }) => theme.colors.secondary});
  color: white;
  text-decoration: none;
  font-weight: 600;
  border-radius: 8px;
  box-shadow: 0 4px 14px rgba(0, 118, 255, 0.39);
  transition: transform 0.2s, box-shadow 0.2s;
  
  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(0, 118, 255, 0.39);
  }
  
  svg {
    margin-left: 8px;
  }
`;

const SecondaryButton = styled(motion(Link))`
  display: inline-flex;
  align-items: center;
  padding: 0.875rem 1.75rem;
  background: transparent;
  color: ${({ theme }) => theme.colors.primary};
  text-decoration: none;
  font-weight: 600;
  border-radius: 8px;
  border: 2px solid ${({ theme }) => theme.colors.primary};
  transition: background 0.2s, transform 0.2s;
  
  &:hover {
    background: ${({ theme }) => theme.colors.backgroundHover};
    transform: translateY(-2px);
  }
  
  svg {
    margin-left: 8px;
  }
`;

// Отображение браузера с демонстрацией
const BrowserWindow = styled(motion.div)`
  width: 100%;
  max-width: 900px;
  margin: 0 auto;
  background: ${({ theme }) => theme.colors.cardBackground};
  border-radius: 8px;
  box-shadow: 0 12px 40px rgba(0, 0, 0, 0.12);
  overflow: hidden;
`;

const BrowserHeader = styled.div`
  background: ${({ theme }) => theme.colors.backgroundSecondary};
  padding: 0.75rem 1rem;
  display: flex;
  align-items: center;
  border-bottom: 1px solid ${({ theme }) => theme.colors.border};
`;

const BrowserDots = styled.div`
  display: flex;
  gap: 6px;
`;

const Dot = styled.div<{ color: string }>`
  width: 10px;
  height: 10px;
  border-radius: 50%;
  background-color: ${({ color }) => color};
`;

const BrowserAddressBar = styled.div`
  background: ${({ theme }) => theme.colors.backgroundHover};
  border-radius: 4px;
  padding: 0.4rem 1rem;
  color: ${({ theme }) => theme.colors.textSecondary};
  font-size: 0.8rem;
  margin-left: 1rem;
  flex: 1;
  text-align: left;
  display: flex;
  align-items: center;
  
  svg {
    margin-right: 0.5rem;
    color: ${({ theme }) => theme.colors.textTertiary};
  }
`;

const BrowserContent = styled.div`
  padding: 1rem;
  
  img {
    width: 100%;
    border-radius: 4px;
    display: block;
  }
`;

// Секция возможностей
const FeaturesSection = styled.section`
  padding: 6rem 0;
  text-align: center;
`;

const SectionTitle = styled.h2`
  font-size: 2.2rem;
  font-weight: 700;
  margin-bottom: 1rem;
  color: ${({ theme }) => theme.colors.text};
  position: relative;
  display: inline-block;
  
  &::after {
    content: '';
    position: absolute;
    left: 50%;
    bottom: -10px;
    transform: translateX(-50%);
    width: 60px;
    height: 4px;
    background: linear-gradient(90deg, ${({ theme }) => theme.colors.primary}, ${({ theme }) => theme.colors.secondary});
    border-radius: 2px;
  }
`;

const SectionSubtitle = styled.p`
  font-size: 1.1rem;
  color: ${({ theme }) => theme.colors.textSecondary};
  max-width: 700px;
  margin: 2rem auto 4rem;
`;

const FeaturesGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
  gap: 2rem;
  margin-top: 3rem;
`;

const FeatureCard = styled.div`
  background: ${({ theme }) => theme.colors.cardBackground};
  border-radius: 12px;
  padding: 2rem;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
  transition: transform 0.3s, box-shadow 0.3s;
  
  &:hover {
    transform: translateY(-8px);
    box-shadow: 0 12px 30px rgba(0, 0, 0, 0.12);
  }
`;

const FeatureIcon = styled.div`
  margin-bottom: 1.5rem;
  font-size: 2.5rem;
`;

const FeatureTitle = styled.h3`
  font-size: 1.3rem;
  margin-bottom: 1rem;
  color: ${({ theme }) => theme.colors.text};
  font-weight: 600;
`;

const FeatureDescription = styled.p`
  color: ${({ theme }) => theme.colors.textSecondary};
  line-height: 1.6;
`;

// Секция интеграции
const IntegrationsSection = styled.section`
  padding: 5rem 0;
  background: ${({ theme }) => theme.colors.backgroundSecondary};
  text-align: center;
`;

const LogosGrid = styled.div`
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
  align-items: center;
  gap: 2rem;
  margin-top: 3rem;
`;

const LogoItem = styled.div`
  padding: 1rem 2rem;
  background: ${({ theme }) => theme.colors.cardBackground};
  border-radius: 8px;
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
  
  img {
    height: 40px;
    max-width: 120px;
    object-fit: contain;
  }
`;

// Секция CTA
const CTASection = styled.section`
  padding: 6rem 0;
  text-align: center;
  background: linear-gradient(135deg, ${({ theme }) => `${theme.colors.primary}10`}, ${({ theme }) => `${theme.colors.secondary}10`});
`;

const Home: React.FC = () => {
  return (
    <>
      <Container>
        <HeroSection>
          <HeroTitle>
            Отслеживайте цены и <span>экономьте деньги</span> с помощью PriceTrack
          </HeroTitle>
          <HeroSubtitle>
            Сервис автоматического мониторинга цен на товары из популярных интернет-магазинов. 
            Получайте уведомления о снижении цен и экономьте на покупках.
          </HeroSubtitle>
          
          <ButtonGroup>
            <PrimaryButton 
              to="/products"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              Начать отслеживание
              <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M8 0L6.59 1.41L12.17 7H0V9H12.17L6.59 14.59L8 16L16 8L8 0Z" fill="currentColor"/>
              </svg>
            </PrimaryButton>
            
            <SecondaryButton 
              to="/contact"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              Узнать больше
            </SecondaryButton>
          </ButtonGroup>
          
          <BrowserWindow
            initial={{ y: 30, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.2, duration: 0.5 }}
          >
            <BrowserHeader>
              <BrowserDots>
                <Dot color="#ff5f57" />
                <Dot color="#febc2e" />
                <Dot color="#28c840" />
              </BrowserDots>
              <BrowserAddressBar>
                <svg width="16" height="16" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path fillRule="evenodd" clipRule="evenodd" d="M8 0C3.58 0 0 3.58 0 8C0 12.42 3.58 16 8 16C12.42 16 16 12.42 16 8C16 3.58 12.42 0 8 0ZM7.5 2.5C7.5 2.22 7.72 2 8 2C8.28 2 8.5 2.22 8.5 2.5V3.5C8.5 3.78 8.28 4 8 4C7.72 4 7.5 3.78 7.5 3.5V2.5ZM2 8C2 7.72 2.22 7.5 2.5 7.5H3.5C3.78 7.5 4 7.72 4 8C4 8.28 3.78 8.5 3.5 8.5H2.5C2.22 8.5 2 8.28 2 8ZM12 8C12 7.72 12.22 7.5 12.5 7.5H13.5C13.78 7.5 14 7.72 14 8C14 8.28 13.78 8.5 13.5 8.5H12.5C12.22 8.5 12 8.28 12 8ZM7.5 12.5C7.5 12.22 7.72 12 8 12C8.28 12 8.5 12.22 8.5 12.5V13.5C8.5 13.78 8.28 14 8 14C7.72 14 7.5 13.78 7.5 13.5V12.5Z" fill="currentColor"/>
                </svg>
                pricetrack.com/products
              </BrowserAddressBar>
            </BrowserHeader>
            <BrowserContent>
              <img src="https://via.placeholder.com/860x480?text=PriceTrack+Dashboard" alt="PriceTrack Dashboard" />
            </BrowserContent>
          </BrowserWindow>
        </HeroSection>
      </Container>
      
      <FeaturesSection>
        <Container>
          <SectionTitle>Возможности сервиса</SectionTitle>
          <SectionSubtitle>
            PriceTrack предлагает множество инструментов для отслеживания цен и анализа их изменений
          </SectionSubtitle>
          
          <FeaturesGrid>
            <FeatureCard>
              <FeatureIcon>📊</FeatureIcon>
              <FeatureTitle>Отслеживание цен</FeatureTitle>
              <FeatureDescription>
                Автоматически отслеживайте цены на товары из популярных интернет-магазинов.
              </FeatureDescription>
            </FeatureCard>
            
            <FeatureCard>
              <FeatureIcon>🔔</FeatureIcon>
              <FeatureTitle>Уведомления</FeatureTitle>
              <FeatureDescription>
                Получайте мгновенные уведомления при снижении цены до заданного уровня.
              </FeatureDescription>
            </FeatureCard>
            
            <FeatureCard>
              <FeatureIcon>📈</FeatureIcon>
              <FeatureTitle>История цен</FeatureTitle>
              <FeatureDescription>
                Анализируйте изменения цен с помощью интерактивных графиков и таблиц.
              </FeatureDescription>
            </FeatureCard>
            
            <FeatureCard>
              <FeatureIcon>🛒</FeatureIcon>
              <FeatureTitle>Поддержка магазинов</FeatureTitle>
              <FeatureDescription>
                Работает с Wildberries, Ozon, AliExpress и другими популярными магазинами.
              </FeatureDescription>
            </FeatureCard>
            
            <FeatureCard>
              <FeatureIcon>📱</FeatureIcon>
              <FeatureTitle>Мобильный доступ</FeatureTitle>
              <FeatureDescription>
                Используйте сервис с любого устройства благодаря адаптивному дизайну.
              </FeatureDescription>
            </FeatureCard>
            
            <FeatureCard>
              <FeatureIcon>🔍</FeatureIcon>
              <FeatureTitle>Аналитика</FeatureTitle>
              <FeatureDescription>
                Получайте статистику и рекомендации о лучшем времени для покупки.
              </FeatureDescription>
            </FeatureCard>
          </FeaturesGrid>
        </Container>
      </FeaturesSection>
      
      <IntegrationsSection>
        <Container>
          <SectionTitle>Поддерживаемые магазины</SectionTitle>
          <SectionSubtitle>
            PriceTrack работает с крупнейшими интернет-магазинами России и мира
          </SectionSubtitle>
          
          <LogosGrid>
            <LogoItem>
              <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/8/88/Wildberries_logo.svg/320px-Wildberries_logo.svg.png" alt="Wildberries" />
            </LogoItem>
            <LogoItem>
              <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/8/82/Logo_of_Ozon.ru_%28old%29.svg/320px-Logo_of_Ozon.ru_%28old%29.svg.png" alt="Ozon" />
            </LogoItem>
            <LogoItem>
              <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/e/e1/AliExpress_logo.svg/320px-AliExpress_logo.svg.png" alt="AliExpress" />
            </LogoItem>
            <LogoItem>
              <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/0/0f/Avito_logo.svg/320px-Avito_logo.svg.png" alt="Avito" />
            </LogoItem>
            <LogoItem>
              <img src="https://avatars.mds.yandex.net/get-altay/10514637/2a00000189bfc8ba88b8c9b7d67141d0dad7/orig" alt="Яндекс.Маркет" />
            </LogoItem>
          </LogosGrid>
        </Container>
      </IntegrationsSection>
      
      <CTASection>
        <Container>
          <SectionTitle>Начните экономить уже сейчас</SectionTitle>
          <SectionSubtitle>
            Регистрация занимает менее минуты, и вы сразу можете начать отслеживать цены
          </SectionSubtitle>
          
          <PrimaryButton 
            to="/products"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            Попробовать бесплатно
          </PrimaryButton>
        </Container>
      </CTASection>
    </>
  );
};

export default Home; 