import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import styled from 'styled-components';
import { motion } from 'framer-motion';
import { toast } from 'react-toastify';
import { useAuth } from '../../contexts/AuthContext';

const Container = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: calc(100vh - 64px);
  padding: 2rem;
  background: ${({ theme }) => theme.colors?.background || '#f9fafb'};
`;

const RegisterCard = styled(motion.div)`
  width: 100%;
  max-width: 450px;
  background: ${({ theme }) => theme.colors?.cardBackground || '#fff'};
  border-radius: ${({ theme }) => theme.borderRadius?.medium || '8px'};
  box-shadow: ${({ theme }) => theme.shadows?.md || '0 4px 6px rgba(0, 0, 0, 0.1)'};
  padding: 2.5rem;
  
  @media (max-width: 480px) {
    padding: 1.5rem;
  }
`;

const Logo = styled.div`
  font-size: 2rem;
  font-weight: 700;
  text-align: center;
  margin-bottom: 2rem;
  color: ${({ theme }) => theme.colors?.primary || '#0066cc'};
`;

const Title = styled.h1`
  font-size: 1.75rem;
  font-weight: 700;
  margin-bottom: 1.5rem;
  text-align: center;
  color: ${({ theme }) => theme.colors?.text || '#1f2937'};
`;

const Form = styled.form`
  display: flex;
  flex-direction: column;
  gap: 1.25rem;
`;

const FormGroup = styled.div`
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
`;

const Label = styled.label`
  font-size: 0.875rem;
  font-weight: 500;
  color: ${({ theme }) => theme.colors?.text || '#1f2937'};
`;

const Input = styled.input`
  padding: 0.75rem;
  background-color: ${({ theme }) => theme.colors?.surface || '#fff'};
  border: 1px solid ${({ theme }) => theme.colors?.border || '#e5e7eb'};
  border-radius: ${({ theme }) => theme.borderRadius?.small || '4px'};
  font-size: 1rem;
  color: ${({ theme }) => theme.colors?.text || '#1f2937'};
  
  &:focus {
    outline: none;
    border-color: ${({ theme }) => theme.colors?.primary || '#0066cc'};
    box-shadow: 0 0 0 2px ${({ theme }) => theme.colors?.primary + '20' || '#0066cc20'};
  }
`;

const PasswordContainer = styled.div`
  position: relative;
`;

const PasswordToggle = styled.button`
  position: absolute;
  right: 0.75rem;
  top: 50%;
  transform: translateY(-50%);
  background: none;
  border: none;
  color: ${({ theme }) => theme.colors?.textLight || '#6b7280'};
  cursor: pointer;
  padding: 0.25rem;
  
  &:hover {
    color: ${({ theme }) => theme.colors?.text || '#1f2937'};
  }
`;

const SubmitButton = styled.button`
  padding: 0.75rem;
  background-color: ${({ theme }) => theme.colors?.primary || '#0066cc'};
  color: white;
  border: none;
  border-radius: ${({ theme }) => theme.borderRadius?.small || '4px'};
  font-weight: 600;
  font-size: 1rem;
  cursor: pointer;
  transition: background-color ${({ theme }) => theme.transitions?.default || '0.3s ease-in-out'};
  margin-top: 0.5rem;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 0.5rem;
  
  &:hover {
    background-color: ${({ theme }) => theme.colors?.accent || '#0052a3'};
  }
  
  &:disabled {
    background-color: ${({ theme }) => theme.colors?.textLight || '#9ca3af'};
    cursor: not-allowed;
  }
`;

const LinkContainer = styled.div`
  margin-top: 1.5rem;
  text-align: center;
  font-size: 0.875rem;
  color: ${({ theme }) => theme.colors?.textLight || '#6b7280'};
`;

const StyledLink = styled(Link)`
  color: ${({ theme }) => theme.colors?.primary || '#0066cc'};
  text-decoration: none;
  font-weight: 500;
  
  &:hover {
    text-decoration: underline;
  }
`;

const ErrorMessage = styled.span`
  color: ${({ theme }) => theme.colors?.error || '#ef4444'};
  font-size: 0.875rem;
`;

const Checkbox = styled.input`
  margin-right: 0.5rem;
`;

const TermsContainer = styled.div`
  display: flex;
  align-items: flex-start;
  margin-top: 1rem;
`;

const TermsText = styled.label`
  font-size: 0.875rem;
  color: ${({ theme }) => theme.colors?.textLight || '#6b7280'};
  line-height: 1.4;
`;

const Spinner = styled.div`
  width: 1.25rem;
  height: 1.25rem;
  border: 2px solid rgba(255, 255, 255, 0.3);
  border-radius: 50%;
  border-top-color: white;
  animation: spin 1s linear infinite;
  
  @keyframes spin {
    to {
      transform: rotate(360deg);
    }
  }
`;

interface FormData {
  name: string;
  email: string;
  password: string;
  confirmPassword: string;
  agreeToTerms: boolean;
}

interface FormErrors {
  name?: string;
  email?: string;
  password?: string;
  confirmPassword?: string;
  agreeToTerms?: string;
}

const Register: React.FC = () => {
  const [formData, setFormData] = useState<FormData>({
    name: '',
    email: '',
    password: '',
    confirmPassword: '',
    agreeToTerms: false
  });
  
  const [errors, setErrors] = useState<FormErrors>({});
  const [showPassword, setShowPassword] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  const { register } = useAuth();
  const navigate = useNavigate();
  
  const validateForm = (): boolean => {
    const newErrors: FormErrors = {};
    
    if (!formData.name.trim()) {
      newErrors.name = 'Имя обязательно';
    }
    
    if (!formData.email.trim()) {
      newErrors.email = 'Email обязателен';
    } else if (!/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i.test(formData.email)) {
      newErrors.email = 'Неверный формат email';
    }
    
    if (!formData.password) {
      newErrors.password = 'Пароль обязателен';
    } else if (formData.password.length < 6) {
      newErrors.password = 'Пароль должен содержать не менее 6 символов';
    }
    
    if (formData.password !== formData.confirmPassword) {
      newErrors.confirmPassword = 'Пароли не совпадают';
    }
    
    if (!formData.agreeToTerms) {
      newErrors.agreeToTerms = 'Вы должны согласиться с условиями';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
    
    // Clear error for this field when user types
    if (errors[name as keyof FormErrors]) {
      setErrors(prev => ({ ...prev, [name]: undefined }));
    }
  };
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }
    
    setIsSubmitting(true);
    
    try {
      const success = await register(formData.name, formData.email, formData.password);
      
      if (success) {
        toast.success('Регистрация успешна! Добро пожаловать!');
        navigate('/');
      } else {
        toast.error('Ошибка при регистрации. Возможно, этот email уже используется.');
      }
    } catch (error) {
      toast.error('Произошла ошибка при регистрации. Пожалуйста, попробуйте позже.');
      console.error('Registration error:', error);
    } finally {
      setIsSubmitting(false);
    }
  };
  
  return (
    <Container>
      <RegisterCard
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
      >
        <Logo>PriceTrack</Logo>
        <Title>Регистрация</Title>
        
        <Form onSubmit={handleSubmit}>
          <FormGroup>
            <Label htmlFor="name">Имя</Label>
            <Input
              type="text"
              id="name"
              name="name"
              placeholder="Введите ваше имя"
              value={formData.name}
              onChange={handleChange}
            />
            {errors.name && <ErrorMessage>{errors.name}</ErrorMessage>}
          </FormGroup>
          
          <FormGroup>
            <Label htmlFor="email">Email</Label>
            <Input
              type="email"
              id="email"
              name="email"
              placeholder="Введите ваш email"
              value={formData.email}
              onChange={handleChange}
            />
            {errors.email && <ErrorMessage>{errors.email}</ErrorMessage>}
          </FormGroup>
          
          <FormGroup>
            <Label htmlFor="password">Пароль</Label>
            <PasswordContainer>
              <Input
                type={showPassword ? 'text' : 'password'}
                id="password"
                name="password"
                placeholder="Создайте пароль"
                value={formData.password}
                onChange={handleChange}
              />
              <PasswordToggle
                type="button"
                onClick={() => setShowPassword(!showPassword)}
              >
                {showPassword ? '👁️' : '👁️‍🗨️'}
              </PasswordToggle>
            </PasswordContainer>
            {errors.password && <ErrorMessage>{errors.password}</ErrorMessage>}
          </FormGroup>
          
          <FormGroup>
            <Label htmlFor="confirmPassword">Подтверждение пароля</Label>
            <Input
              type={showPassword ? 'text' : 'password'}
              id="confirmPassword"
              name="confirmPassword"
              placeholder="Подтвердите пароль"
              value={formData.confirmPassword}
              onChange={handleChange}
            />
            {errors.confirmPassword && <ErrorMessage>{errors.confirmPassword}</ErrorMessage>}
          </FormGroup>
          
          <TermsContainer>
            <Checkbox
              type="checkbox"
              id="agreeToTerms"
              name="agreeToTerms"
              checked={formData.agreeToTerms}
              onChange={handleChange}
            />
            <TermsText htmlFor="agreeToTerms">
              Я согласен с <StyledLink to="#">условиями использования</StyledLink> и <StyledLink to="#">политикой конфиденциальности</StyledLink>
            </TermsText>
          </TermsContainer>
          {errors.agreeToTerms && <ErrorMessage>{errors.agreeToTerms}</ErrorMessage>}
          
          <SubmitButton type="submit" disabled={isSubmitting}>
            {isSubmitting ? <Spinner /> : null}
            {isSubmitting ? 'Регистрация...' : 'Зарегистрироваться'}
          </SubmitButton>
        </Form>
        
        <LinkContainer>
          Уже есть аккаунт?{' '}
          <StyledLink to="/login">Войти</StyledLink>
        </LinkContainer>
      </RegisterCard>
    </Container>
  );
};

export default Register; 