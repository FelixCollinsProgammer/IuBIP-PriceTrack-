import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useMutation } from '@tanstack/react-query';
import axios from 'axios';
import { motion } from 'framer-motion';

const AddProduct = () => {
  const [url, setUrl] = useState('');
  const navigate = useNavigate();

  const { mutate: addProduct, isPending } = useMutation({
    mutationFn: async (productUrl: string) => {
      const response = await axios.post('/api/products', { url: productUrl });
      return response.data;
    },
    onSuccess: (data) => {
      navigate(`/products/${data.id}`);
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (url.trim()) {
      addProduct(url.trim());
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="max-w-2xl mx-auto"
    >
      <div className="card">
        <h1 className="text-2xl font-bold mb-6">Добавить товар</h1>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label htmlFor="url" className="block text-sm font-medium text-gray-700 mb-1">
              URL товара
            </label>
            <input
              type="url"
              id="url"
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              placeholder="https://www.ozon.ru/product/..."
              className="input"
              required
            />
            <p className="mt-1 text-sm text-gray-500">
              Поддерживаемые площадки: Ozon, Wildberries, AliExpress, Avito
            </p>
          </div>
          
          <motion.button
            type="submit"
            className="btn btn-primary w-full"
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            disabled={isPending}
          >
            {isPending ? 'Добавление...' : 'Добавить товар'}
          </motion.button>
        </form>
      </div>
    </motion.div>
  );
};

export default AddProduct;