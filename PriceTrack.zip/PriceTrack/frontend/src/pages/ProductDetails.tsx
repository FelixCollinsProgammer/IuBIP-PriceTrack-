import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import axios from 'axios';
import styled from 'styled-components';
import { motion } from 'framer-motion';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';
import { Line } from 'react-chartjs-2';
import { ProductService } from '../services/ProductService';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
);

const Container = styled.div`
  max-width: 1200px;
  margin: 0 auto;
  padding: 2rem;
`;

const PageHeader = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 2rem;
`;

const BackLink = styled(Link)`
  color: ${({ theme }) => theme.colors.primary};
  text-decoration: none;
  display: flex;
  align-items: center;
  gap: 0.5rem;
  
  &:hover {
    text-decoration: underline;
  }
`;

const Card = styled(motion.div)`
  background: ${({ theme }) => theme.colors.cardBackground};
  border-radius: ${({ theme }) => theme.borderRadius.medium};
  padding: 2rem;
  box-shadow: ${({ theme }) => theme.shadows.md};
  margin-bottom: 2rem;
  overflow: hidden;
`;

const ProductHeader = styled.div`
  display: flex;
  gap: 2rem;
  margin-bottom: 2rem;
  
  @media (max-width: 768px) {
    flex-direction: column;
  }
`;

const ImageContainer = styled.div`
  width: 250px;
  height: 250px;
  border-radius: ${({ theme }) => theme.borderRadius.medium};
  overflow: hidden;
  background: ${({ theme }) => theme.colors.backgroundAlt};
  display: flex;
  align-items: center;
  justify-content: center;
  
  @media (max-width: 768px) {
    width: 100%;
    height: 200px;
  }
`;

const ProductImage = styled.img`
  max-width: 100%;
  max-height: 100%;
  object-fit: contain;
`;

const ProductInfo = styled.div`
  flex: 1;
`;

const ProductTitle = styled.h1`
  color: ${({ theme }) => theme.colors.text};
  margin-bottom: 1rem;
  font-size: 1.8rem;
`;

const ProductDetail = styled.div`
  color: ${({ theme }) => theme.colors.textLight};
  margin-bottom: 0.5rem;
  display: flex;
  align-items: center;
  gap: 0.5rem;
`;

const ProductPrice = styled.div`
  font-size: 2rem;
  font-weight: bold;
  color: ${({ theme }) => theme.colors.primary};
  margin: 1rem 0;
`;

const ExternalLink = styled.a`
  color: ${({ theme }) => theme.colors.primary};
  text-decoration: none;
  display: inline-flex;
  align-items: center;
  gap: 0.5rem;
  margin-top: 1rem;
  
  &:hover {
    text-decoration: underline;
  }
`;

const UpdateButton = styled.button`
  background: ${({ theme }) => theme.colors.primary};
  color: white;
  border: none;
  padding: 0.5rem 1rem;
  border-radius: ${({ theme }) => theme.borderRadius.small};
  cursor: pointer;
  font-weight: 500;
  display: inline-flex;
  align-items: center;
  gap: 0.5rem;
  margin-top: 1rem;
  
  &:hover {
    background: ${({ theme }) => theme.colors.accent};
  }
  
  &:disabled {
    background: ${({ theme }) => theme.colors.textLight};
    cursor: not-allowed;
  }
`;

const ChartContainer = styled.div`
  width: 100%;
  margin-top: 2rem;
`;

const LoadingContainer = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  height: 300px;
`;

const Spinner = styled(motion.div)`
  width: 40px;
  height: 40px;
  border: 3px solid ${({ theme }) => theme.colors.background};
  border-top: 3px solid ${({ theme }) => theme.colors.primary};
  border-radius: 50%;
`;

const NoDataMessage = styled.div`
  text-align: center;
  padding: 3rem;
  color: ${({ theme }) => theme.colors.textLight};
`;

const ProductDetails: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const productId = id ? parseInt(id) : 0;

  // Fetch product details
  const { 
    data: product, 
    isLoading: isLoadingProduct 
  } = useQuery({
    queryKey: ['product', productId],
    queryFn: () => ProductService.getProduct(productId),
    enabled: !!productId,
  });

  // Fetch product prices
  const { 
    data: prices, 
    isLoading: isLoadingPrices,
    refetch: refetchPrices
  } = useQuery({
    queryKey: ['prices', productId],
    queryFn: () => ProductService.getPrices(productId),
    enabled: !!productId,
  });

  // Handle price update
  const handleUpdatePrice = async () => {
    try {
      await ProductService.updatePrice(productId);
      // Refetch prices after update
      refetchPrices();
    } catch (error) {
      console.error('Failed to update price:', error);
    }
  };

  // Extract domain from URL
  const getDomain = (url: string): string => {
    try {
      const urlObj = new URL(url);
      return urlObj.hostname.replace('www.', '');
    } catch (e) {
      return 'unknown';
    }
  };

  // Format date for display
  const formatDate = (dateString: string): string => {
    const date = new Date(dateString);
    return date.toLocaleDateString('ru-RU', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  };

  if (isLoadingProduct || isLoadingPrices) {
    return (
      <Container>
        <LoadingContainer>
          <Spinner 
            animate={{ rotate: 360 }} 
            transition={{ duration: 1, repeat: Infinity, ease: "linear" }} 
          />
        </LoadingContainer>
      </Container>
    );
  }

  if (!product) {
    return (
      <Container>
        <NoDataMessage>Товар не найден</NoDataMessage>
      </Container>
    );
  }

  const sortedPrices = [...(prices || [])].sort(
    (a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime()
  );

  const chartData = {
    labels: sortedPrices.map(price => new Date(price.createdAt).toLocaleDateString('ru-RU')),
    datasets: [
      {
        label: 'Цена (₽)',
        data: sortedPrices.map(price => price.price),
        borderColor: 'rgb(53, 162, 235)',
        backgroundColor: 'rgba(53, 162, 235, 0.5)',
        tension: 0.3,
      },
    ],
  };

  const chartOptions = {
    responsive: true,
    plugins: {
      legend: {
        position: 'top' as const,
      },
      title: {
        display: true,
        text: 'История изменения цены',
        font: {
          size: 16
        }
      },
      tooltip: {
        callbacks: {
          label: function(context: any) {
            return `Цена: ${context.parsed.y.toLocaleString('ru-RU')} ₽`;
          }
        }
      }
    },
    scales: {
      x: {
        title: {
          display: true,
          text: 'Дата'
        }
      },
      y: {
        beginAtZero: false,
        title: {
          display: true,
          text: 'Цена (₽)'
        },
        ticks: {
          callback: function(value: any) {
            return value.toLocaleString('ru-RU') + ' ₽';
          }
        }
      },
    },
  };

  return (
    <Container>
      <PageHeader>
        <BackLink to="/products">← Вернуться к списку товаров</BackLink>
      </PageHeader>
      
      <Card 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <ProductHeader>
          <ImageContainer>
            {product.imageUrl ? (
              <ProductImage
                src={product.imageUrl}
                alt={product.name}
                onError={(e: React.SyntheticEvent<HTMLImageElement>) => {
                  // Set fallback image on error
                  e.currentTarget.src = `https://placehold.co/400x400/png?text=${encodeURIComponent(product.name)}`;
                }}
              />
            ) : (
              <ProductImage
                src={`https://placehold.co/400x400/png?text=${encodeURIComponent(product.name)}`}
                alt={product.name}
              />
            )}
          </ImageContainer>
          
          <ProductInfo>
            <ProductTitle>{product.name}</ProductTitle>
            
            <ProductDetail>
              <span>Магазин:</span> {getDomain(product.url)}
            </ProductDetail>
            
            <ProductDetail>
              <span>Добавлен:</span> {product.createdAt ? formatDate(product.createdAt) : 'Неизвестно'}
            </ProductDetail>
            
            <ProductPrice>{product.currentPrice?.toLocaleString('ru-RU')} ₽</ProductPrice>
            
            <ExternalLink 
              href={product.url} 
              target="_blank" 
              rel="noopener noreferrer"
            >
              Открыть на сайте продавца
            </ExternalLink>
            
            <div>
              <UpdateButton onClick={handleUpdatePrice}>
                Обновить цену
              </UpdateButton>
            </div>
          </ProductInfo>
        </ProductHeader>
        
        <ChartContainer>
          {sortedPrices.length > 0 ? (
            <Line data={chartData} options={chartOptions} />
          ) : (
            <NoDataMessage>Нет данных о ценах</NoDataMessage>
          )}
        </ChartContainer>
      </Card>
    </Container>
  );
};

export default ProductDetails; 