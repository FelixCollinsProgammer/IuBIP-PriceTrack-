import React, { useState, useEffect } from 'react';
import styled from 'styled-components';
import { motion } from 'framer-motion';
import { toast } from 'react-toastify';

// Стилизованные компоненты
const Container = styled.div`
  max-width: 1200px;
  margin: 0 auto;
  padding: 2rem;
`;

const PageTitle = styled.h1`
  font-size: 2.5rem;
  margin-bottom: 2rem;
  color: ${({ theme }) => theme.colors.text};
  position: relative;
  
  &:after {
    content: '';
    position: absolute;
    bottom: -10px;
    left: 0;
    width: 100px;
    height: 4px;
    background: linear-gradient(90deg, ${({ theme }) => theme.colors.primary}, ${({ theme }) => theme.colors.secondary});
    border-radius: 2px;
  }
`;

const ProfileGrid = styled.div`
  display: grid;
  grid-template-columns: 300px 1fr;
  gap: 2rem;
  
  @media (max-width: 768px) {
    grid-template-columns: 1fr;
  }
`;

const Sidebar = styled.div`
  background: ${({ theme }) => theme.colors.cardBackground};
  border-radius: ${({ theme }) => theme.borderRadius.large};
  box-shadow: ${({ theme }) => theme.shadows.medium};
  padding: 1.5rem;
  height: fit-content;
`;

const ProfileAvatar = styled.div`
  width: 150px;
  height: 150px;
  border-radius: 50%;
  background: ${({ theme }) => theme.colors.backgroundAlt};
  margin: 0 auto 1.5rem;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 4rem;
  color: ${({ theme }) => theme.colors.textSecondary};
  position: relative;
  overflow: hidden;
`;

const AvatarImage = styled.img`
  width: 100%;
  height: 100%;
  object-fit: cover;
`;

const UploadButton = styled.label`
  position: absolute;
  bottom: 0;
  left: 0;
  right: 0;
  background: rgba(0, 0, 0, 0.5);
  color: white;
  text-align: center;
  padding: 0.5rem;
  cursor: pointer;
  font-size: 0.8rem;
`;

const HiddenInput = styled.input`
  display: none;
`;

const ProfileName = styled.h2`
  font-size: 1.5rem;
  text-align: center;
  margin-bottom: 1rem;
  color: ${({ theme }) => theme.colors.text};
`;

const ProfileEmail = styled.p`
  font-size: 1rem;
  text-align: center;
  color: ${({ theme }) => theme.colors.textSecondary};
  margin-bottom: 1.5rem;
`;

const NavItem = styled.button<{ active?: boolean }>`
  display: block;
  width: 100%;
  text-align: left;
  padding: 1rem;
  margin-bottom: 0.5rem;
  background: ${({ theme, active }) => active ? theme.colors.primary + '20' : 'transparent'};
  color: ${({ theme, active }) => active ? theme.colors.primary : theme.colors.text};
  border: none;
  border-radius: ${({ theme }) => theme.borderRadius.medium};
  cursor: pointer;
  transition: all ${({ theme }) => theme.transitions.default};
  font-weight: ${({ active }) => active ? '600' : '400'};
  display: flex;
  align-items: center;
  
  &:hover {
    background: ${({ theme }) => theme.colors.backgroundHover};
  }
  
  svg {
    margin-right: 0.75rem;
  }
`;

const ContentArea = styled.div`
  background: ${({ theme }) => theme.colors.cardBackground};
  border-radius: ${({ theme }) => theme.borderRadius.large};
  box-shadow: ${({ theme }) => theme.shadows.medium};
  padding: 2rem;
`;

const SectionTitle = styled.h3`
  font-size: 1.5rem;
  margin-bottom: 1.5rem;
  color: ${({ theme }) => theme.colors.text};
  border-bottom: 1px solid ${({ theme }) => theme.colors.border};
  padding-bottom: 0.75rem;
`;

const Form = styled.form`
  display: grid;
  gap: 1.5rem;
`;

const InputGroup = styled.div`
  display: flex;
  flex-direction: column;
`;

const Label = styled.label`
  font-size: 0.9rem;
  margin-bottom: 0.5rem;
  color: ${({ theme }) => theme.colors.textSecondary};
`;

const Input = styled.input`
  padding: 0.75rem 1rem;
  border: 1px solid ${({ theme }) => theme.colors.border};
  border-radius: ${({ theme }) => theme.borderRadius.medium};
  background: ${({ theme }) => theme.colors.inputBackground};
  color: ${({ theme }) => theme.colors.text};
  font-size: 1rem;
  
  &:focus {
    outline: none;
    border-color: ${({ theme }) => theme.colors.primary};
    box-shadow: 0 0 0 2px ${({ theme }) => theme.colors.primaryLight};
  }
`;

const Button = styled(motion.button)`
  background: linear-gradient(90deg, ${({ theme }) => theme.colors.primary}, ${({ theme }) => theme.colors.secondary});
  color: white;
  padding: 0.75rem 1.5rem;
  border: none;
  border-radius: ${({ theme }) => theme.borderRadius.medium};
  font-size: 1rem;
  font-weight: 600;
  cursor: pointer;
  justify-self: start;
  
  &:disabled {
    opacity: 0.6;
    cursor: not-allowed;
  }
`;

const StatsGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
  gap: 1rem;
  margin-bottom: 2rem;
`;

const StatCard = styled.div`
  background: ${({ theme }) => theme.colors.surface};
  border-radius: ${({ theme }) => theme.borderRadius.medium};
  padding: 1.5rem;
  text-align: center;
`;

const StatValue = styled.div`
  font-size: 2rem;
  font-weight: bold;
  color: ${({ theme }) => theme.colors.primary};
  margin-bottom: 0.5rem;
`;

const StatLabel = styled.div`
  font-size: 0.9rem;
  color: ${({ theme }) => theme.colors.textSecondary};
`;

const ActivityTitle = styled.h4`
  font-size: 1.2rem;
  margin-bottom: 1rem;
  color: ${({ theme }) => theme.colors.text};
`;

const ActivityList = styled.div`
  display: flex;
  flex-direction: column;
  gap: 1rem;
`;

const ActivityItem = styled.div`
  display: flex;
  align-items: center;
  padding: 1rem;
  background: ${({ theme }) => theme.colors.surface};
  border-radius: ${({ theme }) => theme.borderRadius.medium};
`;

const ActivityIcon = styled.div`
  width: 40px;
  height: 40px;
  border-radius: 50%;
  background: ${({ theme }) => theme.colors.primaryLight};
  color: ${({ theme }) => theme.colors.primary};
  display: flex;
  align-items: center;
  justify-content: center;
  margin-right: 1rem;
  font-size: 1.2rem;
`;

const ActivityContent = styled.div`
  flex: 1;
`;

const ActivityText = styled.div`
  color: ${({ theme }) => theme.colors.text};
  margin-bottom: 0.25rem;
`;

const ActivityDate = styled.div`
  font-size: 0.8rem;
  color: ${({ theme }) => theme.colors.textTertiary};
`;

// Основной компонент
const Profile: React.FC = () => {
  const [activeTab, setActiveTab] = useState<string>('profile');
  const [avatar, setAvatar] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  
  // Демо-данные для пользователя
  const [user, setUser] = useState({
    name: 'Иван Иванов',
    email: 'ivan@example.com',
    phone: '+7 (999) 123-45-67',
    location: 'Москва, Россия',
    bio: 'Исследователь цен и качества. Люблю отслеживать выгодные предложения и делиться находками.'
  });

  const handleAvatarChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const reader = new FileReader();
      reader.onload = (e) => {
        if (e.target?.result) {
          setAvatar(e.target.result as string);
        }
      };
      reader.readAsDataURL(e.target.files[0]);
    }
  };

  const handleProfileUpdate = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    // Имитация API-запроса
    setTimeout(() => {
      setIsLoading(false);
      toast.success('Профиль успешно обновлен!');
    }, 1500);
  };

  const renderTabContent = () => {
    switch (activeTab) {
      case 'profile':
        return (
          <>
            <SectionTitle>Личная информация</SectionTitle>
            <Form onSubmit={handleProfileUpdate}>
              <InputGroup>
                <Label>Полное имя</Label>
                <Input 
                  value={user.name} 
                  onChange={(e) => setUser({...user, name: e.target.value})}
                />
              </InputGroup>
              
              <InputGroup>
                <Label>Email</Label>
                <Input 
                  type="email" 
                  value={user.email}
                  onChange={(e) => setUser({...user, email: e.target.value})}
                />
              </InputGroup>
              
              <InputGroup>
                <Label>Телефон</Label>
                <Input 
                  type="tel" 
                  value={user.phone}
                  onChange={(e) => setUser({...user, phone: e.target.value})}
                />
              </InputGroup>
              
              <InputGroup>
                <Label>Местоположение</Label>
                <Input 
                  value={user.location}
                  onChange={(e) => setUser({...user, location: e.target.value})}
                />
              </InputGroup>
              
              <InputGroup>
                <Label>О себе</Label>
                <Input 
                  as="textarea" 
                  rows={4} 
                  value={user.bio}
                  onChange={(e) => setUser({...user, bio: e.target.value})}
                />
              </InputGroup>
              
              <Button 
                type="submit" 
                disabled={isLoading}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                {isLoading ? 'Сохранение...' : 'Сохранить изменения'}
              </Button>
            </Form>
          </>
        );
        
      case 'stats':
        return (
          <>
            <SectionTitle>Статистика</SectionTitle>
            <StatsGrid>
              <StatCard>
                <StatValue>5</StatValue>
                <StatLabel>Отслеживаемых товаров</StatLabel>
              </StatCard>
              <StatCard>
                <StatValue>8%</StatValue>
                <StatLabel>Средняя экономия</StatLabel>
              </StatCard>
              <StatCard>
                <StatValue>3</StatValue>
                <StatLabel>Уведомлений за месяц</StatLabel>
              </StatCard>
              <StatCard>
                <StatValue>2</StatValue>
                <StatLabel>Товаров со скидкой</StatLabel>
              </StatCard>
            </StatsGrid>
            
            <ActivityTitle>Недавняя активность</ActivityTitle>
            <ActivityList>
              <ActivityItem>
                <ActivityIcon>📦</ActivityIcon>
                <ActivityContent>
                  <ActivityText>Добавлен товар "Смартфон Samsung Galaxy A52"</ActivityText>
                  <ActivityDate>Сегодня, 11:23</ActivityDate>
                </ActivityContent>
              </ActivityItem>
              <ActivityItem>
                <ActivityIcon>📉</ActivityIcon>
                <ActivityContent>
                  <ActivityText>Цена на "Наушники Sony WH-1000XM4" снизилась на 8%</ActivityText>
                  <ActivityDate>Вчера, 15:40</ActivityDate>
                </ActivityContent>
              </ActivityItem>
              <ActivityItem>
                <ActivityIcon>🔔</ActivityIcon>
                <ActivityContent>
                  <ActivityText>Настроено уведомление о снижении цены для товара "Ноутбук ASUS VivoBook"</ActivityText>
                  <ActivityDate>3 дня назад, 09:12</ActivityDate>
                </ActivityContent>
              </ActivityItem>
              <ActivityItem>
                <ActivityIcon>✏️</ActivityIcon>
                <ActivityContent>
                  <ActivityText>Обновлена категория товара "Мышь Logitech MX Master 3"</ActivityText>
                  <ActivityDate>5 дней назад, 18:35</ActivityDate>
                </ActivityContent>
              </ActivityItem>
              <ActivityItem>
                <ActivityIcon>👁️</ActivityIcon>
                <ActivityContent>
                  <ActivityText>Просмотр аналитики цен за последний месяц</ActivityText>
                  <ActivityDate>Неделю назад, 12:50</ActivityDate>
                </ActivityContent>
              </ActivityItem>
            </ActivityList>
          </>
        );
        
      case 'security':
        return (
          <>
            <SectionTitle>Безопасность</SectionTitle>
            <Form>
              <InputGroup>
                <Label>Текущий пароль</Label>
                <Input type="password" />
              </InputGroup>
              
              <InputGroup>
                <Label>Новый пароль</Label>
                <Input type="password" />
              </InputGroup>
              
              <InputGroup>
                <Label>Подтверждение пароля</Label>
                <Input type="password" />
              </InputGroup>
              
              <Button 
                type="submit" 
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                Изменить пароль
              </Button>
            </Form>
          </>
        );
        
      default:
        return null;
    }
  };

  return (
    <Container>
      <PageTitle>Профиль пользователя</PageTitle>
      
      <ProfileGrid>
        <Sidebar>
          <ProfileAvatar>
            {avatar ? (
              <AvatarImage src={avatar} alt="Avatar" />
            ) : (
              '👤'
            )}
            <UploadButton>
              Изменить
              <HiddenInput 
                type="file" 
                accept="image/*" 
                onChange={handleAvatarChange} 
              />
            </UploadButton>
          </ProfileAvatar>
          
          <ProfileName>{user.name}</ProfileName>
          <ProfileEmail>{user.email}</ProfileEmail>
          
          <NavItem 
            active={activeTab === 'profile'} 
            onClick={() => setActiveTab('profile')}
          >
            <span>👤</span> Личная информация
          </NavItem>
          
          <NavItem 
            active={activeTab === 'stats'} 
            onClick={() => setActiveTab('stats')}
          >
            <span>📊</span> Статистика и активность
          </NavItem>
          
          <NavItem 
            active={activeTab === 'security'} 
            onClick={() => setActiveTab('security')}
          >
            <span>🔒</span> Безопасность
          </NavItem>
          
          <NavItem 
            active={activeTab === 'settings'} 
            onClick={() => setActiveTab('settings')}
          >
            <span>⚙️</span> Настройки
          </NavItem>
        </Sidebar>
        
        <ContentArea>
          {renderTabContent()}
        </ContentArea>
      </ProfileGrid>
    </Container>
  );
};

export default Profile; 