import React, { useState, useEffect, useCallback } from 'react';
import styled from 'styled-components';
import { motion, AnimatePresence } from 'framer-motion';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { toast } from 'react-toastify';
import { ProductService } from '../services/ProductService';
import MarketplaceLogo from '../components/MarketplaceLogo';
import { Link } from 'react-router-dom';
import { 
  Grid, 
  IconButton, 
  Tooltip, 
  Typography, 
  Button,
  Card,
  CardHeader,
  CardMedia,
  CardContent,
  CardActions,
  Chip,
  Stack,
  Box,
  TextField,
  MenuItem,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  FormControl,
  InputLabel,
  Select as MuiSelect,
  CircularProgress,
  Paper
} from '@mui/material';
import EditIcon from '@mui/icons-material/Edit';
import DeleteOutlineIcon from '@mui/icons-material/DeleteOutline';
import InfoOutlinedIcon from '@mui/icons-material/InfoOutlined';
import CloseIcon from '@mui/icons-material/Close';
import AddIcon from '@mui/icons-material/Add';
import ArrowDownwardIcon from '@mui/icons-material/ArrowDownward';
import ArrowUpwardIcon from '@mui/icons-material/ArrowUpward';
import AutorenewIcon from '@mui/icons-material/Autorenew';
import AccessTimeIcon from '@mui/icons-material/AccessTime';

// Стили с использованием темы
const ThemeStyles = `
  .hover-scale:hover {
    transform: scale(1.05);
  }
  .hover-scale:active {
    transform: scale(0.95);
  }
  
  .price-card {
    transition: all 0.3s ease;
    border-radius: 12px;
    overflow: hidden;
    height: 100%;
  }
  
  .price-card:hover {
    transform: translateY(-8px);
    box-shadow: 0 12px 24px rgba(0,0,0,0.12);
  }
  
  .price-up {
    color: #f44336;
  }
  
  .price-down {
    color: #00c853;
  }
  
  .price-badge {
    position: absolute;
    top: 16px;
    right: 16px;
    z-index: 10;
    padding: 4px 10px;
    border-radius: 20px;
    font-weight: 600;
    font-size: 13px;
    display: flex;
    align-items: center;
    gap: 4px;
    box-shadow: 0 3px 5px rgba(0,0,0,0.1);
  }
  
  .price-badge-up {
    background: linear-gradient(135deg, #ff9a9e 0%, #fad0c4 99%, #fad0c4 100%);
    color: #d32f2f;
  }
  
  .price-badge-down {
    background: linear-gradient(135deg, #a8edea 0%, #fed6e3 100%);
    color: #00796b;
  }
  
  .marketplace-label {
    font-size: 12px;
    font-weight: 500;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    color: #6c757d;
  }
`;

const Container = styled.div`
  padding: 20px;
  max-width: 1400px;
  margin: 0 auto;
`;

const Title = styled.h1`
  color: ${props => props.theme.colors.text};
  margin-bottom: 20px;
`;

const EmptyMessage = styled.div`
  text-align: center;
  padding: 30px;
  color: ${props => props.theme.colors.textSecondary};
  font-size: 16px;
  background: ${props => props.theme.colors.cardBackground};
  border-radius: ${props => props.theme.borderRadius.medium};
  box-shadow: ${props => props.theme.shadows.small};
`;

const Header = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 2rem;
  flex-wrap: wrap;
  gap: 1rem;
`;

const HeaderActions = styled.div`
  display: flex;
  gap: 1rem;
  
  @media (max-width: 768px) {
    width: 100%;
    justify-content: space-between;
  }
`;

const AddButton = styled(motion.button)`
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 0.5rem;
  padding: 0.75rem 1.5rem;
  background: linear-gradient(135deg, #6a11cb 0%, #2575fc 100%);
  color: white;
  font-weight: 600;
  border-radius: 12px;
  border: none;
  cursor: pointer;
  font-size: 1rem;
  box-shadow: 0 4px 10px rgba(37, 117, 252, 0.3);
  
  &:hover {
    box-shadow: 0 6px 15px rgba(37, 117, 252, 0.4);
  }
`;

const CategoryButton = styled(Link)`
  background: linear-gradient(135deg, #6a11cb 0%, #2575fc 100%);
  color: white;
  border: none;
  padding: 0.75rem 1.5rem;
  border-radius: 12px;
  font-weight: 600;
  cursor: pointer;
  box-shadow: 0 4px 15px rgba(0, 0, 0, 0.15);
  text-decoration: none;
  display: flex;
  align-items: center;
  gap: 0.5rem;
  transition: all 0.3s ease;
  
  &:hover {
    box-shadow: 0 6px 20px rgba(37, 117, 252, 0.4);
    transform: translateY(-2px);
  }
`;

const FilterSection = styled.div`
  margin-bottom: 2rem;
  background: #2d3748;
  padding: 1.5rem;
  border-radius: 16px;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2);
`;

const FilterTitle = styled.h3`
  margin-top: 0;
  margin-bottom: 1rem;
  font-size: 1.2rem;
  color: #ffffff;
  font-weight: 600;
`;

const CategoryFilterBar = styled.div`
  display: flex;
  gap: 0.75rem;
  flex-wrap: wrap;
`;

const CategoryFilterItem = styled.button<{ isActive: boolean }>`
  padding: 0.5rem 1rem;
  background: ${props => props.isActive ? 'linear-gradient(135deg, #6a11cb 0%, #2575fc 100%)' : '#3a4556'};
  color: ${props => props.isActive ? '#ffffff' : '#cbd5e0'};
  border: none;
  border-radius: 12px;
  cursor: pointer;
  font-size: 0.875rem;
  font-weight: 500;
  transition: all 0.2s ease;
  display: flex;
  align-items: center;
  gap: 0.5rem;
  box-shadow: ${props => props.isActive ? '0 4px 12px rgba(37, 117, 252, 0.3)' : 'none'};
  
  &:hover {
    background: ${props => props.isActive ? 'linear-gradient(135deg, #5a0cb6 0%, #1565e0 100%)' : '#4a5568'};
    transform: translateY(-2px);
  }
`;

const CategoryFilterCount = styled.span`
  background: rgba(255, 255, 255, 0.15);
  color: #ffffff;
  padding: 0.125rem 0.5rem;
  border-radius: 12px;
  font-size: 0.75rem;
  font-weight: 600;
`;

const MarketplaceFilterBar = styled.div`
  display: flex;
  gap: 0.75rem;
  flex-wrap: wrap;
`;

const ProductsGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
  gap: 2rem;
  
  @media (max-width: 768px) {
    grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
    gap: 1.5rem;
  }
`;

const NoProductsMessage = styled.div`
  text-align: center;
  background: #2d3748;
  border-radius: 16px;
  padding: 3rem;
  max-width: 800px;
  margin: 2rem auto;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2);
`;

const NoProductsTitle = styled.h2`
  color: #ffffff;
  font-size: 1.75rem;
  margin-bottom: 1rem;
`;

const NoProductsDescription = styled.p`
  color: #cbd5e0;
  font-size: 1.1rem;
  margin-bottom: 2rem;
`;

const LoadingSpinner = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 300px;
  
  .MuiCircularProgress-root {
    color: #6a11cb;
  }
`;

// Компонент карточки товара
const ProductCard = styled.div`
  background: #2d3748;
  border-radius: 16px;
  padding: 16px;
  box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
  transition: transform 0.2s ease, box-shadow 0.2s ease;
  display: flex;
  flex-direction: column;
  position: relative;
  color: #ffffff;
  overflow: hidden;
  
  &:hover {
    box-shadow: 0 8px 25px rgba(0, 0, 0, 0.3);
    transform: translateY(-5px);
  }
`;

const ProductHeader = styled.div`
  display: flex;
  align-items: center;
  margin-bottom: 12px;
`;

const ProductLogo = styled.div`
  width: 36px;
  height: 36px;
  border-radius: 8px;
  background-color: #fff;
  padding: 4px;
  margin-right: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
  
  img {
    max-width: 100%;
    max-height: 100%;
    object-fit: contain;
  }
`;

const ProductImage = styled.div`
  width: 100%;
  height: 180px;
  overflow: hidden;
  border-radius: 12px;
  margin-bottom: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
  background-color: #3a4556;
  position: relative;
  
  img {
    width: 80%;
    height: 80%;
    object-fit: contain;
    transition: transform 0.3s ease;
    
    &:hover {
      transform: scale(1.05);
    }
  }
`;

const ProductMarketplace = styled.div`
  position: absolute;
  top: 10px;
  right: 10px;
  background: rgba(33, 41, 54, 0.85);
  border-radius: 8px;
  padding: 6px 10px;
  display: flex;
  align-items: center;
  font-size: 12px;
  font-weight: 500;
  box-shadow: 0 2px 5px rgba(0, 0, 0, 0.2);
  color: #ffffff;
  z-index: 2;
`;

const ProductName = styled.h3`
  margin: 0 0 12px 0;
  font-size: 1rem;
  font-weight: 600;
  color: #ffffff;
  line-height: 1.4;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
  height: 44px;
`;

const ProductPrice = styled.div`
  margin: 0.5rem 0 1rem 0;
  display: flex;
  flex-direction: column;
  gap: 8px;
`;

const CurrentPrice = styled.div`
  font-size: 1.5rem;
  font-weight: 700;
  color: #ffffff;
  display: flex;
  align-items: center;
  justify-content: space-between;
`;

const PriceValue = styled.span`
  background: linear-gradient(135deg, #6a11cb 0%, #2575fc 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
  text-fill-color: transparent;
  font-size: 1.6rem;
`;

const UpdateButton = styled.button<{ disabled?: boolean }>`
  background: ${props => props.disabled ? '#A0AEC0' : '#3a4556'};
  border: none;
  border-radius: 8px;
  width: 32px;
  height: 32px;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: ${props => props.disabled ? 'default' : 'pointer'};
  transition: background 0.2s ease, transform 0.2s ease;
  
  &:hover {
    background: ${props => props.disabled ? '#A0AEC0' : '#4a5568'};
    transform: ${props => props.disabled ? 'none' : 'scale(1.05)'};
  }
  
  svg {
    color: #ffffff;
    font-size: 18px;
  }
`;

const CooldownTimer = styled.div`
  position: absolute;
  bottom: -22px;
  right: 0;
  font-size: 11px;
  color: #A0AEC0;
  display: flex;
  align-items: center;
  gap: 4px;
`;

const UpdateTooltip = styled.div`
  position: absolute;
  top: -40px;
  right: 0;
  background: rgba(42, 46, 56, 0.9);
  padding: 6px 10px;
  border-radius: 8px;
  font-size: 12px;
  color: white;
  z-index: 10;
  box-shadow: 0 2px 8px rgba(0,0,0,0.2);
  white-space: nowrap;
  
  &:after {
    content: '';
    position: absolute;
    bottom: -5px;
    right: 10px;
    width: 0;
    height: 0;
    border-left: 5px solid transparent;
    border-right: 5px solid transparent;
    border-top: 5px solid rgba(42, 46, 56, 0.9);
  }
`;

const PriceChange = styled.div<{ isPositive: boolean }>`
  font-size: 0.875rem;
  font-weight: 500;
  color: ${({ isPositive }) => (isPositive ? '#4ade80' : '#f87171')};
  background-color: ${({ isPositive }) => (isPositive ? 'rgba(74, 222, 128, 0.1)' : 'rgba(248, 113, 113, 0.1)')};
  padding: 6px 10px;
  border-radius: 8px;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 4px;
`;

const ProductCategory = styled.div`
  margin-top: auto;
  padding: 6px 12px;
  background-color: #3a4556;
  border-radius: 8px;
  font-size: 0.75rem;
  font-weight: 500;
  color: #cbd5e0;
  width: fit-content;
`;

const ProductActions = styled.div`
  display: flex;
  justify-content: flex-end;
  gap: 0.5rem;
  margin-top: 12px;

  button {
    background-color: #3a4556;
    color: #ffffff;
    border-radius: 8px;
    padding: 6px;
    
    &:hover {
      background-color: #4a5568;
    }
  }
`;

const MarketplaceContainer = styled.div`
  display: flex;
  align-items: center;
`;

const MarketplaceLabel = styled.span`
  font-size: 12px;
  color: #888;
  margin-right: 8px;
`;

const LastUpdated = styled.div`
  font-size: 0.75rem;
  color: ${({ theme }) => theme.colors.textSecondary};
  margin-top: 0.5rem;
`;

const LoadingState = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 300px;
  font-size: 1.2rem;
  color: ${props => props.theme.colors.textSecondary};
`;

const ErrorState = styled.div`
  text-align: center;
  padding: ${props => props.theme.spacing.lg};
  color: ${props => props.theme.colors.error};
  background: ${props => `${props.theme.colors.error}10`};
  border-radius: ${props => props.theme.borderRadius.medium};
  margin: ${props => props.theme.spacing.lg} 0;
`;

const EmptyState = styled.div`
  text-align: center;
  padding: ${props => props.theme.spacing.xl};
  color: ${props => props.theme.colors.textSecondary};
`;

// Модальное окно
const Modal = styled(motion.div)`
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: rgba(0, 0, 0, 0.5);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 1000;
`;

const ModalContent = styled.div`
  background: linear-gradient(145deg, #2d3748, #1a202c);
  border-radius: 20px;
  padding: 2rem;
  display: flex;
  flex-direction: column;
  gap: 1.5rem;
  box-shadow: 0 10px 25px rgba(0, 0, 0, 0.2);
  max-width: 500px;
  width: 100%;
  position: relative;
`;

const ModalTitle = styled.h2`
  font-size: 1.75rem;
  color: #ffffff;
  margin: 0;
  font-weight: 700;
  background: linear-gradient(90deg, #6a11cb, #2575fc);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  text-align: center;
`;

const Input = styled.input`
  background: rgba(74, 85, 104, 0.2);
  border: 1px solid rgba(113, 128, 150, 0.3);
  padding: 1rem;
  border-radius: 10px;
  color: #ffffff;
  font-size: 1rem;
  width: 100%;
  box-sizing: border-box;
  transition: all 0.2s ease;
  
  &:focus {
    outline: none;
    border-color: rgba(66, 153, 225, 0.6);
    box-shadow: 0 0 0 3px rgba(66, 153, 225, 0.15);
  }
  
  &::placeholder {
    color: #A0AEC0;
  }
`;

const Select = styled.select`
  background: rgba(74, 85, 104, 0.2);
  border: 1px solid rgba(113, 128, 150, 0.3);
  padding: 1rem;
  border-radius: 10px;
  color: #ffffff;
  font-size: 1rem;
  width: 100%;
  box-sizing: border-box;
  transition: all 0.2s ease;
  appearance: none;
  
  &:focus {
    outline: none;
    border-color: rgba(66, 153, 225, 0.6);
    box-shadow: 0 0 0 3px rgba(66, 153, 225, 0.15);
  }
  
  option {
    background: #2d3748;
    color: #ffffff;
  }
`;

const SubmitButton = styled.button`
  background: linear-gradient(90deg, #6a11cb, #2575fc);
  border: none;
  border-radius: 10px;
  padding: 1rem;
  color: #ffffff;
  font-size: 1.1rem;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.2s ease;
  box-shadow: 0 4px 10px rgba(42, 118, 252, 0.2);
  
  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 15px rgba(42, 118, 252, 0.3);
  }
  
  &:disabled {
    background: #A0AEC0;
    cursor: not-allowed;
    transform: none;
    box-shadow: none;
  }
`;

const SupportedStores = styled.div`
  display: flex;
  gap: 1rem;
  flex-wrap: wrap;
  margin-top: 1rem;
  
  img {
    height: 24px;
    margin-right: 8px;
    border-radius: ${props => props.theme.borderRadius.small};
  }
`;

interface Product {
  id: number;
  name: string;
  url: string;
  imageUrl: string;
  currentPrice: number;
  category?: string;
  marketplace?: string;
  createdAt?: string;
  priceChange?: number;
  prices?: Array<{id: number, price: number, createdAt: string}>;
}

// Function to get categories from local storage
const getLocalCategories = (): string[] => {
  const savedCategories = localStorage.getItem('productCategories');
  return savedCategories ? JSON.parse(savedCategories) : ['Электроника', 'Одежда', 'Бытовая техника', 'Продукты', 'Книги', 'Прочее'];
};

// Добавим функцию для плейсхолдера изображений
const getMarketplacePlaceholder = (marketplace: string | undefined): string => {
  if (!marketplace) return 'https://static.vecteezy.com/system/resources/previews/019/896/008/original/male-user-avatar-icon-in-flat-design-style-person-icon-png.png';
  
  switch (marketplace.toLowerCase()) {
    case 'ozon':
      return 'https://cdn-icons-png.flaticon.com/512/5968/5968282.png';
    case 'wildberries':
      return 'https://upload.wikimedia.org/wikipedia/commons/thumb/8/88/Wildberries_logo.svg/2560px-Wildberries_logo.svg.png';
    case 'aliexpress':
      return 'https://upload.wikimedia.org/wikipedia/commons/thumb/a/a9/AliExpress_logo.svg/2560px-AliExpress_logo.svg.png';
    case 'avito':
      return 'https://upload.wikimedia.org/wikipedia/commons/thumb/0/0f/Avito_logo.svg/2560px-Avito_logo.svg.png';
    case 'amazon':
      return 'https://upload.wikimedia.org/wikipedia/commons/thumb/a/a9/Amazon_logo.svg/2560px-Amazon_logo.svg.png';
    case 'yandex market':
      return 'https://avatars.mds.yandex.net/get-altay/10514637/2a00000189bfc8ba88b8c9b7d67141d0dad7/orig';
    default:
      return 'https://static.vecteezy.com/system/resources/previews/019/896/008/original/male-user-avatar-icon-in-flat-design-style-person-icon-png.png';
  }
};

const PriceChart = styled.div`
  height: 40px;
  margin: 10px 0;
  display: flex;
  align-items: flex-end;
  gap: 2px;
`;

const ChartBar = styled.div<{ height: number; isPositive: boolean }>`
  flex: 1;
  height: ${props => `${props.height}%`};
  background: ${props => props.isPositive ? 'rgba(0, 200, 83, 0.2)' : 'rgba(244, 67, 54, 0.2)'};
  border-radius: 2px;
  min-height: 4px;
`;

// Helper function to get marketplace logo
const getMarketplaceLogo = (marketplace?: string): string => {
  if (!marketplace) return '';
  
  switch (marketplace.toLowerCase()) {
    case 'ozon':
      return 'https://upload.wikimedia.org/wikipedia/commons/thumb/8/82/Logo_of_Ozon.ru_%28old%29.svg/320px-Logo_of_Ozon.ru_%28old%29.svg.png';
    case 'wildberries':
      return 'https://upload.wikimedia.org/wikipedia/commons/thumb/8/88/Wildberries_logo.svg/320px-Wildberries_logo.svg.png';
    case 'aliexpress':
      return 'https://upload.wikimedia.org/wikipedia/commons/thumb/e/e1/AliExpress_logo.svg/320px-AliExpress_logo.svg.png';
    case 'avito':
      return 'https://upload.wikimedia.org/wikipedia/commons/thumb/0/0f/Avito_logo.svg/320px-Avito_logo.svg.png';
    default:
      return 'https://cdn-icons-png.flaticon.com/512/3176/3176363.png';
  }
};

// Форматирование цены
const formatPrice = (price: number | undefined): string => {
  if (!price && price !== 0) return 'Нет данных о цене';
  return `${price.toLocaleString('ru-RU')}`;
};

// Функция форматирования оставшегося времени
const formatRemainingTime = (ms: number): string => {
  const seconds = Math.floor((ms / 1000) % 60);
  const minutes = Math.floor((ms / (1000 * 60)) % 60);
  
  return `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
};

const Products: React.FC = () => {
  // Добавляем глобальные стили
  useEffect(() => {
    // Добавляем стили в head документа
    const styleElement = document.createElement('style');
    styleElement.innerHTML = ThemeStyles;
    document.head.appendChild(styleElement);

    // Очистка при размонтировании
    return () => {
      document.head.removeChild(styleElement);
    };
  }, []);

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [url, setUrl] = useState('');
  const [category, setCategory] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const queryClient = useQueryClient();
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [selectedMarketplace, setSelectedMarketplace] = useState<string | null>(null);
  const [availableCategories, setAvailableCategories] = useState<string[]>([]);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [editProductId, setEditProductId] = useState<number | null>(null);
  const [editCategory, setEditCategory] = useState('');
  const [editMarketplace, setEditMarketplace] = useState('');
  const [isEditSubmitting, setIsEditSubmitting] = useState(false);
  const [cooldowns, setCooldowns] = useState<Record<number, { canUpdate: boolean; remainingTimeMs?: number }>>({});
  const [showUpdateTooltips, setShowUpdateTooltips] = useState<Record<number, boolean>>({});
  
  // Функция для установки состояния кулдауна для конкретного продукта
  const setCooldownForProduct = (productId: number, cooldownData: { canUpdate: boolean; remainingTimeMs?: number }) => {
    setCooldowns(prev => ({
      ...prev,
      [productId]: cooldownData
    }));
  };

  // Функция для установки видимости тултипа для конкретного продукта
  const setShowUpdateTooltipForProduct = (productId: number, show: boolean) => {
    setShowUpdateTooltips(prev => ({
      ...prev,
      [productId]: show
    }));
  };

  // Load categories from local storage on mount
  useEffect(() => {
    setAvailableCategories(getLocalCategories());
  }, []);
  
  // Запрос продуктов с сервера
  const { 
    data: products, 
    isLoading, 
    error 
  } = useQuery({
    queryKey: ['products'],
    queryFn: async () => {
      console.log('Fetching products...');
      try {
        const result = await ProductService.getProducts();
        console.log('Products fetched:', result);
        return result;
      } catch (err) {
        console.error('Error fetching products:', err);
        throw err;
      }
    },
    retry: 1,
    staleTime: 30000,
  });
  
  // Обработчик добавления продукта
  const handleAddProduct = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Если уже идет процесс добавления, игнорируем повторные клики
    if (isSubmitting) {
      return;
    }
    
    // Очистка URL от пробелов
    const trimmedUrl = url.trim();
    
    // Проверка URL
    if (!trimmedUrl) {
      toast.error('Пожалуйста, введите URL товара');
      return;
    }
    
    // Validate URL format before submitting
    let validUrl = trimmedUrl;
    if (!validUrl.startsWith('http://') && !validUrl.startsWith('https://')) {
      validUrl = 'https://' + validUrl;
    }
    
    try {
      new URL(validUrl);
    } catch (e) {
      toast.error('Некорректный формат URL. Пожалуйста, введите правильный адрес товара.');
      return;
    }
    
    setIsSubmitting(true);
    toast.info('Добавление товара...', { autoClose: false, toastId: 'adding-product' });
    console.log('Submitting product with URL:', validUrl);
    
    // Если категория не указана, устанавливаем 'Прочее'
    const finalCategory = category.trim() || 'Прочее';
    
    // Log the request that's being sent
    console.log('Sending request with data:', { url: validUrl, category: finalCategory });
    
    addProductMutation.mutate({ 
      url: validUrl, 
      category: finalCategory 
    });
  };
  
  // Мутация для добавления продукта
  const addProductMutation = useMutation({
    mutationFn: async ({ url, category }: { url: string; category?: string }) => {
      console.log('Adding product with data:', { url, category });
      
      // Нормализация URL
      let validUrl = url.trim();
      
      // Проверка и добавление протокола, если отсутствует
      if (!validUrl.startsWith('http://') && !validUrl.startsWith('https://')) {
        validUrl = 'https://' + validUrl;
      }
      
      // Проверяем валидность URL
      try {
        new URL(validUrl);
      } catch (e) {
        throw new Error('Некорректный формат URL. Пожалуйста, введите правильный адрес товара.');
      }
      
      console.log('Sending request with normalized URL:', validUrl);
      try {
        const product = await ProductService.addProduct(validUrl, category);
        console.log('Product added result:', product);
        return product;
      } catch (error) {
        console.error('Error in addProduct mutation:', error);
        throw error;
      }
    },
    onSuccess: (data) => {
      console.log('Product added successfully:', data);
      toast.dismiss('adding-product');
      toast.success('Товар успешно добавлен!');
      setIsModalOpen(false);
      setUrl('');
      setCategory('');
      queryClient.invalidateQueries({ queryKey: ['products'] });
      setIsSubmitting(false);
    },
    onError: (error: any) => {
      console.error('Error adding product:', error);
      toast.dismiss('adding-product');
      let errorMessage = 'Не удалось добавить товар';
      
      if (error.message) {
        errorMessage = error.message;
      } else if (error.response?.data?.message) {
        errorMessage = error.response.data.message;
      } else if (error.response?.data?.error) {
        errorMessage = error.response.data.error;
      } else if (error.response?.status === 500) {
        errorMessage = 'Ошибка сервера. Пожалуйста, попробуйте позже или сообщите администратору.';
      } else if (error.response?.status === 404) {
        errorMessage = 'API endpoint не найден. Проверьте настройки API.';
      } else if (error.code === 'ERR_NETWORK') {
        errorMessage = 'Ошибка сети. Проверьте подключение или доступность сервера.';
      }
      
      toast.error(errorMessage);
      setIsSubmitting(false);
    }
  });
  
  // Мутация для обновления цены продукта
  const updatePriceMutation = useMutation({
    mutationFn: (productId: number) => {
      console.log('Updating price for product ID:', productId);
      return ProductService.updatePrice(productId);
    },
    onSuccess: (data) => {
      console.log('Price updated successfully:', data);
      toast.success('Цена обновлена успешно!');
      queryClient.invalidateQueries({ queryKey: ['products'] });
    },
    onError: (error) => {
      console.error('Error updating price:', error);
      if (error instanceof Error) {
        toast.error(`Ошибка обновления цены: ${error.message}`);
      } else {
        toast.error('Произошла ошибка при обновлении цены');
      }
    }
  });

  // Мутация для удаления продукта
  const deleteProductMutation = useMutation({
    mutationFn: (productId: number) => {
      console.log('Deleting product ID:', productId);
      return ProductService.deleteProduct(productId);
    },
    onSuccess: () => {
      console.log('Product deleted successfully');
      toast.success('Товар удален успешно!');
      queryClient.invalidateQueries({ queryKey: ['products'] });
    },
    onError: (error) => {
      console.error('Error deleting product:', error);
      if (error instanceof Error) {
        toast.error(`Ошибка удаления товара: ${error.message}`);
      } else {
        toast.error('Произошла ошибка при удалении товара');
      }
    }
  });

  // Обработчик открытия модального окна редактирования
  const handleOpenEditModal = (product: Product) => {
    setEditProductId(product.id);
    setEditCategory(product.category || '');
    setEditMarketplace(product.marketplace || '');
    setIsEditModalOpen(true);
  };

  // Мутация для редактирования продукта
  const editProductMutation = useMutation({
    mutationFn: ({ id, category, marketplace }: { id: number, category: string, marketplace: string }) => {
      console.log('Editing product:', { id, category, marketplace });
      return ProductService.updateProduct(id, { category, marketplace });
    },
    onSuccess: () => {
      console.log('Product edited successfully');
      toast.success('Товар отредактирован успешно!');
      setIsEditModalOpen(false);
      setIsEditSubmitting(false);
      queryClient.invalidateQueries({ queryKey: ['products'] });
    },
    onError: (error) => {
      console.error('Error editing product:', error);
      setIsEditSubmitting(false);
      if (error instanceof Error) {
        toast.error(`Ошибка редактирования товара: ${error.message}`);
      } else {
        toast.error('Произошла ошибка при редактировании товара');
      }
    }
  });

  // Обработчик сохранения изменений
  const handleSaveEdit = () => {
    if (!editProductId) return;
    
    setIsEditSubmitting(true);
    editProductMutation.mutate({
      id: editProductId,
      category: editCategory,
      marketplace: editMarketplace
    });
  };

  // Get unique categories and marketplaces from products
  const categories = products 
    ? ['Все', ...new Set(products.map(product => product.category || 'Прочее'))]
    : ['Все'];
    
  const marketplaces = products 
    ? ['Все', ...new Set(products.map(product => product.marketplace || 'Другое').filter(Boolean))]
    : ['Все'];
  
  // Filter products by category and marketplace
  const filteredProducts = products?.filter(product => {
    const categoryMatch = !selectedCategory || selectedCategory === 'Все' || (product.category || 'Прочее') === selectedCategory;
    const marketplaceMatch = !selectedMarketplace || selectedMarketplace === 'Все' || (product.marketplace || 'Другое') === selectedMarketplace;
    return categoryMatch && marketplaceMatch;
  });
    
  // Count products in each category
  const categoryCount = categories.reduce((acc, category) => {
    if (category === 'Все') {
      acc[category] = products?.length || 0;
    } else {
      acc[category] = products?.filter(product => (product.category || 'Прочее') === category).length || 0;
    }
    return acc;
  }, {} as Record<string, number>);
  
  // Count products in each marketplace
  const marketplaceCount = marketplaces.reduce((acc, marketplace) => {
    if (marketplace === 'Все') {
      acc[marketplace] = products?.length || 0;
    } else {
      acc[marketplace] = products?.filter(product => (product.marketplace || 'Другое') === marketplace).length || 0;
    }
    return acc;
  }, {} as Record<string, number>);

  // Функция для запроса статуса кулдауна для продукта
  const getCooldownStatus = useCallback(async (productId: number) => {
    try {
      const result = await ProductService.getUpdateCooldown(productId);
      setCooldownForProduct(productId, result);
      
      // Если есть оставшееся время, запускаем таймер обратного отсчета
      if (!result.canUpdate && result.remainingTimeMs && result.remainingTimeMs > 0) {
        const timer = setInterval(() => {
          setCooldowns(prev => {
            const currentCooldown = prev[productId];
            if (currentCooldown && currentCooldown.remainingTimeMs && currentCooldown.remainingTimeMs > 1000) {
              return {
                ...prev,
                [productId]: {
                  ...currentCooldown,
                  remainingTimeMs: currentCooldown.remainingTimeMs - 1000
                }
              };
            } else {
              clearInterval(timer);
              return {
                ...prev,
                [productId]: { canUpdate: true }
              };
            }
          });
        }, 1000);
        
        return () => clearInterval(timer);
      }
    } catch (error) {
      console.error('Error getting cooldown status:', error);
    }
  }, []);

  // Инициализация статусов кулдауна для всех продуктов
  useEffect(() => {
    if (products && products.length > 0) {
      products.forEach(product => {
        getCooldownStatus(product.id);
      });
    }
  }, [products, getCooldownStatus]);

  // Обновляем статус кулдауна после успешного обновления цены
  useEffect(() => {
    if (updatePriceMutation.isSuccess && updatePriceMutation.data?.productId) {
      getCooldownStatus(Number(updatePriceMutation.data.productId));
    }
  }, [updatePriceMutation.isSuccess, getCooldownStatus, updatePriceMutation.data]);

  // Рендеринг карточек продуктов
  const renderProductCards = () => {
    if (!filteredProducts || filteredProducts.length === 0) {
      return <EmptyMessage>Нет товаров для отображения</EmptyMessage>;
    }

    return filteredProducts.map((product) => {
      // Получаем последнюю цену
      const currentPrice = product.prices && product.prices.length > 0 
        ? product.prices[product.prices.length - 1].price 
        : product.currentPrice || 0;
        
      // Получаем предпоследнюю цену, если есть
      const previousPrice = product.prices && product.prices.length > 1 
        ? product.prices[product.prices.length - 2].price 
        : currentPrice;
        
      // Вычисляем изменение цены
      const priceDiff = currentPrice - previousPrice;
      const priceChangePercent = previousPrice > 0 
        ? (priceDiff / previousPrice) * 100 
        : 0;
      const isPositive = priceDiff >= 0;
      
      // Проверка, есть ли данные о цене
      const hasPrice = currentPrice > 0;
      
      // Получаем данные о кулдауне и тултипе для этого продукта
      const cooldown = cooldowns[product.id] || { canUpdate: true };
      const showUpdateTooltip = showUpdateTooltips[product.id] || false;
      
      return (
        <ProductCard key={product.id}>
          <ProductHeader>
            <ProductLogo>
              <img 
                src={getMarketplaceLogo(product.marketplace)} 
                alt={product.marketplace || 'Товар'} 
                onError={(e) => {
                  const target = e.target as HTMLImageElement;
                  target.src = 'https://cdn-icons-png.flaticon.com/512/3176/3176363.png';
                }}
              />
            </ProductLogo>
            <span>{product.marketplace || 'Неизвестный маркетплейс'}</span>
          </ProductHeader>
          
          <ProductImage>
            <img 
              src={product.imageUrl || getMarketplacePlaceholder(product.marketplace)} 
              alt={product.name} 
              onError={(e) => {
                const target = e.target as HTMLImageElement;
                target.src = getMarketplacePlaceholder(product.marketplace);
              }}
            />
          </ProductImage>
          
          <ProductName>{product.name}</ProductName>
          
          <ProductPrice>
            <CurrentPrice>
              <PriceValue>{hasPrice ? `${formatPrice(currentPrice)} ₽` : 'Нет данных о цене'}</PriceValue>
              <div style={{ position: 'relative' }}>
                {showUpdateTooltip && !cooldown.canUpdate && (
                  <UpdateTooltip>
                    Обновление доступно через {formatRemainingTime(cooldown.remainingTimeMs || 0)}
                  </UpdateTooltip>
                )}
                <UpdateButton 
                  onClick={() => {
                    if (cooldown.canUpdate) {
                      updatePriceMutation.mutate(product.id);
                    } else {
                      setShowUpdateTooltipForProduct(product.id, true);
                      setTimeout(() => setShowUpdateTooltipForProduct(product.id, false), 3000);
                    }
                  }}
                  disabled={updatePriceMutation.isPending || !cooldown.canUpdate}
                  onMouseEnter={() => !cooldown.canUpdate && setShowUpdateTooltipForProduct(product.id, true)}
                  onMouseLeave={() => setShowUpdateTooltipForProduct(product.id, false)}
                  title={cooldown.canUpdate ? "Обновить цену" : `Обновление через ${formatRemainingTime(cooldown.remainingTimeMs || 0)}`}
                >
                  <AutorenewIcon fontSize="small" />
                </UpdateButton>
                {!cooldown.canUpdate && cooldown.remainingTimeMs && (
                  <CooldownTimer>
                    <AccessTimeIcon style={{ fontSize: 12 }} /> 
                    {formatRemainingTime(cooldown.remainingTimeMs)}
                  </CooldownTimer>
                )}
              </div>
            </CurrentPrice>
            
            {hasPrice && priceDiff !== 0 && (
              <PriceChange isPositive={isPositive}>
                {isPositive ? <ArrowUpwardIcon fontSize="small" /> : <ArrowDownwardIcon fontSize="small" />}
                {isPositive ? '+' : ''}{priceDiff.toLocaleString('ru-RU')} ₽
                ({isPositive ? '+' : ''}{priceChangePercent.toFixed(1)}%)
              </PriceChange>
            )}
          </ProductPrice>
          
          <ProductCategory>
            {product.category || 'Без категории'}
          </ProductCategory>
          
          <ProductActions>
            <IconButton 
              onClick={() => handleOpenEditModal(product)} 
              sx={{ backgroundColor: '#3a4556', color: 'white' }}
              title="Редактировать"
            >
              <EditIcon />
            </IconButton>
            <IconButton 
              onClick={() => deleteProductMutation.mutate(product.id)} 
              sx={{ backgroundColor: '#3a4556', color: 'white' }}
              title="Удалить"
            >
              <DeleteOutlineIcon />
            </IconButton>
          </ProductActions>
        </ProductCard>
      );
    });
  };

  // Компонент загрузки
  if (isLoading) {
    return (
      <Container>
        <Header>
          <Title>Мои товары</Title>
        </Header>
        <LoadingState>Загрузка товаров...</LoadingState>
      </Container>
    );
  }

  // Компонент ошибки
  if (error) {
    return (
      <Container>
        <Header>
          <Title>Мои товары</Title>
          <HeaderActions>
            <CategoryButton to="/categories">
              <span>🏷️</span> Управление категориями
            </CategoryButton>
            <AddButton
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => setIsModalOpen(true)}
            >
              + Добавить товар
            </AddButton>
          </HeaderActions>
        </Header>
        <ErrorState>
          <h3>Ошибка при загрузке товаров</h3>
          <p>{(error as Error).message || 'Неизвестная ошибка'}</p>
          <Button 
            variant="contained" 
            onClick={() => queryClient.invalidateQueries({ queryKey: ['products'] })}
            style={{
              background: 'linear-gradient(135deg, #6a11cb 0%, #2575fc 100%)',
              borderRadius: '12px',
              padding: '8px 20px'
            }}
          >
            Попробовать снова
          </Button>
        </ErrorState>
      </Container>
    );
  }

  return (
    <Container>
      <Header>
        <Title>Мои товары</Title>
        <HeaderActions>
          <CategoryButton 
            to="/categories"
            className="hover-scale"
            style={{
              transition: 'transform 0.2s ease',
            }}
          >
            <span>🏷️</span> Управление категориями
          </CategoryButton>
          <AddButton
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => setIsModalOpen(true)}
          >
            <AddIcon fontSize="small" /> Добавить товар
          </AddButton>
        </HeaderActions>
      </Header>

      <FilterSection>
        <FilterTitle>Фильтр по категориям</FilterTitle>
        <CategoryFilterBar>
          {categories.map(category => (
            <CategoryFilterItem 
              key={category}
              isActive={selectedCategory === category || (selectedCategory === null && category === 'Все')}
              onClick={() => setSelectedCategory(category === 'Все' ? null : category)}
            >
              {category}
              <CategoryFilterCount>
                {categoryCount[category]}
              </CategoryFilterCount>
            </CategoryFilterItem>
          ))}
        </CategoryFilterBar>
      </FilterSection>
      
      <FilterSection>
        <FilterTitle>Фильтр по маркетплейсам</FilterTitle>
        <MarketplaceFilterBar>
          {marketplaces.map(marketplace => (
            <CategoryFilterItem 
              key={marketplace}
              isActive={selectedMarketplace === marketplace || (selectedMarketplace === null && marketplace === 'Все')}
              onClick={() => setSelectedMarketplace(marketplace === 'Все' ? null : marketplace)}
            >
              {marketplace === 'Все' ? (
                <span>Все маркетплейсы</span>
              ) : (
                <span>{marketplace}</span>
              )}
              <CategoryFilterCount>
                {marketplaceCount[marketplace]}
              </CategoryFilterCount>
            </CategoryFilterItem>
          ))}
        </MarketplaceFilterBar>
      </FilterSection>

      {/* Продукты */}
      {isLoading ? (
        <LoadingSpinner>
          <CircularProgress />
        </LoadingSpinner>
      ) : error ? (
        <NoProductsMessage>
          <NoProductsTitle>Ошибка загрузки</NoProductsTitle>
          <NoProductsDescription>
            Произошла ошибка при загрузке товаров. Пожалуйста, попробуйте позже.
          </NoProductsDescription>
          <Button 
            variant="contained" 
            onClick={() => queryClient.invalidateQueries({ queryKey: ['products'] })}
            style={{
              background: 'linear-gradient(135deg, #6a11cb 0%, #2575fc 100%)',
              borderRadius: '12px',
              padding: '8px 20px'
            }}
          >
            Попробовать снова
          </Button>
        </NoProductsMessage>
      ) : !filteredProducts || filteredProducts.length === 0 ? (
        <NoProductsMessage>
          <NoProductsTitle>
            {products && products.length > 0 
              ? 'Нет товаров, соответствующих фильтрам' 
              : 'У вас пока нет отслеживаемых товаров'}
          </NoProductsTitle>
          <NoProductsDescription>
            {products && products.length > 0 
              ? 'Попробуйте изменить параметры фильтра или добавить новые товары.' 
              : 'Добавьте товар, чтобы начать отслеживать его цену.'}
          </NoProductsDescription>
          <Button 
            variant="contained" 
            onClick={() => setIsModalOpen(true)}
            startIcon={<AddIcon />}
            style={{
              background: 'linear-gradient(135deg, #6a11cb 0%, #2575fc 100%)',
              borderRadius: '12px',
              padding: '8px 20px'
            }}
          >
            Добавить первый товар
          </Button>
        </NoProductsMessage>
      ) : (
        <ProductsGrid>
          {renderProductCards()}
        </ProductsGrid>
      )}

      {/* Модальное окно добавления товара */}
      <Dialog 
        open={isModalOpen} 
        onClose={() => setIsModalOpen(false)}
        maxWidth="sm"
        fullWidth
        PaperProps={{
          style: {
            borderRadius: '20px',
            boxShadow: '0 10px 25px rgba(0,0,0,0.2)',
            overflow: 'hidden',
            background: 'linear-gradient(145deg, #2d3748, #1a202c)'
          }
        }}
      >
        <DialogTitle 
          sx={{ 
            display: 'flex', 
            justifyContent: 'space-between', 
            alignItems: 'center',
            background: 'linear-gradient(90deg, #6a11cb, #2575fc)',
            color: 'white',
            padding: '20px 24px',
            fontSize: '22px',
            fontWeight: '700'
          }}
        >
          <Typography variant="h6" sx={{ fontWeight: 700, fontSize: '20px' }}>
            Добавление товара для отслеживания цены
          </Typography>
          <IconButton 
            edge="end" 
            color="inherit" 
            onClick={() => setIsModalOpen(false)}
            aria-label="close"
            sx={{ 
              color: 'white',
              '&:hover': {
                background: 'rgba(255,255,255,0.15)'
              }
            }}
          >
            <CloseIcon />
          </IconButton>
        </DialogTitle>
        <DialogContent sx={{ padding: '24px', color: 'white' }}>
          <form onSubmit={handleAddProduct}>
            <TextField
              autoFocus
              margin="dense"
              label="URL товара"
              type="text"
              fullWidth
              variant="outlined"
              placeholder="Вставьте ссылку на товар (https://...)"
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              disabled={isSubmitting}
              required
              sx={{ 
                mb: 3, 
                mt: 1,
                '& .MuiOutlinedInput-root': {
                  borderRadius: '12px',
                  color: 'white',
                  '& fieldset': {
                    borderColor: 'rgba(255, 255, 255, 0.23)',
                  },
                  '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                    borderColor: '#6a11cb',
                    borderWidth: '2px'
                  },
                  '&:hover .MuiOutlinedInput-notchedOutline': {
                    borderColor: '#6a11cb',
                  },
                  backgroundColor: 'rgba(255, 255, 255, 0.05)'
                },
                '& .MuiFormLabel-root': {
                  color: 'rgba(255, 255, 255, 0.7)'
                },
                '& .MuiFormLabel-root.Mui-focused': {
                  color: '#6a11cb'
                },
                '& .MuiInputBase-input': {
                  color: 'white',
                }
              }}
              error={url.trim() !== '' && !url.trim().startsWith('http')}
              helperText={url.trim() !== '' && !url.trim().startsWith('http') ? 'URL должен начинаться с http:// или https://' : ''}
            />
            
            <FormControl fullWidth margin="normal" sx={{ mb: 3 }}>
              <InputLabel id="category-select-label" sx={{ color: 'rgba(255, 255, 255, 0.7)' }}>Категория</InputLabel>
              <MuiSelect
                labelId="category-select-label"
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                label="Категория"
                disabled={isSubmitting}
                sx={{ 
                  borderRadius: '12px',
                  color: 'white',
                  '& .MuiOutlinedInput-notchedOutline': {
                    borderColor: 'rgba(255, 255, 255, 0.23)',
                  },
                  '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                    borderColor: '#6a11cb',
                    borderWidth: '2px'
                  },
                  '&:hover .MuiOutlinedInput-notchedOutline': {
                    borderColor: '#6a11cb',
                  },
                  backgroundColor: 'rgba(255, 255, 255, 0.05)',
                  '& .MuiSelect-icon': {
                    color: 'white',
                  }
                }}
              >
                <MenuItem value="">
                  <em>Выберите категорию</em>
                </MenuItem>
                {availableCategories.map((cat) => (
                  <MenuItem key={cat} value={cat}>
                    {cat}
                  </MenuItem>
                ))}
              </MuiSelect>
            </FormControl>
            
            <Box sx={{ mb: 3 }}>
              <Typography variant="subtitle1" sx={{ mb: 1.5, fontWeight: 600, color: 'rgba(255, 255, 255, 0.9)' }}>
                Поддерживаемые маркетплейсы:
              </Typography>
              <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1 }}>
                <Paper sx={{ 
                  px: 1.5, 
                  py: 1,
                  display: 'flex', 
                  alignItems: 'center', 
                  gap: 1, 
                  borderRadius: '12px',
                  background: 'rgba(66, 153, 225, 0.15)',
                  border: '1px solid rgba(66, 153, 225, 0.3)',
                  boxShadow: 'none'
                }}>
                  <Typography variant="body2" sx={{ fontWeight: 600, color: '#60a5fa' }}>Ozon</Typography>
                </Paper>
                <Paper sx={{ 
                  px: 1.5, 
                  py: 1,
                  display: 'flex', 
                  alignItems: 'center', 
                  gap: 1, 
                  borderRadius: '12px',
                  background: 'rgba(113, 128, 150, 0.15)',
                  border: '1px solid rgba(113, 128, 150, 0.3)',
                  boxShadow: 'none'
                }}>
                  <Typography variant="body2" sx={{ fontWeight: 600, color: '#cbd5e0' }}>Wildberries</Typography>
                </Paper>
                <Paper sx={{ 
                  px: 1.5, 
                  py: 1,
                  display: 'flex', 
                  alignItems: 'center', 
                  gap: 1, 
                  borderRadius: '12px',
                  background: 'rgba(227, 52, 47, 0.15)',
                  border: '1px solid rgba(227, 52, 47, 0.3)',
                  boxShadow: 'none'
                }}>
                  <Typography variant="body2" sx={{ fontWeight: 600, color: '#fc8181' }}>AliExpress</Typography>
                </Paper>
              </Box>
            </Box>
            
            <Typography variant="body2" sx={{ mb: 2, color: 'rgba(255, 255, 255, 0.7)', lineHeight: '1.6' }}>
              Добавьте ссылку на товар, и мы будем автоматически отслеживать изменения цены.
              Вы получите возможность следить за динамикой цен и выбирать лучший момент для покупки.
            </Typography>
          </form>
        </DialogContent>
        <DialogActions sx={{ padding: '16px 24px 24px', background: 'linear-gradient(145deg, #2d3748, #1a202c)' }}>
          <Button 
            onClick={() => setIsModalOpen(false)} 
            sx={{ 
              color: '#cbd5e0',
              borderRadius: '10px',
              textTransform: 'none',
              fontWeight: 500,
              px: 3
            }}
          >
            Отмена
          </Button>
          <Button 
            onClick={handleAddProduct}
            disabled={isSubmitting || !url.trim().startsWith('http')}
            variant="contained"
            startIcon={isSubmitting ? <CircularProgress size={20} color="inherit" /> : <AddIcon />}
            sx={{ 
              background: 'linear-gradient(90deg, #6a11cb, #2575fc)',
              borderRadius: '10px',
              textTransform: 'none',
              fontWeight: 500,
              boxShadow: '0 4px 15px rgba(42, 118, 252, 0.2)',
              px: 3,
              '&:hover': {
                background: 'linear-gradient(135deg, #5a0cb6 0%, #1565e0 100%)',
                boxShadow: '0 6px 20px rgba(42, 118, 252, 0.3)',
              },
              '&.Mui-disabled': {
                background: '#cbd5e0',
                color: '#718096'
              }
            }}
          >
            {isSubmitting ? 'Добавление...' : 'Добавить товар'}
          </Button>
        </DialogActions>
      </Dialog>

      {/* Модальное окно редактирования товара */}
      <Dialog 
        open={isEditModalOpen} 
        onClose={() => setIsEditModalOpen(false)}
        maxWidth="sm"
        fullWidth
        PaperProps={{
          style: {
            borderRadius: '20px',
            boxShadow: '0 10px 25px rgba(0,0,0,0.2)',
            overflow: 'hidden'
          }
        }}
      >
        <DialogTitle 
          sx={{ 
            display: 'flex', 
            justifyContent: 'space-between', 
            alignItems: 'center',
            background: 'linear-gradient(135deg, #6a11cb 0%, #2575fc 100%)',
            color: 'white',
            padding: '20px 24px'
          }}
        >
          <Typography variant="h6" sx={{ fontWeight: 600 }}>
            Редактирование товара
          </Typography>
          <IconButton 
            edge="end" 
            color="inherit" 
            onClick={() => setIsEditModalOpen(false)}
            aria-label="close"
            sx={{ 
              color: 'white',
              '&:hover': {
                background: 'rgba(255,255,255,0.15)'
              }
            }}
          >
            <CloseIcon />
          </IconButton>
        </DialogTitle>
        <DialogContent sx={{ padding: '24px' }}>
          <form onSubmit={handleSaveEdit}>
            <FormControl fullWidth margin="normal" sx={{ mb: 3 }}>
              <InputLabel id="edit-category-select-label">Категория</InputLabel>
              <MuiSelect
                labelId="edit-category-select-label"
                value={editCategory}
                onChange={(e) => setEditCategory(e.target.value)}
                label="Категория"
                disabled={isEditSubmitting}
                sx={{ 
                  borderRadius: '12px',
                  '& .MuiOutlinedInput-notchedOutline': {
                    borderColor: '#e2e8f0',
                  },
                  '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                    borderColor: '#6a11cb',
                    borderWidth: '2px'
                  },
                  '&:hover .MuiOutlinedInput-notchedOutline': {
                    borderColor: '#6a11cb',
                  },
                }}
              >
                <MenuItem value="">
                  <em>Выберите категорию</em>
                </MenuItem>
                {availableCategories.map((cat) => (
                  <MenuItem key={cat} value={cat}>
                    {cat}
                  </MenuItem>
                ))}
              </MuiSelect>
            </FormControl>
            
            <FormControl fullWidth margin="normal" sx={{ mb: 3 }}>
              <InputLabel id="edit-marketplace-select-label">Маркетплейс</InputLabel>
              <MuiSelect
                labelId="edit-marketplace-select-label"
                value={editMarketplace}
                onChange={(e) => setEditMarketplace(e.target.value)}
                label="Маркетплейс"
                disabled={isEditSubmitting}
                sx={{ 
                  borderRadius: '12px',
                  '& .MuiOutlinedInput-notchedOutline': {
                    borderColor: '#e2e8f0',
                  },
                  '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                    borderColor: '#6a11cb',
                    borderWidth: '2px'
                  },
                  '&:hover .MuiOutlinedInput-notchedOutline': {
                    borderColor: '#6a11cb',
                  },
                }}
              >
                <MenuItem value="">
                  <em>Выберите маркетплейс</em>
                </MenuItem>
                <MenuItem value="Ozon">Ozon</MenuItem>
                <MenuItem value="Wildberries">Wildberries</MenuItem>
                <MenuItem value="AliExpress">AliExpress</MenuItem>
                <MenuItem value="Другое">Другое</MenuItem>
              </MuiSelect>
            </FormControl>
            
            <Typography variant="body2" sx={{ mt: 2, color: '#718096' }}>
              Правильная категоризация товаров поможет вам легче находить нужные товары и анализировать цены.
            </Typography>
          </form>
        </DialogContent>
        <DialogActions sx={{ padding: '16px 24px 24px' }}>
          <Button 
            onClick={() => setIsEditModalOpen(false)} 
            sx={{ 
              color: '#4a5568',
              borderRadius: '10px',
              textTransform: 'none',
              fontWeight: 500,
              px: 3
            }}
          >
            Отмена
          </Button>
          <Button 
            onClick={handleSaveEdit}
            disabled={isEditSubmitting}
            variant="contained"
            startIcon={isEditSubmitting ? <CircularProgress size={20} color="inherit" /> : null}
            sx={{ 
              background: 'linear-gradient(135deg, #6a11cb 0%, #2575fc 100%)',
              borderRadius: '10px',
              textTransform: 'none',
              fontWeight: 500,
              boxShadow: '0 4px 15px rgba(42, 118, 252, 0.2)',
              px: 3,
              '&:hover': {
                background: 'linear-gradient(135deg, #5a0cb6 0%, #1565e0 100%)',
                boxShadow: '0 6px 20px rgba(42, 118, 252, 0.3)',
              },
              '&.Mui-disabled': {
                background: '#cbd5e0',
                color: '#718096'
              }
            }}
          >
            {isEditSubmitting ? 'Сохранение...' : 'Сохранить изменения'}
          </Button>
        </DialogActions>
      </Dialog>
    </Container>
  );
};

export default Products; 