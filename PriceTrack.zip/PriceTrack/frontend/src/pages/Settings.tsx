import React, { useState, useEffect, ChangeEvent } from 'react';
import styled from 'styled-components';
import { motion } from 'framer-motion';
import { toast } from 'react-toastify';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import axios from 'axios';

const Container = styled.div`
  max-width: 800px;
  margin: 0 auto;
  padding: 2rem;
  background-color: ${({ theme }) => theme.colors.surface};
  border-radius: ${({ theme }) => theme.borderRadius.medium};
  box-shadow: ${({ theme }) => theme.shadows.md};
`;

const Title = styled.h1`
  color: ${({ theme }) => theme.colors.text};
  margin-bottom: 1.5rem;
  font-size: 1.8rem;
`;

const Section = styled.section`
  margin-bottom: 2rem;
  padding-bottom: 1.5rem;
  border-bottom: 1px solid ${({ theme }) => theme.colors.border};
`;

const SectionTitle = styled.h2`
  color: ${({ theme }) => theme.colors.text};
  font-size: 1.4rem;
  margin-bottom: 1rem;
`;

const SettingRow = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 1rem;
  padding: 0.75rem;
  background-color: ${({ theme }) => theme.colors.backgroundAlt};
  border-radius: ${({ theme }) => theme.borderRadius.small};
`;

const SettingLabel = styled.div`
  color: ${({ theme }) => theme.colors.text};
  font-weight: 500;
`;

const SettingDescription = styled.p`
  color: ${({ theme }) => theme.colors.textLight};
  font-size: 0.9rem;
  margin-top: 0.25rem;
`;

const Toggle = styled.label`
  position: relative;
  display: inline-block;
  width: 52px;
  height: 26px;
`;

const ToggleInput = styled.input`
  opacity: 0;
  width: 0;
  height: 0;
  
  &:checked + span {
    background-color: ${({ theme }) => theme.colors.primary};
  }
  
  &:checked + span:before {
    transform: translateX(26px);
  }
`;

const ToggleSlider = styled.span`
  position: absolute;
  cursor: pointer;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: ${({ theme }) => theme.colors.border};
  transition: ${({ theme }) => theme.transitions.default};
  border-radius: 34px;
  
  &:before {
    position: absolute;
    content: "";
    height: 18px;
    width: 18px;
    left: 4px;
    bottom: 4px;
    background-color: white;
    transition: ${({ theme }) => theme.transitions.default};
    border-radius: 50%;
  }
`;

const Input = styled.input`
  padding: 0.75rem;
  border-radius: ${({ theme }) => theme.borderRadius.small};
  border: 1px solid ${({ theme }) => theme.colors.border};
  background-color: ${({ theme }) => theme.colors.backgroundAlt};
  color: ${({ theme }) => theme.colors.text};
  width: 100%;
  margin-top: 0.5rem;
  
  &:focus {
    outline: none;
    border-color: ${({ theme }) => theme.colors.primary};
  }
`;

const Select = styled.select`
  padding: 0.75rem;
  border-radius: ${({ theme }) => theme.borderRadius.small};
  border: 1px solid ${({ theme }) => theme.colors.border};
  background-color: ${({ theme }) => theme.colors.backgroundAlt};
  color: ${({ theme }) => theme.colors.text};
  width: 100%;
  margin-top: 0.5rem;
  
  &:focus {
    outline: none;
    border-color: ${({ theme }) => theme.colors.primary};
  }
`;

const Button = styled(motion.button)`
  padding: 0.75rem 1.5rem;
  background-color: ${({ theme }) => theme.colors.primary};
  color: white;
  border: none;
  border-radius: ${({ theme }) => theme.borderRadius.small};
  cursor: pointer;
  font-weight: 500;
  transition: ${({ theme }) => theme.transitions.fast};
  
  &:hover {
    opacity: 0.9;
  }
  
  &:disabled {
    background-color: ${({ theme }) => theme.colors.border};
    cursor: not-allowed;
  }
`;

const ButtonGroup = styled.div`
  display: flex;
  gap: 1rem;
  margin-top: 2rem;
`;

const ResetButton = styled(Button)`
  background-color: ${({ theme }) => theme.colors.error};
`;

const InputGroup = styled.div`
  margin-top: 1rem;
`;

const InputLabel = styled.label`
  display: block;
  margin-bottom: 0.5rem;
  color: ${({ theme }) => theme.colors.text};
`;

const ErrorMessage = styled.p`
  color: ${({ theme }) => theme.colors.error};
  font-size: 0.85rem;
  margin-top: 0.5rem;
`;

// Email validation function
const validateEmail = (email: string): boolean => {
  const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return re.test(email);
};

// Telegram username validation
const validateTelegramUsername = (username: string): boolean => {
  return username.length > 0;
};

// Service for settings management
const SettingsService = {
  saveSettings: (settings: any) => {
    localStorage.setItem('userSettings', JSON.stringify(settings));
  },
  
  getSettings: () => {
    const savedSettings = localStorage.getItem('userSettings');
    return savedSettings ? JSON.parse(savedSettings) : null;
  },
  
  resetSettings: () => {
    localStorage.removeItem('userSettings');
  }
};

const Settings: React.FC = () => {
  // Settings state
  const [darkMode, setDarkMode] = useState(false);
  const [emailNotifications, setEmailNotifications] = useState(false);
  const [telegramNotifications, setTelegramNotifications] = useState(false);
  const [priceAlerts, setPriceAlerts] = useState(false);
  const [emailInput, setEmailInput] = useState('');
  const [telegramInput, setTelegramInput] = useState('');
  const [priceAlertThreshold, setPriceAlertThreshold] = useState('10');
  const [showNewProducts, setShowNewProducts] = useState(true);
  const [emailError, setEmailError] = useState('');
  const [telegramError, setTelegramError] = useState('');
  const [hasChanges, setHasChanges] = useState(false);
  
  // Load settings on mount
  useEffect(() => {
    const savedSettings = SettingsService.getSettings();
    if (savedSettings) {
      setDarkMode(savedSettings.darkMode || false);
      setEmailNotifications(savedSettings.emailNotifications || false);
      setTelegramNotifications(savedSettings.telegramNotifications || false);
      setPriceAlerts(savedSettings.priceAlerts || false);
      setEmailInput(savedSettings.email || '');
      setTelegramInput(savedSettings.telegram || '');
      setPriceAlertThreshold(savedSettings.priceAlertThreshold || '10');
      setShowNewProducts(savedSettings.showNewProducts !== false);
    }
    setHasChanges(false);
  }, []);
  
  // Track changes
  useEffect(() => {
    setHasChanges(true);
  }, [darkMode, emailNotifications, telegramNotifications, priceAlerts, emailInput, telegramInput, priceAlertThreshold, showNewProducts]);
  
  // Validate email when email notifications are enabled
  useEffect(() => {
    if (emailNotifications && emailInput.trim() !== '') {
      const isValid = validateEmail(emailInput);
      setEmailError(isValid ? '' : 'Пожалуйста, введите корректный email адрес');
    } else {
      setEmailError('');
    }
  }, [emailInput, emailNotifications]);
  
  // Validate telegram username when telegram notifications are enabled
  useEffect(() => {
    if (telegramNotifications && telegramInput.trim() !== '') {
      const isValid = validateTelegramUsername(telegramInput);
      setTelegramError(isValid ? '' : 'Пожалуйста, введите имя пользователя Telegram');
    } else {
      setTelegramError('');
    }
  }, [telegramInput, telegramNotifications]);
  
  // Email subscription mutation
  const emailSubscriptionMutation = useMutation({
    mutationFn: async (email: string) => {
      const response = await axios.post(`${import.meta.env.VITE_API_URL}/users/subscribe`, { email });
      return response.data;
    },
    onSuccess: () => {
      toast.success('Подписка на email обновления успешно оформлена!');
    },
    onError: (error: any) => {
      console.error('Error subscribing to email updates:', error);
      toast.error(error.response?.data?.message || 'Произошла ошибка при оформлении подписки');
    }
  });
  
  // Handle input changes
  const handleEmailChange = (e: ChangeEvent<HTMLInputElement>) => {
    setEmailInput(e.target.value);
  };
  
  const handleTelegramChange = (e: ChangeEvent<HTMLInputElement>) => {
    setTelegramInput(e.target.value);
  };
  
  const handleThresholdChange = (e: ChangeEvent<HTMLSelectElement>) => {
    setPriceAlertThreshold(e.target.value);
  };
  
  // Save settings
  const saveSettings = () => {
    // Validate before saving
    if (emailNotifications && !validateEmail(emailInput)) {
      toast.error('Пожалуйста, введите корректный email адрес');
      return;
    }
    
    if (telegramNotifications && !validateTelegramUsername(telegramInput)) {
      toast.error('Пожалуйста, введите имя пользователя Telegram');
      return;
    }
    
    const settings = {
      darkMode,
      emailNotifications,
      telegramNotifications,
      priceAlerts,
      email: emailInput,
      telegram: telegramInput,
      priceAlertThreshold,
      showNewProducts
    };
    
    SettingsService.saveSettings(settings);
    
    // Subscribe to email updates if enabled
    if (emailNotifications && validateEmail(emailInput)) {
      emailSubscriptionMutation.mutate(emailInput);
    }
    
    toast.success('Настройки успешно сохранены');
    setHasChanges(false);
  };
  
  // Reset settings
  const resetSettings = () => {
    if (window.confirm('Вы уверены, что хотите сбросить все настройки?')) {
      SettingsService.resetSettings();
      setDarkMode(false);
      setEmailNotifications(false);
      setTelegramNotifications(false);
      setPriceAlerts(false);
      setEmailInput('');
      setTelegramInput('');
      setPriceAlertThreshold('10');
      setShowNewProducts(true);
      setHasChanges(false);
      toast.success('Настройки сброшены до значений по умолчанию');
    }
  };
  
  return (
    <Container>
      <Title>Настройки</Title>
      
      <Section>
        <SectionTitle>Внешний вид</SectionTitle>
        
        <SettingRow>
          <div>
            <SettingLabel>Темная тема</SettingLabel>
            <SettingDescription>Переключить на темный режим интерфейса</SettingDescription>
          </div>
          <Toggle>
            <ToggleInput 
              type="checkbox" 
              checked={darkMode} 
              onChange={() => setDarkMode(!darkMode)} 
            />
            <ToggleSlider />
          </Toggle>
        </SettingRow>
      </Section>
      
      <Section>
        <SectionTitle>Уведомления</SectionTitle>
        
        <SettingRow>
          <div>
            <SettingLabel>Email уведомления</SettingLabel>
            <SettingDescription>Получать уведомления об изменении цен на email</SettingDescription>
          </div>
          <Toggle>
            <ToggleInput 
              type="checkbox" 
              checked={emailNotifications} 
              onChange={() => setEmailNotifications(!emailNotifications)} 
            />
            <ToggleSlider />
          </Toggle>
        </SettingRow>
        
        {emailNotifications && (
          <InputGroup>
            <InputLabel>Email адрес</InputLabel>
            <Input 
              type="email" 
              value={emailInput} 
              onChange={handleEmailChange} 
              placeholder="example@mail.ru" 
            />
            {emailError && <ErrorMessage>{emailError}</ErrorMessage>}
          </InputGroup>
        )}
        
        <SettingRow>
          <div>
            <SettingLabel>Telegram уведомления</SettingLabel>
            <SettingDescription>Получать уведомления через Telegram бота</SettingDescription>
          </div>
          <Toggle>
            <ToggleInput 
              type="checkbox" 
              checked={telegramNotifications} 
              onChange={() => setTelegramNotifications(!telegramNotifications)} 
            />
            <ToggleSlider />
          </Toggle>
        </SettingRow>
        
        {telegramNotifications && (
          <InputGroup>
            <InputLabel>Имя пользователя Telegram</InputLabel>
            <Input 
              type="text" 
              value={telegramInput} 
              onChange={handleTelegramChange} 
              placeholder="@username" 
            />
            {telegramError && <ErrorMessage>{telegramError}</ErrorMessage>}
          </InputGroup>
        )}
      </Section>
      
      <Section>
        <SectionTitle>Отслеживание цен</SectionTitle>
        
        <SettingRow>
          <div>
            <SettingLabel>Уведомления о снижении цены</SettingLabel>
            <SettingDescription>Получать уведомления, когда цена снижается больше чем на определенный процент</SettingDescription>
          </div>
          <Toggle>
            <ToggleInput 
              type="checkbox" 
              checked={priceAlerts} 
              onChange={() => setPriceAlerts(!priceAlerts)} 
            />
            <ToggleSlider />
          </Toggle>
        </SettingRow>
        
        {priceAlerts && (
          <InputGroup>
            <InputLabel>Порог снижения цены</InputLabel>
            <Select value={priceAlertThreshold} onChange={handleThresholdChange}>
              <option value="5">5%</option>
              <option value="10">10%</option>
              <option value="15">15%</option>
              <option value="20">20%</option>
              <option value="25">25%</option>
              <option value="30">30%</option>
            </Select>
          </InputGroup>
        )}
        
        <SettingRow>
          <div>
            <SettingLabel>Отображать новые товары</SettingLabel>
            <SettingDescription>Показывать уведомления о новых добавленных товарах</SettingDescription>
          </div>
          <Toggle>
            <ToggleInput 
              type="checkbox" 
              checked={showNewProducts} 
              onChange={() => setShowNewProducts(!showNewProducts)} 
            />
            <ToggleSlider />
          </Toggle>
        </SettingRow>
      </Section>
      
      <ButtonGroup>
        <Button 
          onClick={saveSettings} 
          disabled={!hasChanges || (emailNotifications && !!emailError) || (telegramNotifications && !!telegramError)}
        >
          Сохранить настройки
        </Button>
        <ResetButton onClick={resetSettings}>Сбросить настройки</ResetButton>
      </ButtonGroup>
    </Container>
  );
};

export default Settings; 