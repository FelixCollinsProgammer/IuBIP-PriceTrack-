import React, { useState } from 'react';
import axios from 'axios';
import Button from './Button';

interface ParserResult {
  success: boolean;
  data?: {
    name: string;
    price: number;
    originalPrice?: number;
    discount?: number;
    imageUrl: string;
    marketplace?: string;
    url?: string;
    executionTime?: number;
  };
  error?: string;
  seleniumData?: any;
  playwrightData?: any;
  comparison?: {
    fasterMethod: string;
    timeDifference: string;
    priceDifference: number;
    bothSuccessful: boolean;
  };
}

const ParserTester: React.FC = () => {
  const [url, setUrl] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [result, setResult] = useState<ParserResult | null>(null);
  const [error, setError] = useState<string>('');
  const [selectedParser, setSelectedParser] = useState<'selenium' | 'playwright' | 'compare'>('selenium');

  const handleUrlChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setUrl(e.target.value);
  };

  const handleParserChange = (parser: 'selenium' | 'playwright' | 'compare') => {
    setSelectedParser(parser);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!url) {
      setError('Пожалуйста, введите URL');
      return;
    }
    
    // Clear previous results and errors
    setResult(null);
    setError('');
    setIsLoading(true);
    
    try {
      let endpoint = '';
      
      switch (selectedParser) {
        case 'selenium':
          endpoint = '/api/products/parse/selenium';
          break;
        case 'playwright':
          endpoint = '/api/products/parse/playwright';
          break;
        case 'compare':
          endpoint = '/api/products/parse/compare';
          break;
      }
      
      const response = await axios.post(endpoint, { url });
      setResult(response.data);
    } catch (err: any) {
      setError(err.response?.data?.message || 'Произошла ошибка при парсинге URL');
      console.error('Error during parsing:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const renderParserResult = () => {
    if (!result) return null;
    
    if (selectedParser === 'compare' && result.seleniumData && result.playwrightData) {
      return (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-4">
          <div className="bg-gray-100 dark:bg-gray-800 rounded-lg p-4">
            <h3 className="text-lg font-semibold mb-2">Selenium Parser</h3>
            {result.seleniumData.success ? (
              <>
                <div className="flex mb-2">
                  {result.seleniumData.imageUrl && (
                    <img src={result.seleniumData.imageUrl} alt={result.seleniumData.name} className="w-20 h-20 object-contain mr-4" />
                  )}
                  <div>
                    <p className="font-medium">{result.seleniumData.name}</p>
                    <p className="text-green-600 dark:text-green-400 font-bold">{result.seleniumData.price} ₽</p>
                    {result.seleniumData.originalPrice > 0 && result.seleniumData.originalPrice !== result.seleniumData.price && (
                      <p className="text-gray-500 line-through">{result.seleniumData.originalPrice} ₽</p>
                    )}
                    {result.seleniumData.discount > 0 && (
                      <p className="text-red-500">-{result.seleniumData.discount}%</p>
                    )}
                    <p className="text-sm mt-1">Время: {result.seleniumData.executionTime.toFixed(2)} сек.</p>
                  </div>
                </div>
              </>
            ) : (
              <p className="text-red-500">{result.seleniumData.error || 'Ошибка парсинга'}</p>
            )}
          </div>
          
          <div className="bg-gray-100 dark:bg-gray-800 rounded-lg p-4">
            <h3 className="text-lg font-semibold mb-2">Playwright Parser</h3>
            {result.playwrightData.success ? (
              <>
                <div className="flex mb-2">
                  {result.playwrightData.imageUrl && (
                    <img src={result.playwrightData.imageUrl} alt={result.playwrightData.name} className="w-20 h-20 object-contain mr-4" />
                  )}
                  <div>
                    <p className="font-medium">{result.playwrightData.name}</p>
                    <p className="text-green-600 dark:text-green-400 font-bold">{result.playwrightData.price} ₽</p>
                    {result.playwrightData.originalPrice > 0 && result.playwrightData.originalPrice !== result.playwrightData.price && (
                      <p className="text-gray-500 line-through">{result.playwrightData.originalPrice} ₽</p>
                    )}
                    {result.playwrightData.discount > 0 && (
                      <p className="text-red-500">-{result.playwrightData.discount}%</p>
                    )}
                    <p className="text-sm mt-1">Время: {result.playwrightData.executionTime.toFixed(2)} сек.</p>
                  </div>
                </div>
              </>
            ) : (
              <p className="text-red-500">{result.playwrightData.error || 'Ошибка парсинга'}</p>
            )}
          </div>
          
          {result.comparison && (
            <div className="md:col-span-2 bg-blue-50 dark:bg-blue-900 rounded-lg p-4">
              <h3 className="text-lg font-semibold mb-2">Сравнение парсеров</h3>
              <p>Быстрее работает: <span className="font-bold">{result.comparison.fasterMethod}</span> (на {result.comparison.timeDifference} сек.)</p>
              
              {result.comparison.bothSuccessful ? (
                <p>
                  Разница в цене: {result.comparison.priceDifference === 0 ? (
                    <span className="text-green-500">нет различий</span>
                  ) : (
                    <span className="text-yellow-500">{result.comparison.priceDifference} ₽</span>
                  )}
                </p>
              ) : (
                <p className="text-red-500">Невозможно сравнить цены: один из парсеров завершился с ошибкой</p>
              )}
            </div>
          )}
        </div>
      );
    }
    
    // Для отдельных парсеров (selenium или playwright)
    const data = result.data;
    if (!data) return <p className="text-red-500">Нет данных о товаре</p>;
    
    return (
      <div className="bg-gray-100 dark:bg-gray-800 rounded-lg p-4 mt-4">
        <h3 className="text-lg font-semibold mb-2">{selectedParser === 'selenium' ? 'Selenium' : 'Playwright'} Parser</h3>
        <div className="flex mb-2">
          {data.imageUrl && (
            <img src={data.imageUrl} alt={data.name} className="w-20 h-20 object-contain mr-4" />
          )}
          <div>
            <p className="font-medium">{data.name}</p>
            <p className="text-green-600 dark:text-green-400 font-bold">{data.price} ₽</p>
            {data.originalPrice && data.originalPrice > 0 && data.originalPrice !== data.price && (
              <p className="text-gray-500 line-through">{data.originalPrice} ₽</p>
            )}
            {data.discount && data.discount > 0 && (
              <p className="text-red-500">-{data.discount}%</p>
            )}
            {data.executionTime && (
              <p className="text-sm mt-1">Время выполнения: {data.executionTime.toFixed(2)} сек.</p>
            )}
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="bg-white dark:bg-gray-900 rounded-lg shadow-sm p-6">
      <h2 className="text-xl font-bold mb-4">Тестирование парсеров маркетплейсов</h2>
      
      <div className="mb-4">
        <div className="flex flex-wrap gap-2 mb-4">
          <Button 
            variant={selectedParser === 'selenium' ? 'primary' : 'secondary'} 
            onClick={() => handleParserChange('selenium')}
            size="small"
          >
            Selenium Parser
          </Button>
          <Button 
            variant={selectedParser === 'playwright' ? 'primary' : 'secondary'} 
            onClick={() => handleParserChange('playwright')}
            size="small"
          >
            Playwright Parser
          </Button>
          <Button 
            variant={selectedParser === 'compare' ? 'primary' : 'secondary'} 
            onClick={() => handleParserChange('compare')}
            size="small"
          >
            Сравнить оба
          </Button>
        </div>
        
        <form onSubmit={handleSubmit}>
          <div className="flex flex-col md:flex-row gap-2">
            <input
              type="text"
              value={url}
              onChange={handleUrlChange}
              placeholder="Введите URL товара (Ozon, Wildberries, AliExpress)"
              className="border border-gray-300 dark:border-gray-600 dark:bg-gray-800 rounded-md px-4 py-2 flex-grow"
            />
            <Button 
              type="submit" 
              variant="primary" 
              isLoading={isLoading}
            >
              {isLoading ? 'Обработка...' : 'Проверить'}
            </Button>
          </div>
        </form>
        
        {error && (
          <p className="text-red-500 mt-2">{error}</p>
        )}
      </div>
      
      {renderParserResult()}
      
      <div className="mt-6 text-sm text-gray-500 dark:text-gray-400">
        <p>Поддерживаемые маркетплейсы: Ozon, Wildberries, AliExpress</p>
        <p className="mt-1">Пример URL: https://www.ozon.ru/product/smartfon-xiaomi-redmi-12-8-256gb-graphite-gray-global-version-1171511903/</p>
      </div>
    </div>
  );
};

export default ParserTester; 