import React from 'react';
import { ErrorBoundary as ReactErrorBoundary } from 'react-error-boundary';
import styled from 'styled-components';
import { motion } from 'framer-motion';

const ErrorContainer = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  height: 100vh;
  padding: 2rem;
  text-align: center;
  background: ${({ theme }) => theme.colors.background};
`;

const ErrorIcon = styled.div`
  font-size: 5rem;
  margin-bottom: 2rem;
  color: ${({ theme }) => theme.colors.error};
`;

const ErrorTitle = styled.h1`
  font-size: 2rem;
  margin-bottom: 1rem;
  color: ${({ theme }) => theme.colors.text};
`;

const ErrorMessage = styled.p`
  font-size: 1.1rem;
  margin-bottom: 2rem;
  max-width: 600px;
  color: ${({ theme }) => theme.colors.textSecondary};
`;

const ResetButton = styled(motion.button)`
  padding: 0.75rem 1.5rem;
  background: linear-gradient(90deg, ${({ theme }) => theme.colors.primary}, ${({ theme }) => theme.colors.secondary});
  color: white;
  border: none;
  border-radius: ${({ theme }) => theme.borderRadius.medium};
  font-size: 1rem;
  font-weight: 600;
  cursor: pointer;
  box-shadow: ${({ theme }) => theme.shadows.medium};
`;

const ErrorFallback = ({ error, resetErrorBoundary }: { error: Error; resetErrorBoundary: () => void }) => {
  return (
    <ErrorContainer>
      <ErrorIcon>💥</ErrorIcon>
      <ErrorTitle>Что-то пошло не так</ErrorTitle>
      <ErrorMessage>
        Приносим извинения, в работе приложения произошла ошибка. Наша команда уже работает над исправлением.
      </ErrorMessage>
      <details style={{ marginBottom: '1.5rem', color: '#666' }}>
        <summary>Технические детали</summary>
        <pre style={{ 
          marginTop: '1rem', 
          padding: '1rem', 
          background: '#f5f5f5', 
          borderRadius: '8px', 
          overflow: 'auto',
          maxWidth: '100%', 
          textAlign: 'left' 
        }}>
          {error.message}
          {error.stack}
        </pre>
      </details>
      <ResetButton 
        onClick={resetErrorBoundary}
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
      >
        Попробовать снова
      </ResetButton>
    </ErrorContainer>
  );
};

export const AppErrorBoundary: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const handleReset = () => {
    // Можно добавить дополнительные действия при сбросе ошибки
    console.log('Ошибка сброшена');
  };

  return (
    <ReactErrorBoundary FallbackComponent={ErrorFallback} onReset={handleReset}>
      {children}
    </ReactErrorBoundary>
  );
};

export default AppErrorBoundary; 