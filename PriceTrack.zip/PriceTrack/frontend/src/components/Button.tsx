import React from 'react';
import styled, { css } from 'styled-components';
import { motion } from 'framer-motion';

export type ButtonVariant = 'primary' | 'secondary' | 'outline' | 'text' | 'danger' | 'success';
export type ButtonSize = 'small' | 'medium' | 'large';

export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: ButtonVariant;
  size?: ButtonSize;
  isLoading?: boolean;
  icon?: React.ReactNode;
  iconPosition?: 'left' | 'right';
  fullWidth?: boolean;
}

const getSizeStyles = (size: ButtonSize) => {
  switch (size) {
    case 'small':
      return css`
        padding: 0.5rem 1rem;
        font-size: 0.875rem;
      `;
    case 'large':
      return css`
        padding: 0.875rem 1.5rem;
        font-size: 1.125rem;
      `;
    case 'medium':
    default:
      return css`
        padding: 0.75rem 1.25rem;
        font-size: 1rem;
      `;
  }
};

const getVariantStyles = (variant: ButtonVariant) => {
  switch (variant) {
    case 'secondary':
      return css`
        background: linear-gradient(90deg, ${({ theme }) => theme.colors.secondary}, ${({ theme }) => theme.colors.secondaryLight});
        color: white;
        border: none;
        
        &:hover:not(:disabled) {
          background: linear-gradient(90deg, ${({ theme }) => theme.colors.secondary}, ${({ theme }) => theme.colors.secondary});
          box-shadow: 0 4px 8px ${({ theme }) => theme.colors.secondary}50;
        }
        
        &:disabled {
          background: ${({ theme }) => theme.colors.backgroundDisabled};
          color: ${({ theme }) => theme.colors.textTertiary};
        }
      `;
    case 'outline':
      return css`
        background: transparent;
        color: ${({ theme }) => theme.colors.primary};
        border: 2px solid ${({ theme }) => theme.colors.primary};
        
        &:hover:not(:disabled) {
          background: ${({ theme }) => theme.colors.primary}10;
        }
        
        &:disabled {
          border-color: ${({ theme }) => theme.colors.backgroundDisabled};
          color: ${({ theme }) => theme.colors.textTertiary};
        }
      `;
    case 'text':
      return css`
        background: transparent;
        color: ${({ theme }) => theme.colors.primary};
        border: none;
        padding-left: 0.5rem;
        padding-right: 0.5rem;
        
        &:hover:not(:disabled) {
          background: ${({ theme }) => theme.colors.primary}10;
        }
        
        &:disabled {
          color: ${({ theme }) => theme.colors.textTertiary};
        }
      `;
    case 'danger':
      return css`
        background: linear-gradient(90deg, ${({ theme }) => theme.colors.error}, ${({ theme }) => theme.colors.error}DD);
        color: white;
        border: none;
        
        &:hover:not(:disabled) {
          background: ${({ theme }) => theme.colors.error};
          box-shadow: 0 4px 8px ${({ theme }) => theme.colors.error}50;
        }
        
        &:disabled {
          background: ${({ theme }) => theme.colors.backgroundDisabled};
          color: ${({ theme }) => theme.colors.textTertiary};
        }
      `;
    case 'success':
      return css`
        background: linear-gradient(90deg, ${({ theme }) => theme.colors.success}, ${({ theme }) => theme.colors.success}DD);
        color: white;
        border: none;
        
        &:hover:not(:disabled) {
          background: ${({ theme }) => theme.colors.success};
          box-shadow: 0 4px 8px ${({ theme }) => theme.colors.success}50;
        }
        
        &:disabled {
          background: ${({ theme }) => theme.colors.backgroundDisabled};
          color: ${({ theme }) => theme.colors.textTertiary};
        }
      `;
    case 'primary':
    default:
      return css`
        background: linear-gradient(90deg, ${({ theme }) => theme.colors.primary}, ${({ theme }) => theme.colors.secondary});
        color: white;
        border: none;
        
        &:hover:not(:disabled) {
          background: linear-gradient(90deg, ${({ theme }) => theme.colors.primary}, ${({ theme }) => theme.colors.primary});
          box-shadow: 0 4px 8px ${({ theme }) => theme.colors.primary}50;
        }
        
        &:disabled {
          background: ${({ theme }) => theme.colors.backgroundDisabled};
          color: ${({ theme }) => theme.colors.textTertiary};
        }
      `;
  }
};

const StyledButton = styled(motion.button)<ButtonProps>`
  ${({ size = 'medium' }) => getSizeStyles(size)};
  ${({ variant = 'primary' }) => getVariantStyles(variant)};
  
  display: inline-flex;
  align-items: center;
  justify-content: center;
  font-weight: 500;
  border-radius: ${({ theme }) => theme.borderRadius.medium};
  transition: all 0.2s ease;
  cursor: pointer;
  outline: none;
  position: relative;
  overflow: hidden;
  width: ${({ fullWidth }) => (fullWidth ? '100%' : 'auto')};
  
  &:disabled {
    cursor: not-allowed;
    opacity: 0.7;
  }
  
  .icon-left {
    margin-right: 0.5rem;
  }
  
  .icon-right {
    margin-left: 0.5rem;
  }
`;

const LoadingSpinner = styled.div`
  width: 16px;
  height: 16px;
  border: 2px solid rgba(255, 255, 255, 0.3);
  border-radius: 50%;
  border-top-color: #fff;
  animation: spin 0.8s linear infinite;
  margin-right: 8px;
  
  @keyframes spin {
    to {
      transform: rotate(360deg);
    }
  }
`;

const Button: React.FC<ButtonProps> = ({
  children,
  variant = 'primary',
  size = 'medium',
  isLoading = false,
  icon,
  iconPosition = 'left',
  fullWidth = false,
  disabled,
  ...props
}) => {
  return (
    <StyledButton
      variant={variant}
      size={size}
      fullWidth={fullWidth}
      disabled={disabled || isLoading}
      whileHover={!disabled && !isLoading ? { scale: 1.03 } : {}}
      whileTap={!disabled && !isLoading ? { scale: 0.98 } : {}}
      {...props}
    >
      {isLoading && <LoadingSpinner />}
      {!isLoading && icon && iconPosition === 'left' && <span className="icon-left">{icon}</span>}
      {children}
      {!isLoading && icon && iconPosition === 'right' && <span className="icon-right">{icon}</span>}
    </StyledButton>
  );
};

export default Button; 