import React from 'react';
import styled from 'styled-components';

// Логотипы маркетплейсов
const MARKETPLACE_LOGOS = {
  'Ozon': '/images/logos/ozon.png',
  'Wildberries': '/images/logos/wildberries.png',
  'AliExpress': '/images/logos/aliexpress.png',
  'Amazon': '/images/logos/amazon.png'
};

// SVG логотипы для запасного варианта
const SVG_LOGOS = {
  'Ozon': `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 24" fill="#005bff"><path d="M24.14 0a12 12 0 1 0 0 24 12 12 0 0 0 0-24zm0 17.3a5.3 5.3 0 1 1 0-10.6 5.3 5.3 0 0 1 0 10.6z"/></svg>`,
  'Wildberries': `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 24" fill="#cb11ab"><path d="M6,12c0-7.8,9-9.6,18-9.6s18,1.8,18,9.6c0,7.8-9,9.6-18,9.6S6,19.8,6,12z M18.5,12a5.5,5.5 0 1,0 11,0a5.5,5.5 0 1,0 -11,0"/></svg>`,
  'AliExpress': `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 24" fill="#ff4747"><path d="M8.8,10l1.6-6h3.2l-1.6,6H8.8z M14,10l1.6-6h7.2l-0.4,1.5h-4l-0.3,1h3.8l-0.4,1.5h-3.8l-0.3,1h4l-0.4,1.5 L14,10z M23.6,10V4h6l-0.4,1.5h-2.4V10H23.6z M33.2,10l-1.3-2.9L30.9,10h-3l3-6h3.4l2.9,6H33.2z"/></svg>`,
};

const LogoContainer = styled.div<{ size?: number }>`
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: ${props => props.size || 24}px;
  height: ${props => props.size || 24}px;
  margin-right: 8px;
  
  img {
    max-width: 100%;
    max-height: 100%;
  }
`;

// Элемент замены для случаев, когда логотип не загружается
const PlaceholderLogo = styled.div<{ size?: number, bg?: string }>`
  width: ${props => props.size || 24}px;
  height: ${props => props.size || 24}px;
  border-radius: 50%;
  background-color: ${props => props.bg || '#f0f0f0'};
  display: flex;
  align-items: center;
  justify-content: center;
  font-weight: bold;
  font-size: ${props => (props.size ? props.size / 2 : 12)}px;
  color: white;
`;

// Элемент замены для логотипов
const getPlaceholderForMarketplace = (marketplace: string, size?: number) => {
  const name = marketplace || 'Unknown';
  const initial = name.charAt(0).toUpperCase();
  
  let bgColor = '#999';
  if (name.toLowerCase().includes('ozon')) bgColor = '#005bff';
  if (name.toLowerCase().includes('wildberries')) bgColor = '#cb11ab';
  if (name.toLowerCase().includes('aliexpress')) bgColor = '#ff4747';
  
  return (
    <PlaceholderLogo size={size} bg={bgColor}>
      {initial}
    </PlaceholderLogo>
  );
};

interface MarketplaceLogoProps {
  marketplace: string;
  size?: number;
}

const MarketplaceLogo: React.FC<MarketplaceLogoProps> = ({ marketplace, size = 24 }) => {
  const [imageError, setImageError] = React.useState(false);

  if (!marketplace || imageError) {
    return (
      <LogoContainer size={size}>
        {getPlaceholderForMarketplace(marketplace, size)}
      </LogoContainer>
    );
  }

  const handleImageError = () => {
    setImageError(true);
  };

  // Используем встроенные Base64 закодированные изображения вместо файлов
  let logoSrc = '';
  if (marketplace.toLowerCase().includes('ozon')) {
    logoSrc = 'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyNCAyNCIgZmlsbD0iIzAwNWJmZiI+PHBhdGggZD0iTTEyIDJDNi40NzcgMiAyIDYuNDc3IDIgMTJTNi40NzcgMjIgMTIgMjJTMjIgMTcuNTIzIDIyIDEyUzE3LjUyMyAyIDEyIDJabTAgMy4zODlDMTUuNjQ1IDUuMzg5IDE4LjYxMSA4LjM1NSAxOC42MTEgMTJTMTUuNjQ1IDE4LjYxMSAxMiAxOC42MTFDOC4zNTUgMTguNjExIDUuMzg5IDE1LjY0NSA1LjM4OSAxMlM4LjM1NSA1LjM4OSAxMiA1LjM4OVoiLz48L3N2Zz4=';
  } else if (marketplace.toLowerCase().includes('wildberries')) {
    logoSrc = 'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyNCAyNCIgZmlsbD0iI2NiMTFhYiI+PHBhdGggZD0iTTE5IDNINUMzLjkgMyAzIDMuOSAzIDVWMTlDMyAyMC4xIDMuOSAyMSA1IDIxSDE5QzIwLjEgMjEgMjEgMjAuMSAyMSAxOVY1QzIxIDMuOSAyMC4xIDMgMTkgM1pNMTUgMTFDMTQgMTEgMTMuMiAxMC41IDEyLjkgOS43TDEyIDdMMTEuMSA5LjdDMTAuOCAxMC41IDEwIDExIDkgMTFINlY3SDE5VjE3SDVWMTFIMTVaIi8+PC9zdmc+';
  } else if (marketplace.toLowerCase().includes('aliexpress')) {
    logoSrc = 'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyNCAyNCIgZmlsbD0iI2ZmNDc0NyI+PHBhdGggZD0iTTIxIDRIM0MyIDQgMSA1IDEgNlYxOEMxIDE5IDIgMjAgMyAyMEgyMUMyMiAyMCAyMyAxOSAyMyAxOFY2QzIzIDUgMjIgNCAyMSA0Wk0xOCA4LjVDMTcuNTk4IDguNSAxNy4yMSA4LjY1NiAxNi45MzkgOC45MjdDMTYuNjY5IDkuMTk3IDE2LjUxMiA5LjU4NiAxNi41MTIgOS45ODdDMTYuNTEyIDEwLjM4OSAxNi42NjkgMTAuNzc3IDE2LjkzOSAxMS4wNDhDMTcuMjEgMTEuMzE5IDE3LjU5OCAxMS40NzUgMTggMTEuNDc1QzE4LjQwMiAxMS40NzUgMTguNzkgMTEuMzE5IDE5LjA2MSAxMS4wNDhDMTkuMzMxIDEwLjc3NyAxOS40ODggMTAuMzg5IDE5LjQ4OCA5Ljk4N0MxOS40ODggOS41ODYgMTkuMzMxIDkuMTk3IDE5LjA2MSA4LjkyN0MxOC43OSA4LjY1NiAxOC40MDIgOC41IDE4IDguNVpNNi43NSAxMkwxMCAxNS4yNUwxNy4yNSA4TDE5IDkuNzVMOS45OTkgMTguNzVMNSAxMy43NUw2Ljc1IDEyWiIvPjwvc3ZnPg==';
  } else {
    return (
      <LogoContainer size={size}>
        {getPlaceholderForMarketplace(marketplace, size)}
      </LogoContainer>
    );
  }

  return (
    <LogoContainer size={size}>
      <img 
        src={logoSrc}
        alt={`${marketplace} logo`}
        onError={handleImageError}
        width={size}
        height={size}
      />
    </LogoContainer>
  );
};

export default MarketplaceLogo; 