import React from 'react';
import styled, { css } from 'styled-components';
import { motion } from 'framer-motion';

export type CardVariant = 'default' | 'outlined' | 'elevated';

export interface CardProps {
  variant?: CardVariant;
  padding?: string;
  radius?: string;
  children: React.ReactNode;
  onClick?: () => void;
  className?: string;
  hoverEffect?: boolean;
  fullWidth?: boolean;
}

const getVariantStyles = (variant: CardVariant) => {
  switch (variant) {
    case 'outlined':
      return css`
        background-color: transparent;
        border: 1px solid ${({ theme }) => theme.colors.border};
        box-shadow: none;
      `;
    case 'elevated':
      return css`
        background-color: ${({ theme }) => theme.colors.cardBackground};
        border: none;
        box-shadow: ${({ theme }) => theme.shadows.medium};
      `;
    case 'default':
    default:
      return css`
        background-color: ${({ theme }) => theme.colors.cardBackground};
        border: 1px solid ${({ theme }) => theme.colors.border};
        box-shadow: ${({ theme }) => theme.shadows.small};
      `;
  }
};

const CardContainer = styled(motion.div)<{
  variant: CardVariant;
  $padding: string;
  $radius: string;
  $hoverEffect: boolean;
  $fullWidth: boolean;
}>`
  ${({ variant }) => getVariantStyles(variant)};
  padding: ${({ $padding }) => $padding};
  border-radius: ${({ $radius }) => $radius};
  width: ${({ $fullWidth }) => ($fullWidth ? '100%' : 'auto')};
  transition: transform 0.2s ease, box-shadow 0.2s ease;
  position: relative;
  overflow: hidden;
  
  ${({ $hoverEffect, theme }) =>
    $hoverEffect &&
    css`
      cursor: pointer;
      
      &:hover {
        transform: translateY(-4px);
        box-shadow: ${theme.shadows.medium};
      }
      
      &:active {
        transform: translateY(-2px);
      }
    `}
  
  &::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 3px;
    background: linear-gradient(90deg, ${({ theme }) => theme.colors.primary}, ${({ theme }) => theme.colors.secondary});
    opacity: 0;
    transition: opacity 0.2s ease;
  }
  
  &:hover::before {
    opacity: ${({ $hoverEffect }) => ($hoverEffect ? 1 : 0)};
  }
`;

const Card: React.FC<CardProps> = ({
  variant = 'default',
  padding = '1.5rem',
  radius = '16px',
  children,
  onClick,
  className,
  hoverEffect = false,
  fullWidth = false,
}) => {
  return (
    <CardContainer
      variant={variant}
      $padding={padding}
      $radius={radius}
      $hoverEffect={hoverEffect}
      $fullWidth={fullWidth}
      onClick={onClick}
      className={className}
      whileHover={hoverEffect ? { scale: 1.02 } : {}}
      whileTap={hoverEffect ? { scale: 0.98 } : {}}
    >
      {children}
    </CardContainer>
  );
};

// Вспомогательные компоненты для Card
export const CardHeader = styled.div`
  margin-bottom: 1.25rem;
`;

export const CardTitle = styled.h3`
  font-size: 1.25rem;
  margin: 0 0 0.5rem;
  color: ${({ theme }) => theme.colors.text};
  font-weight: 600;
`;

export const CardSubtitle = styled.p`
  font-size: 0.9rem;
  margin: 0;
  color: ${({ theme }) => theme.colors.textSecondary};
`;

export const CardContent = styled.div`
  color: ${({ theme }) => theme.colors.textSecondary};
`;

export const CardFooter = styled.div`
  margin-top: 1.5rem;
  display: flex;
  justify-content: space-between;
  align-items: center;
  border-top: 1px solid ${({ theme }) => theme.colors.border};
  padding-top: 1.25rem;
`;

export default Card; 