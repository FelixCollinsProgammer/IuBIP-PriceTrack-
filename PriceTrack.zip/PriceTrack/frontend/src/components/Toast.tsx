import React, { useState, useEffect } from 'react';
import styled, { keyframes, css } from 'styled-components';
import { motion, AnimatePresence } from 'framer-motion';

export type ToastType = 'success' | 'error' | 'warning' | 'info';

export interface ToastProps {
  id: string;
  type: ToastType;
  message: string;
  duration?: number;
  onClose: (id: string) => void;
}

interface StyledToastProps {
  type: ToastType;
}

const slideIn = keyframes`
  from {
    transform: translateX(100%);
    opacity: 0;
  }
  to {
    transform: translateX(0);
    opacity: 1;
  }
`;

const slideOut = keyframes`
  from {
    transform: translateX(0);
    opacity: 1;
  }
  to {
    transform: translateX(100%);
    opacity: 0;
  }
`;

const ToastContainer = styled(motion.div)<StyledToastProps>`
  display: flex;
  align-items: center;
  min-width: 300px;
  max-width: 450px;
  margin-bottom: 1rem;
  padding: 1rem 1.25rem;
  border-radius: ${({ theme }) => theme.borderRadius.medium};
  box-shadow: ${({ theme }) => theme.shadows.medium};
  background: ${({ theme, type }) => {
    switch (type) {
      case 'success':
        return `linear-gradient(90deg, ${theme.colors.success}15, ${theme.colors.success}05)`;
      case 'error':
        return `linear-gradient(90deg, ${theme.colors.error}15, ${theme.colors.error}05)`;
      case 'warning':
        return `linear-gradient(90deg, ${theme.colors.warning}15, ${theme.colors.warning}05)`;
      case 'info':
        return `linear-gradient(90deg, ${theme.colors.info}15, ${theme.colors.info}05)`;
      default:
        return theme.colors.cardBackground;
    }
  }};
  border-left: 4px solid ${({ theme, type }) => {
    switch (type) {
      case 'success':
        return theme.colors.success;
      case 'error':
        return theme.colors.error;
      case 'warning':
        return theme.colors.warning;
      case 'info':
        return theme.colors.info;
      default:
        return theme.colors.primary;
    }
  }};
  animation: ${slideIn} 0.3s forwards;
  position: relative;
  
  &.exit {
    animation: ${slideOut} 0.3s forwards;
  }
`;

const IconContainer = styled.div<StyledToastProps>`
  margin-right: 1rem;
  font-size: 1.5rem;
  color: ${({ theme, type }) => {
    switch (type) {
      case 'success':
        return theme.colors.success;
      case 'error':
        return theme.colors.error;
      case 'warning':
        return theme.colors.warning;
      case 'info':
        return theme.colors.info;
      default:
        return theme.colors.primary;
    }
  }};
`;

const Content = styled.div`
  flex: 1;
`;

const Message = styled.div`
  font-size: 0.95rem;
  color: ${({ theme }) => theme.colors.text};
  line-height: 1.4;
`;

const CloseButton = styled.button`
  background: none;
  border: none;
  color: ${({ theme }) => theme.colors.textTertiary};
  font-size: 1.2rem;
  cursor: pointer;
  padding: 0.25rem;
  margin-left: 0.5rem;
  opacity: 0.7;
  transition: opacity 0.2s, transform 0.2s;
  
  &:hover {
    opacity: 1;
    transform: scale(1.1);
  }
`;

const ProgressBar = styled.div<{ duration: number, type: ToastType }>`
  position: absolute;
  bottom: 0;
  left: 0;
  height: 3px;
  background-color: ${({ theme, type }) => {
    switch (type) {
      case 'success':
        return theme.colors.success;
      case 'error':
        return theme.colors.error;
      case 'warning':
        return theme.colors.warning;
      case 'info':
        return theme.colors.info;
      default:
        return theme.colors.primary;
    }
  }};
  animation: shrink ${({ duration }) => duration}ms linear forwards;
  
  @keyframes shrink {
    from {
      width: 100%;
    }
    to {
      width: 0%;
    }
  }
`;

const getIcon = (type: ToastType): string => {
  switch (type) {
    case 'success':
      return '✅';
    case 'error':
      return '❌';
    case 'warning':
      return '⚠️';
    case 'info':
      return 'ℹ️';
    default:
      return 'ℹ️';
  }
};

const Toast: React.FC<ToastProps> = ({ 
  id, 
  type, 
  message, 
  duration = 5000, 
  onClose 
}) => {
  const [isExiting, setIsExiting] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsExiting(true);
      setTimeout(() => onClose(id), 300); // Wait for exit animation
    }, duration);

    return () => clearTimeout(timer);
  }, [id, duration, onClose]);

  return (
    <ToastContainer 
      type={type} 
      className={isExiting ? 'exit' : ''}
      initial={{ opacity: 0, x: 100 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: 100 }}
    >
      <IconContainer type={type}>
        {getIcon(type)}
      </IconContainer>
      <Content>
        <Message>{message}</Message>
      </Content>
      <CloseButton onClick={() => {
        setIsExiting(true);
        setTimeout(() => onClose(id), 300);
      }}>
        ×
      </CloseButton>
      <ProgressBar duration={duration} type={type} />
    </ToastContainer>
  );
};

export default Toast;

// Контейнер для уведомлений
export const ToastContainer = styled.div`
  position: fixed;
  top: 20px;
  right: 20px;
  z-index: 9999;
  display: flex;
  flex-direction: column;
  align-items: flex-end;
`; 