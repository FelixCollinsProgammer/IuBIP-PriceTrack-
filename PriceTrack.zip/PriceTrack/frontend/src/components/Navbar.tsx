import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import styled from 'styled-components';
import { motion } from 'framer-motion';

interface NavbarProps {
  onThemeToggle: () => void;
  isDark: boolean;
}

const Nav = styled.nav`
  background: ${({ theme }) => theme.colors.background};
  padding: 1rem 0;
  box-shadow: ${({ theme }) => theme.shadows.small};
  position: sticky;
  top: 0;
  z-index: 100;
  backdrop-filter: blur(10px);
  border-bottom: 1px solid ${({ theme }) => theme.colors.border};
`;

const Container = styled.div`
  max-width: 1200px;
  margin: 0 auto;
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0 1.5rem;
`;

const Logo = styled(Link)`
  color: ${({ theme }) => theme.colors.primary};
  font-size: 1.75rem;
  font-weight: bold;
  text-decoration: none;
  display: flex;
  align-items: center;
  
  span {
    background: linear-gradient(90deg, ${({ theme }) => theme.colors.primary}, ${({ theme }) => theme.colors.secondary});
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
  }
`;

const LogoIcon = styled.div`
  margin-right: 0.5rem;
  font-size: 1.75rem;
`;

const NavLinks = styled.div`
  display: flex;
  gap: 1.5rem;
  align-items: center;
`;

const NavLink = styled(Link)<{ active: boolean }>`
  color: ${({ theme, active }) =>
    active ? theme.colors.primary : theme.colors.text};
  text-decoration: none;
  font-weight: ${({ active }) => (active ? '600' : '400')};
  position: relative;
  padding: 0.5rem 0.25rem;
  transition: all ${({ theme }) => theme.transitions.default};

  &::after {
    content: '';
    position: absolute;
    bottom: 0;
    left: 0;
    width: 100%;
    height: 2px;
    background: linear-gradient(90deg, ${({ theme }) => theme.colors.primary}, ${({ theme }) => theme.colors.secondary});
    transform: scaleX(${({ active }) => (active ? 1 : 0)});
    transition: transform ${({ theme }) => theme.transitions.default};
    border-radius: 2px;
  }

  &:hover {
    color: ${({ theme }) => theme.colors.primary};
  }

  &:hover::after {
    transform: scaleX(1);
  }
`;

const ThemeToggle = styled(motion.button)`
  color: ${({ theme }) => theme.colors.text};
  background: ${({ theme }) => theme.colors.surfaceAlt};
  padding: 0.75rem;
  border-radius: 50%;
  cursor: pointer;
  transition: all ${({ theme }) => theme.transitions.default};
  border: none;
  margin-left: 0.5rem;
  display: flex;
  align-items: center;
  justify-content: center;

  &:hover {
    background: ${({ theme }) => theme.colors.primary};
    color: white;
    transform: translateY(-2px);
  }
`;

const ProfileButton = styled(Link)`
  background: linear-gradient(90deg, ${({ theme }) => theme.colors.primary}, ${({ theme }) => theme.colors.secondary});
  color: white;
  padding: 0.5rem 1rem;
  border-radius: ${({ theme }) => theme.borderRadius.medium};
  text-decoration: none;
  font-weight: 500;
  display: flex;
  align-items: center;
  gap: 0.5rem;
  transition: all ${({ theme }) => theme.transitions.default};
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
  
  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
  }
`;

const MobileMenuButton = styled.button`
  display: none;
  background: none;
  border: none;
  color: ${({ theme }) => theme.colors.text};
  font-size: 1.5rem;
  cursor: pointer;
  
  @media (max-width: 768px) {
    display: block;
  }
`;

const DesktopNav = styled.div`
  display: flex;
  align-items: center;
  
  @media (max-width: 768px) {
    display: none;
  }
`;

const Navbar: React.FC<NavbarProps> = ({ onThemeToggle, isDark }) => {
  const location = useLocation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  return (
    <Nav>
      <Container>
        <Logo to="/">
          <LogoIcon>📊</LogoIcon>
          <span>PriceTrack</span>
        </Logo>
        
        <MobileMenuButton onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}>
          {isMobileMenuOpen ? '✕' : '☰'}
        </MobileMenuButton>
        
        <DesktopNav>
          <NavLinks>
            <NavLink to="/" active={location.pathname === '/'}>
              Главная
            </NavLink>
            <NavLink to="/products" active={location.pathname === '/products'}>
              Товары
            </NavLink>
            <NavLink to="/categories" active={location.pathname === '/categories'}>
              Категории
            </NavLink>
            <NavLink to="/analytics" active={location.pathname === '/analytics'}>
              Аналитика
            </NavLink>
            <NavLink to="/parsers" active={location.pathname === '/parsers'}>
              Парсеры
            </NavLink>
            <NavLink to="/contact" active={location.pathname === '/contact'}>
              Контакты
            </NavLink>
            <ProfileButton to="/profile">
              <span>👤</span> Профиль
            </ProfileButton>
            <ThemeToggle 
              onClick={onThemeToggle}
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
            >
              {isDark ? '🌞' : '🌙'}
            </ThemeToggle>
          </NavLinks>
        </DesktopNav>
      </Container>
    </Nav>
  );
};

export default Navbar; 