import React, { useState, useEffect, ReactNode } from 'react';
import styled from 'styled-components';
import axios from 'axios';

// Стили для компонента авторизации
const AuthContainer = styled.div`
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  z-index: 1000;
`;

const AuthBanner = styled.div`
  background-color: ${props => props.theme.colors.primary};
  color: white;
  text-align: center;
  padding: 8px 16px;
  display: flex;
  justify-content: space-between;
  align-items: center;
`;

const CloseButton = styled.button`
  background: none;
  border: none;
  color: white;
  font-size: 16px;
  cursor: pointer;
  opacity: 0.8;
  &:hover {
    opacity: 1;
  }
`;

interface AuthWrapperProps {
  children: ReactNode;
}

const AuthWrapper: React.FC<AuthWrapperProps> = ({ children }) => {
  const [showAuthError, setShowAuthError] = useState(false);
  
  // Перехватываем ошибки авторизации
  useEffect(() => {
    // Автоматическая авторизация при запуске
    console.log('Initializing auto-authentication');
    const demoToken = 'demo-token';
    localStorage.setItem('auth_token', demoToken);
    
    // Добавляем interceptor для автоматической авторизации
    const interceptor = axios.interceptors.response.use(
      response => response,
      error => {
        if (error.response && error.response.status === 401) {
          console.log('Автоматическая авторизация...');
          // Устанавливаем флаг для показа баннера
          setShowAuthError(true);
          
          // Создаем демо-токен для авторизации
          localStorage.setItem('auth_token', demoToken);
          
          // Переотправляем запрос с токеном
          const originalRequest = error.config;
          if (!originalRequest._retry) {
            originalRequest._retry = true;
            originalRequest.headers.Authorization = `Bearer ${demoToken}`;
            return axios(originalRequest);
          }
        }
        return Promise.reject(error);
      }
    );
    
    // Очистка interceptor при размонтировании
    return () => {
      axios.interceptors.response.eject(interceptor);
    };
  }, []);
  
  return (
    <>
      {showAuthError && (
        <AuthContainer>
          <AuthBanner>
            <div>Ошибка аутентификации. Выполнен автоматический вход в систему.</div>
            <CloseButton onClick={() => setShowAuthError(false)}>✕</CloseButton>
          </AuthBanner>
        </AuthContainer>
      )}
      {children}
    </>
  );
};

export default AuthWrapper; 