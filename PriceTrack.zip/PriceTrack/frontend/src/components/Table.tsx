import React from 'react';
import styled from 'styled-components';
import Loading from './Loading';

interface TableColumn<T> {
  key: keyof T | 'actions';
  title: string;
  render?: (item: T, index: number) => React.ReactNode;
  width?: string;
}

interface TableProps<T> {
  columns: TableColumn<T>[];
  data: T[];
  isLoading?: boolean;
  emptyMessage?: string;
  keyExtractor?: (item: T, index: number) => string;
  onRowClick?: (item: T) => void;
}

const TableContainer = styled.div`
  width: 100%;
  overflow-x: auto;
  background: ${({ theme }) => theme.colors.cardBackground};
  border-radius: ${({ theme }) => theme.borderRadius.medium};
  box-shadow: ${({ theme }) => theme.shadows.sm};
  margin-bottom: 2rem;
`;

const StyledTable = styled.table`
  width: 100%;
  border-collapse: collapse;
`;

const TableHeader = styled.thead`
  background: ${({ theme }) => theme.colors.backgroundSecondary};
  
  th {
    text-align: left;
    padding: 1rem;
    font-weight: 600;
    color: ${({ theme }) => theme.colors.textSecondary};
    font-size: 0.9rem;
    text-transform: uppercase;
    letter-spacing: 0.03em;
    border-bottom: 1px solid ${({ theme }) => theme.colors.border};
  }
`;

const TableBody = styled.tbody`
  tr {
    transition: background-color 0.2s ease;
    border-bottom: 1px solid ${({ theme }) => theme.colors.border};
    
    &:last-child {
      border-bottom: none;
    }
    
    &:hover {
      background-color: ${({ theme }) => theme.colors.backgroundHover};
    }
  }
  
  td {
    padding: 1rem;
    color: ${({ theme }) => theme.colors.text};
    vertical-align: middle;
  }
`;

const ClickableRow = styled.tr<{ clickable: boolean }>`
  cursor: ${({ clickable }) => (clickable ? 'pointer' : 'default')};
`;

const EmptyStateContainer = styled.div`
  text-align: center;
  padding: 3rem 1rem;
  color: ${({ theme }) => theme.colors.textTertiary};
  font-style: italic;
`;

function Table<T>({
  columns,
  data,
  isLoading = false,
  emptyMessage = 'Нет данных для отображения',
  keyExtractor,
  onRowClick,
}: TableProps<T>) {
  if (isLoading) {
    return (
      <TableContainer>
        <div style={{ padding: '2rem', textAlign: 'center' }}>
          <Loading size="small" text="Загрузка данных..." />
        </div>
      </TableContainer>
    );
  }

  if (data.length === 0) {
    return (
      <TableContainer>
        <EmptyStateContainer>
          {emptyMessage}
        </EmptyStateContainer>
      </TableContainer>
    );
  }

  return (
    <TableContainer>
      <StyledTable>
        <TableHeader>
          <tr>
            {columns.map((column) => (
              <th key={column.key.toString()} style={{ width: column.width }}>
                {column.title}
              </th>
            ))}
          </tr>
        </TableHeader>
        <TableBody>
          {data.map((item, index) => (
            <ClickableRow
              key={keyExtractor ? keyExtractor(item, index) : index}
              clickable={!!onRowClick}
              onClick={onRowClick ? () => onRowClick(item) : undefined}
            >
              {columns.map((column) => (
                <td key={`${index}-${column.key.toString()}`}>
                  {column.render
                    ? column.render(item, index)
                    : column.key !== 'actions'
                    ? String((item as any)[column.key] || '')
                    : null}
                </td>
              ))}
            </ClickableRow>
          ))}
        </TableBody>
      </StyledTable>
    </TableContainer>
  );
}

export default Table; 