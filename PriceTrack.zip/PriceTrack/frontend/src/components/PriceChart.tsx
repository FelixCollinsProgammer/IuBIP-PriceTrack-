import React, { useEffect, useState } from 'react';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
} from 'chart.js';
import { Line } from 'react-chartjs-2';
import { ProductService } from '../services/ProductService';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
);

interface PriceChartProps {
  productId: number;
}

export const PriceChart: React.FC<PriceChartProps> = ({ productId }) => {
  const [priceData, setPriceData] = useState<any[]>([]);

  useEffect(() => {
    const fetchPriceHistory = async () => {
      const history = await ProductService.getPriceHistory(productId);
      setPriceData(history);
    };

    fetchPriceHistory();
  }, [productId]);

  const options = {
    responsive: true,
    plugins: {
      legend: {
        position: 'top' as const,
      },
      title: {
        display: true,
        text: 'Price History',
      },
    },
  };

  const data = {
    labels: priceData.map(item => new Date(item.createdAt).toLocaleDateString()),
    datasets: [
      {
        label: 'Price',
        data: priceData.map(item => item.value),
        borderColor: 'rgb(75, 192, 192)',
        backgroundColor: 'rgba(75, 192, 192, 0.5)',
      },
    ],
  };

  return (
    <div style={{ width: '100%', height: '400px' }}>
      {priceData.length > 0 ? (
        <Line options={options} data={data} />
      ) : (
        <div>Loading price history...</div>
      )}
    </div>
  );
}; 