import React, { useEffect, useState } from 'react';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  ChartOptions,
} from 'chart.js';
import { Line } from 'react-chartjs-2';
import styled from 'styled-components';
import { ProductService } from '../services/ProductService';

// Register ChartJS components
ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
);

// Styled Components
const Container = styled.div`
  background-color: ${({ theme }) => theme.colors.cardBackground};
  border-radius: ${({ theme }) => theme.borderRadius.medium};
  box-shadow: ${({ theme }) => theme.shadows.medium};
  padding: ${({ theme }) => theme.spacing.md};
  margin-top: ${({ theme }) => theme.spacing.md};
  transition: ${({ theme }) => theme.transitions.default};
`;

const ChartTitle = styled.h3`
  color: ${({ theme }) => theme.colors.text};
  margin-bottom: ${({ theme }) => theme.spacing.sm};
  font-size: 1.4rem;
`;

const LoadingText = styled.p`
  color: ${({ theme }) => theme.colors.textSecondary};
  font-style: italic;
  text-align: center;
  padding: ${({ theme }) => theme.spacing.lg};
`;

const PriceInfoBar = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: ${({ theme }) => theme.spacing.md};
  padding: ${({ theme }) => theme.spacing.sm};
  background-color: ${({ theme }) => theme.colors.surfaceAlt};
  border-radius: ${({ theme }) => theme.borderRadius.small};
`;

const CurrentPrice = styled.div`
  font-size: 1.25rem;
  font-weight: 600;
  color: ${({ theme }) => theme.colors.text};
`;

const PriceChange = styled.div`
  display: flex;
  align-items: center;
  font-weight: 500;
`;

const Arrow = styled.span<{ isPositive: boolean }>`
  margin-right: 4px;
  color: ${({ isPositive, theme }) =>
    isPositive ? theme.colors.success : theme.colors.error};
`;

const Percentage = styled.span<{ isPositive: boolean }>`
  color: ${({ isPositive, theme }) =>
    isPositive ? theme.colors.success : theme.colors.error};
`;

// Interfaces
interface Price {
  id: number;
  price: number;
  createdAt: string;
}

interface PriceHistoryProps {
  productId: number;
  initialPrices?: Price[];
}

// Helper function to format price in Rubles
const formatPrice = (price: number): string => {
  return new Intl.NumberFormat('ru-RU', {
    style: 'currency',
    currency: 'RUB',
    minimumFractionDigits: 0,
  }).format(price);
};

export const PriceHistory: React.FC<PriceHistoryProps> = ({
  productId,
  initialPrices,
}) => {
  const [prices, setPrices] = useState<Price[]>(initialPrices || []);
  const [loading, setLoading] = useState(!initialPrices);
  const [priceChange, setPriceChange] = useState<{
    amount: number;
    percentage: number;
    isPositive: boolean;
  }>({ amount: 0, percentage: 0, isPositive: true });

  useEffect(() => {
    if (initialPrices) {
      setPrices(initialPrices);
      calculatePriceChange(initialPrices);
      return;
    }

    const fetchPrices = async () => {
      try {
        setLoading(true);
        const data = await ProductService.getPriceHistory(productId);
        setPrices(data);
        calculatePriceChange(data);
      } catch (error) {
        console.error('Error fetching price history:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchPrices();
  }, [productId, initialPrices]);

  const calculatePriceChange = (priceData: Price[]) => {
    if (priceData.length < 2) {
      setPriceChange({ amount: 0, percentage: 0, isPositive: true });
      return;
    }

    // Sort prices by createdAt in ascending order
    const sortedPrices = [...priceData].sort(
      (a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime()
    );

    const oldestPrice = sortedPrices[0].price;
    const latestPrice = sortedPrices[sortedPrices.length - 1].price;
    const difference = latestPrice - oldestPrice;
    const percentChange = (difference / oldestPrice) * 100;

    setPriceChange({
      amount: difference,
      percentage: Math.abs(parseFloat(percentChange.toFixed(2))),
      isPositive: difference >= 0,
    });
  };

  if (loading) {
    return (
      <Container>
        <ChartTitle>Ценовая история</ChartTitle>
        <LoadingText>Загрузка данных о ценах...</LoadingText>
      </Container>
    );
  }

  if (prices.length === 0) {
    return (
      <Container>
        <ChartTitle>Ценовая история</ChartTitle>
        <LoadingText>Нет данных о ценах для этого товара</LoadingText>
      </Container>
    );
  }

  // Sort prices by date for chart display
  const sortedPrices = [...prices].sort(
    (a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime()
  );

  // Prepare data for the chart
  const chartData = {
    labels: sortedPrices.map((price) => {
      const date = new Date(price.createdAt);
      return date.toLocaleDateString('ru-RU', {
        day: '2-digit',
        month: 'short',
      });
    }),
    datasets: [
      {
        label: 'Цена',
        data: sortedPrices.map((price) => price.price),
        borderColor: (context: any) => {
          const chart = context.chart;
          const { ctx, chartArea } = chart;
          
          if (!chartArea) {
            return 'transparent';
          }
          
          return chart.config.options?.theme?.colors?.chart?.line || '#2563eb';
        },
        backgroundColor: 'transparent',
        tension: 0.1,
        pointRadius: 4,
        pointBackgroundColor: (context: any) => {
          return context.chart.config.options?.theme?.colors?.chart?.line || '#2563eb';
        },
      },
    ],
  };

  // Chart options
  const chartOptions: ChartOptions<'line'> = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: false,
      },
      tooltip: {
        backgroundColor: '#1f2937',
        titleColor: '#f3f4f6',
        bodyColor: '#f3f4f6',
        displayColors: false,
        callbacks: {
          label: function(context) {
            return formatPrice(context.parsed.y);
          }
        }
      },
    },
    scales: {
      x: {
        grid: {
          color: (context: any) => {
            return context.chart.config.options?.theme?.colors?.chart?.grid || '#e5e7eb';
          },
        },
        ticks: {
          color: (context: any) => {
            return context.chart.config.options?.theme?.colors?.chart?.text || '#6b7280';
          },
        },
      },
      y: {
        beginAtZero: false,
        grid: {
          color: (context: any) => {
            return context.chart.config.options?.theme?.colors?.chart?.grid || '#e5e7eb';
          },
        },
        ticks: {
          color: (context: any) => {
            return context.chart.config.options?.theme?.colors?.chart?.text || '#6b7280';
          },
          callback: function(value) {
            return formatPrice(value as number);
          }
        },
      },
    },
    // Add theme context to be used by chart
    theme: undefined as any, // Will be set by the plugin
  };

  // Inject the current theme into the chart options
  const ChartWithTheme = ({ theme }: { theme: any }) => {
    const optionsWithTheme = {
      ...chartOptions,
      theme: theme,
    };

    return (
      <div style={{ height: '300px' }}>
        <Line data={chartData} options={optionsWithTheme} />
      </div>
    );
  };

  const currentPrice = sortedPrices[sortedPrices.length - 1].price;

  return (
    <Container>
      <ChartTitle>Ценовая история</ChartTitle>
      <PriceInfoBar>
        <CurrentPrice>Текущая цена: {formatPrice(currentPrice)}</CurrentPrice>
        {priceChange.amount !== 0 && (
          <PriceChange>
            <Arrow isPositive={priceChange.isPositive}>
              {priceChange.isPositive ? '▲' : '▼'}
            </Arrow>
            <Percentage isPositive={priceChange.isPositive}>
              {priceChange.percentage}% ({formatPrice(Math.abs(priceChange.amount))})
            </Percentage>
          </PriceChange>
        )}
      </PriceInfoBar>
      <ChartWithTheme theme={chartOptions.theme as any} />
    </Container>
  );
}; 