import axios from 'axios';

// URL API из переменных окружения или по умолчанию
// @ts-ignore - игнорируем ошибку TypeScript для env
const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:5002/api';

console.log('Using API URL:', API_URL);

// Настройка Axios для работы с токенами
axios.interceptors.request.use(
  (config) => {
    console.log('Axios request to:', config.url);
    
    // Добавляем токен авторизации к каждому запросу
    const token = localStorage.getItem('auth_token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    
    return config;
  },
  (error) => {
    console.error('Axios request error:', error);
    return Promise.reject(error);
  }
);

axios.interceptors.response.use(
  (response) => {
    console.log('Axios response from:', response.config.url, 'status:', response.status);
    return response;
  },
  (error) => {
    // При получении 401 ошибки показываем сообщение
    if (error.response && error.response.status === 401) {
      console.error('Authentication error:', error);
      // Тут можно добавить перенаправление на страницу логина
    } else if (error.code === 'ERR_NETWORK') {
      console.error('Network error. API might be down or unreachable:', error);
      console.error('Attempted to connect to:', error.config?.url);
      // Более подробное сообщение об ошибке сети
      error.message = `Ошибка сети: Сервер недоступен. Убедитесь, что backend запущен на порту ${API_URL.match(/\d+/)?.[0] || '5002'}.`;
    } else {
      console.error('API error:', error);
    }
    return Promise.reject(error);
  }
);

export interface Product {
  id: number;
  name: string;
  url: string;
  imageUrl: string;
  currentPrice: number;
  category?: string;
  marketplace?: string;
  createdAt?: string;
  prices?: Price[];
}

export interface Price {
  id: number;
  price: number;
  createdAt: string;
  productId: number;
}

interface ApiResponse<T> {
  success: boolean;
  data?: T;
  error?: string;
  message?: string;
}

export class ProductService {
  static async addProduct(url: string, category?: string): Promise<Product> {
    try {
      console.log('ProductService.addProduct called with:', { url, category });
      
      // Проверка валидности URL
      try {
        new URL(url);
      } catch (e) {
        console.error('Invalid URL format:', url);
        throw new Error('Некорректный формат URL');
      }
      
      // Добавляем подробное логирование запроса перед отправкой
      console.log(`Sending POST request to ${API_URL}/products with data:`, { url, category });
      
      const response = await axios.post(`${API_URL}/products`, { 
        url,
        category
      }, {
        // Увеличиваем таймаут для парсинга (может занять больше времени)
        timeout: 60000, // Increased to 60 seconds for slow parsing
        // Предотвращаем автоматическое выбрасывание ошибки при статусах 5xx
        validateStatus: function (status) {
          return status < 600; // Принимаем любой статус для собственной обработки
        }
      });
      
      console.log('Server response:', response.status, response.data);
      
      // Обрабатываем любой ответ как успешный, если статус 201 или 200
      if (response.status === 201 || response.status === 200) {
        // Проверяем, содержит ли ответ объект в ожидаемом формате ApiResponse 
        // или это просто объект Product
        let productData: Product;

        if (response.data.success && response.data.data) {
          productData = response.data.data;
        } else if (response.data.id) {
          // Если ответ - просто объект продукта
          productData = response.data;
        } else {
          console.error('Unexpected response format:', response.data);
          throw new Error('Неожиданный формат ответа от сервера');
        }
        
        console.log('Successfully processed product data:', productData);
        return productData;
      }
      
      // Для ошибок
      if (response.status >= 400) {
        const errorMessage = response.data?.error || response.data?.message || 'Failed to add product';
        console.error('Server error:', response.status, errorMessage);
        throw new Error(errorMessage);
      }
      
      console.error('Unexpected response:', response);
      throw new Error('Неожиданный ответ от сервера');
    } catch (error: any) {
      console.error('Error adding product (caught):', error);
      
      // Подробный лог ошибки
      if (error.response) {
        console.error('Error response data:', error.response.data);
        console.error('Error response status:', error.response.status);
        console.error('Error response headers:', error.response.headers);
        
        // Особая обработка ошибки 401
        if (error.response.status === 401) {
          throw new Error('Ошибка аутентификации. Необходимо авторизоваться.');
        }
        
        if (error.response.data?.error) {
          throw new Error(error.response.data.error);
        }
        
        if (error.response.data?.message) {
          throw new Error(error.response.data.message);
        }
      } else if (error.request) {
        console.error('No response received. Request:', error.request);
        throw new Error('Сервер не отвечает, проверьте соединение');
      } else if (error.message) {
        throw new Error(error.message);
      } else {
        throw new Error('Неизвестная ошибка при добавлении товара');
      }
      
      throw error; // Перебрасываем оригинальную ошибку
    }
  }

  static async getProducts(category?: string): Promise<Product[]> {
    try {
      const url = category 
        ? `${API_URL}/products?category=${encodeURIComponent(category)}`
        : `${API_URL}/products`;
        
      const response = await axios.get<ApiResponse<Product[]>>(url);
      
      if (!response.data.success || !response.data.data) {
        throw new Error(response.data.error || 'Failed to get products');
      }
      
      return response.data.data;
    } catch (error: any) {
      console.error('Error getting products:', error);
      if (error.response?.data?.error) {
        throw new Error(error.response.data.error);
      } else if (error.message) {
        throw new Error(error.message);
      } else {
        throw new Error('An unknown error occurred while getting products');
      }
    }
  }

  static async updatePrice(productId: number): Promise<Price> {
    try {
      console.log('ProductService.updatePrice called for product ID:', productId);
      
      const response = await axios.post<ApiResponse<Price>>(`${API_URL}/prices/${productId}`);
      
      console.log('Update price response:', response.data);
      
      if (!response.data.success || !response.data.data) {
        const errorMessage = response.data.error || 'Failed to update price';
        console.error('Server error when updating price:', errorMessage);
        throw new Error(errorMessage);
      }
      
      return response.data.data;
    } catch (error: any) {
      console.error('Error updating price:', error);
      
      // Подробный лог ошибки
      if (error.response) {
        console.error('Error response data:', error.response.data);
        console.error('Error response status:', error.response.status);
        
        if (error.response.data?.error) {
          throw new Error(error.response.data.error);
        }
      } else if (error.request) {
        console.error('No response received. Request:', error.request);
        throw new Error('Сервер не отвечает, проверьте соединение');
      } else if (error.message) {
        throw new Error(error.message);
      } else {
        throw new Error('Неизвестная ошибка при обновлении цены');
      }
      
      throw error; // Перебрасываем оригинальную ошибку
    }
  }

  static async getPrices(productId: number): Promise<Price[]> {
    try {
      const response = await axios.get<ApiResponse<Price[]>>(`${API_URL}/prices/${productId}`);
      
      if (!response.data.success || !response.data.data) {
        throw new Error(response.data.error || 'Failed to get prices');
      }
      
      return response.data.data;
    } catch (error: any) {
      console.error('Error getting prices:', error);
      if (error.response?.data?.error) {
        throw new Error(error.response.data.error);
      } else if (error.message) {
        throw new Error(error.message);
      } else {
        throw new Error('An unknown error occurred while getting prices');
      }
    }
  }
  
  static async getPriceHistory(productId: number): Promise<{ value: number; timestamp: string }[]> {
    try {
      const response = await axios.get<ApiResponse<Price[]>>(`${API_URL}/prices/${productId}`);
      
      if (!response.data.success || !response.data.data) {
        throw new Error(response.data.error || 'Failed to get price history');
      }
      
      return response.data.data.map(price => ({
        value: price.price,
        timestamp: price.createdAt
      }));
    } catch (error: any) {
      console.error('Error getting price history:', error);
      if (error.response?.data?.error) {
        throw new Error(error.response.data.error);
      } else if (error.message) {
        throw new Error(error.message);
      } else {
        throw new Error('An unknown error occurred while getting price history');
      }
    }
  }

  static async getProduct(productId: number): Promise<Product> {
    try {
      const response = await axios.get<ApiResponse<Product>>(`${API_URL}/products/${productId}`);
      
      if (!response.data.success || !response.data.data) {
        throw new Error(response.data.error || 'Failed to get product');
      }
      
      return response.data.data;
    } catch (error: any) {
      console.error('Error getting product:', error);
      if (error.response?.data?.error) {
        throw new Error(error.response.data.error);
      } else if (error.message) {
        throw new Error(error.message);
      } else {
        throw new Error('An unknown error occurred while getting product');
      }
    }
  }

  static async getCategories(): Promise<string[]> {
    try {
      const response = await axios.get<ApiResponse<string[]>>(`${API_URL}/products/categories/list`);
      
      if (!response.data.success || !response.data.data) {
        throw new Error(response.data.error || 'Failed to get categories');
      }
      
      return response.data.data;
    } catch (error: any) {
      console.error('Error getting categories:', error);
      if (error.response?.data?.error) {
        throw new Error(error.response.data.error);
      } else if (error.message) {
        throw new Error(error.message);
      } else {
        throw new Error('An unknown error occurred while getting categories');
      }
    }
  }

  static async updateCategory(productId: number, category: string): Promise<Product> {
    try {
      const response = await axios.put<ApiResponse<Product>>(
        `${API_URL}/products/${productId}/category`, 
        { category }
      );
      
      if (!response.data.success || !response.data.data) {
        throw new Error(response.data.error || 'Failed to update category');
      }
      
      return response.data.data;
    } catch (error: any) {
      console.error('Error updating category:', error);
      if (error.response?.data?.error) {
        throw new Error(error.response.data.error);
      } else if (error.message) {
        throw new Error(error.message);
      } else {
        throw new Error('An unknown error occurred while updating category');
      }
    }
  }

  static async getUpdateCooldown(productId: number): Promise<{ canUpdate: boolean; nextUpdateTime?: string; remainingTimeMs?: number }> {
    try {
      const response = await axios.get<ApiResponse<{ canUpdate: boolean; nextUpdateTime?: string; remainingTimeMs?: number }>>(`${API_URL}/prices/${productId}/cooldown`);
      
      if (!response.data.success || !response.data.data) {
        throw new Error(response.data.error || 'Failed to get update cooldown information');
      }
      
      return response.data.data;
    } catch (error: any) {
      console.error('Error getting update cooldown information:', error);
      if (error.response?.data?.error) {
        throw new Error(error.response.data.error);
      } else if (error.message) {
        throw new Error(error.message);
      } else {
        throw new Error('An unknown error occurred while getting update cooldown information');
      }
    }
  }

  static async updateProduct(productId: number, data: { category?: string, marketplace?: string }): Promise<Product> {
    try {
      console.log('ProductService.updateProduct called for product ID:', productId, 'with data:', data);
      
      const response = await axios.put<ApiResponse<Product>>(
        `${API_URL}/products/${productId}`, 
        data
      );
      
      console.log('Update product response:', response.data);
      
      if (!response.data.success || !response.data.data) {
        const errorMessage = response.data.error || 'Failed to update product';
        console.error('Server error when updating product:', errorMessage);
        throw new Error(errorMessage);
      }
      
      return response.data.data;
    } catch (error: any) {
      console.error('Error updating product:', error);
      
      // Подробный лог ошибки
      if (error.response) {
        console.error('Error response data:', error.response.data);
        console.error('Error response status:', error.response.status);
        
        if (error.response.data?.error) {
          throw new Error(error.response.data.error);
        }
      } else if (error.request) {
        console.error('No response received. Request:', error.request);
        throw new Error('Сервер не отвечает, проверьте соединение');
      } else if (error.message) {
        throw new Error(error.message);
      } else {
        throw new Error('Неизвестная ошибка при обновлении товара');
      }
      
      throw error; // Перебрасываем оригинальную ошибку
    }
  }

  static async deleteProduct(productId: number): Promise<boolean> {
    try {
      console.log('ProductService.deleteProduct called for product ID:', productId);
      
      const response = await axios.delete<ApiResponse<boolean>>(
        `${API_URL}/products/${productId}`
      );
      
      console.log('Delete product response:', response.data);
      
      if (!response.data.success) {
        const errorMessage = response.data.error || 'Failed to delete product';
        console.error('Server error when deleting product:', errorMessage);
        throw new Error(errorMessage);
      }
      
      return true;
    } catch (error: any) {
      console.error('Error deleting product:', error);
      
      // Подробный лог ошибки
      if (error.response) {
        console.error('Error response data:', error.response.data);
        console.error('Error response status:', error.response.status);
        
        if (error.response.data?.error) {
          throw new Error(error.response.data.error);
        }
      } else if (error.request) {
        console.error('No response received. Request:', error.request);
        throw new Error('Сервер не отвечает, проверьте соединение');
      } else if (error.message) {
        throw new Error(error.message);
      } else {
        throw new Error('Неизвестная ошибка при удалении товара');
      }
      
      throw error; // Перебрасываем оригинальную ошибку
    }
  }
} 