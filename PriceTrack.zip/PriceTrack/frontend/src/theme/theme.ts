import { DefaultTheme } from 'styled-components';

// Base theme with shared properties
const baseTheme = {
  shadows: {
    small: '0 2px 4px rgba(0, 0, 0, 0.1)',
    medium: '0 4px 8px rgba(0, 0, 0, 0.12)',
    large: '0 8px 16px rgba(0, 0, 0, 0.14)',
  },
  transitions: {
    default: '0.3s ease',
    fast: '0.15s ease',
    slow: '0.5s ease',
  },
  borderRadius: {
    small: '4px',
    medium: '8px',
    large: '12px',
  },
  spacing: {
    xs: '4px',
    sm: '8px',
    md: '16px',
    lg: '24px',
    xl: '32px',
  },
};

// Light theme
export const lightTheme: DefaultTheme = {
  ...baseTheme,
  colors: {
    primary: '#1976d2',
    primaryLight: '#4791db',
    primaryDark: '#115293',
    secondary: '#5C6BC0',
    secondaryLight: '#8E99F3',
    secondaryDark: '#26418f',
    background: '#f5f7fa',
    surface: '#ffffff',
    cardBackground: '#ffffff',
    inputBackground: '#f9f9f9',
    text: '#222222',
    textLight: '#666666',
    border: '#e0e0e0',
    disabled: '#bdbdbd',
    error: '#e53935',
    success: '#43a047',
    warning: '#ffa000',
    info: '#039be5',
  },
};

// Dark theme
export const darkTheme: DefaultTheme = {
  ...baseTheme,
  colors: {
    primary: '#2196f3',
    primaryLight: '#4dabf5',
    primaryDark: '#1769aa',
    secondary: '#7986CB',
    secondaryLight: '#9FA8DA',
    secondaryDark: '#5C6BC0',
    background: '#121212',
    surface: '#1e1e1e',
    cardBackground: '#2d2d2d',
    inputBackground: '#333333',
    text: '#f5f5f5',
    textLight: '#b0b0b0',
    border: '#444444',
    disabled: '#616161',
    error: '#f44336',
    success: '#4caf50',
    warning: '#ff9800',
    info: '#29b6f6',
  },
};

export default { lightTheme, darkTheme }; 